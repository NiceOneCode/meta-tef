/**
 *
 * @type {type}
 */

console.log("######################## -TEF APPLICATION STARTUP- ########################");

/* process.env.debug = "false"; */
process.env.debug = "false";

var ip = require('ip');
if(process.env.debug === "false" )
{
  process.env.IP_ADDRESS = ip.address();
}
else
{
  process.env.IP_ADDRESS = "127.0.0.1";
}

process.env.PORT = 80;
process.env.serial_port = '/dev/dmg/ttyMSP';
var defaultPort = false;
/*
process.argv.forEach(function (val, index, array) {
    if (val === '-h' || val === '--h') {
        console.log("\nTEF web server interface\n\nUsage:\n\
\t-h, --h\t\tshows this help\n\
\t--debug\t\tactivates the server for debugging purposes on a PC\n\
\t-port x\t\tstarts listening on port x (the default port is 80)\n\
\t-serial_port s\tsets the port s for serial communication (the default serial port is /dev/ttymxc7)\n\n");
        process.exit();
    }
    if (val === '--debug') {
        process.env.debug = "true";
    }
    if (val === '-port') {
        if (typeof (array[index + 1]) !== 'undefined') {
            process.env.PORT = array[index + 1];
        }
    }
    if (val === '-serial_port') {
        if (typeof (array[index + 1]) !== 'undefined') {
            process.env.serial_port = array[index + 1];
        }
    }
});
*/
var http = require('http');
var app = require('./tef/app');
var fs = require('fs');

var server = http.createServer(app);
server.listen(app.get('port'), function () {
    console.log("TEF web server interface started and listening on port " + app.get('port'));
});

var io = require('socket.io')(server);
var clientAliveFuncRunning = false;
var util = require('util');

if(fs.existsSync("/tmp/session")){
   fs.unlinkSync("/tmp/session");
}

io.on('connection', function(socket){
  fs.writeFileSync(__dirname + "/heartbeat", "");
  socket.on("heartbeat", function(data){
    fs.writeFileSync(__dirname + "/heartbeat", "alive");
  })

  if(!clientAliveFuncRunning){
    clientAliveFuncRunning = true;
    setInterval(function() {
          isClientAlive();
    }, 5000);
  }
});

function isClientAlive(){
  var TIMEOUT_DISCONNECTION = 10;
  var currentTime = new Date();
  if(fs.existsSync(__dirname + "/heartbeat")){
    fs.stat(__dirname + "/heartbeat", function(err, stats){
      var mtime = new Date(util.inspect(stats.mtime));
      var dif = currentTime.getTime() - mtime.getTime();
      var Seconds_from_T1_to_T2 = dif / 1000;
      var Seconds_Between_Dates = Math.abs(Seconds_from_T1_to_T2);
      //console.log(Seconds_Between_Dates);
      if(Seconds_Between_Dates > TIMEOUT_DISCONNECTION){
        //console.log("Dead client");
        //console.log(fs.existsSync("/tmp/session"));
        //clientAliveFuncRunning = false;
        if(fs.existsSync("/tmp/session")){
          fs.unlinkSync("/tmp/session");
        }
        if(fs.existsSync(__dirname + "/heartbeat")){
          fs.unlinkSync(__dirname + "/heartbeat");
        }
      }
    });
  }
}

msp = app.get('msp');
msp.setWebSocket(io);


var exec = require("child_process").exec;
var command = "uname -r"
exec(command, function(error, stdout, stderr){
fs.writeFileSync("/dev/dmg/kernel", stdout);
 });

//Reboot on new APP packet sent
 setInterval(function() {
   if(fs.existsSync("/dev/dmg/reboot")){
     var update = fs.readFileSync("/dev/dmg/reboot");
          if(update == "OK")
          {
            io.emit("update", "OK");
          }
          else
           if(update == "Failed"){
             io.emit("update", "Failed");
           }
     fs.unlinkSync("/dev/dmg/reboot");
   }
 }, 5000);

var ini = require('ini');
var local_armsettings_file    = __dirname + '/tef/database/local_settings.ini';
var default_armsetting_file   = __dirname + '/tef/database/default/armSettingsDefault.ini';
var armSettingDefault = null;

if ( fs.existsSync(local_armsettings_file))
{
  try
  {
      armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  }
  catch(e)
  {
      armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
  }

}
else
{
  armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
}

var timeout_data_halt;
if (armLocalDefault.Settings.Extintion_Automatique_Eth == 'activee'){
  timeout_data_halt = armLocalDefault.Settings.Extintion_Automatique_Eth_min + " ";
} else { timeout_data_halt = "0 " }
if (armLocalDefault.Settings.Extintion_Automatique_WiFi == 'activee'){
  timeout_data_halt += armLocalDefault.Settings.Extintion_Automatique_WiFi_min + " ";
} else { timeout_data_halt += "0 " }

timeout_data_halt += armLocalDefault.Settings.Halt;
console.log("LAN shutdown status: ETH/WIFI/NODE_MODULE: " + timeout_data_halt);
function puts(error, stdout, stderr) { util.puts(stdout) }
fs.writeFileSync("/dev/dmg/wd_start", timeout_data_halt);
exec("sync",puts);


fs.writeFileSync("/dev/dmg/out_arm_active", "1");
exec("sync",puts);
