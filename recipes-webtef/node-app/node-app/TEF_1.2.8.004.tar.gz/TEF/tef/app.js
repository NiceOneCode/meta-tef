var express = require('express');
var app = express();

var passport = require('passport');
var flash = require('connect-flash');


var path = require('path');

var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var session = require('express-session');

require('./app/passport')(passport); // pass passport for configuration

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
//app.use(logger('dev')); // enable this to get more logging
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// required for passport
app.use(session({
    secret: 'ilovescotchscotchyscotchscotch', // session secret
    //cookie: {maxAge: 20000}, // timeout in ms
    resave: true,
    saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash());// use connect-flash for flash messages stored in session


var msp = require('./msp');
app.set('msp', msp);


// routes ======================================================================
require('./app/routes.js')(app, passport, msp); // load our routes and pass in our app and fully configured passport

// catch 404 and forwarding to error handler
app.use(function (req, res, next) {
    //var err = new Error('Not Found');
    //console.log(res);
    //err.status = 404;
    //next(err);
});

// error handlers

// development error handler
// will print stacktrace
//if (app.get('env') === 'development') {
//    app.use(function (err, req, res, next) {
//        res.status(err.status || 500);
//        res.render('error', {
//            message: err.message,
//            error: err
//        });
//    });
//}

// production error handler
// no stacktraces leaked to user
//app.use(function (err, req, res, next) {
//    res.status(err.status || 500);
//    res.render('/pages/error', {
//        message: err.message,
//        error: {}
//    });
//});

app.set('port', process.env.PORT);


module.exports = app;
