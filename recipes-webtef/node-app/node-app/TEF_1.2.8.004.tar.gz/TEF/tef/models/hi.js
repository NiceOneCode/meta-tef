/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var tefData;
var tefDataDefault = null;
var errorFields;
var tefLocal_Settings = null;

var local_armsettings_file    = __dirname + '/../database/local_settings.ini';
var default_armsetting_file   = __dirname + '/../database/default/armSettingsDefault.ini'
var armLocalDefault;
if ( fs.existsSync(local_armsettings_file))
{
  try
  {
      armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  }
  catch(e)
  {
      armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
  }

}
else
{
  armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
}

exports.init = function (objData) {
    tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/hi.ini', 'utf-8'));
    errorFields = [];
    if (objData === false) {
        // no previous data defined,
        // so setting default values
        /*if (tefDataDefault === null) {
            tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/hi.ini', 'utf-8'));
        }*/
        tefData = {
            'Typologie_TEF': tefDataDefault.Typologie_TEF,
            'Nom_Identifiant': tefDataDefault.Nom_Identifiant,

            'Type_Ligne_L1': tefDataDefault.Type_Ligne_L1.default,
            'Impedance_Ligne_L1': tefDataDefault.Impedance_Ligne_L1.default,

            'Temps_Duree_Fixe_TMAX': tefDataDefault.Temps_Duree_Fixe_TMAX.default,
            'Temps_Anti_Bavard_TAB': tefDataDefault.Temps_Anti_Bavard_TAB.default,
            'Temps_Anti_Bavard_TAB_sec': tefDataDefault.Temps_Anti_Bavard_TAB_sec.default,
            'Temps_Mise_A_Repos_No_Rep_L1_sec': tefDataDefault.Temps_Mise_A_Repos_No_Rep_L1_sec.default,


            'Modalite_Communication_L1': tefDataDefault.Modalite_Communication_L1.default,


            'Typologie_Signalisation_L1': tefDataDefault.Typologie_Signalisation_L1.default,
            'Duree_Signalisation_En_Sortie_L1_msec': tefDataDefault.Duree_Signalisation_En_Sortie_L1_msec.default,
            'Code_Identifiant_L1': tefDataDefault.Code_Identifiant_L1.default,
            'Duree_5Ton_L1': tefDataDefault.Duree_5Ton_L1.default,
            'Relais_MTR': tefDataDefault.Relais_MTR.default,



            'Mode_Attente_L1': tefDataDefault.Mode_Attente_L1.default,
            'Duree_Attente_Acquittement_L1_sec': tefDataDefault.Duree_Attente_Acquittement_L1_sec.default,
            'Emission_Message_Vocal_Mode_Attente_L1': tefDataDefault.Emission_Message_Vocal_Mode_Attente_L1.default,

            'Detection_Occupation_Liberation_L1': tefDataDefault.Detection_Occupation_Liberation_L1.default,
            'Duree_Signalisation_Detectee_Liberer_Communication_L1_sec': tefDataDefault.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.default,
            'Emission_Message_Vocal_Detection_Occupation_Liberation_L1': tefDataDefault.Emission_Message_Vocal_Detection_Occupation_Liberation_L1.default,


            'Signalisation_Retour_Appel_L1': tefDataDefault.Signalisation_Retour_Appel_L1.default,

            'Duree_Signalisation_Retour_Appel_L1_msec': tefDataDefault.Duree_Signalisation_Retour_Appel_L1_msec.default,

            'Niveau_Signalisation_Retour_Appel_L1_dB': tefDataDefault.Niveau_Signalisation_Retour_Appel_L1_dB.default,


            'Modalite_Reponse_L1': tefDataDefault.Modalite_Reponse_L1.default,
            'Nombre_Trains_Sonnerie_L1': tefDataDefault.Nombre_Trains_Sonnerie_L1.default,

            'Sonnerie': tefDataDefault.Sonnerie.default,
            'Duree_Sonnerie_Interieure_msec': tefDataDefault.Duree_Sonnerie_Interieure_msec.default,
            'Duree_Extention_Sonnerie_msec': tefDataDefault.Duree_Extention_Sonnerie_msec.default,
            'Module_Interface_Aerienne_L1': tefDataDefault.Module_Interface_Aerienne_L1.default,

            'Niveau_Emission_Ligne_Analogique_L1_dB': tefDataDefault.Niveau_Emission_Ligne_Analogique_L1_dB.default,

            'Extintion_Automatique_WiFi': tefDataDefault.Extintion_Automatique_WiFi.default,
            'Extintion_Automatique_WiFi_min': tefDataDefault.Extintion_Automatique_WiFi_min.default,
            'Extintion_Automatique_Eth': tefDataDefault.Extintion_Automatique_Eth.default,
            'Extintion_Automatique_Eth_min': tefDataDefault.Extintion_Automatique_Eth_min.default,
            'Mot_De_Passe': tefDataDefault.Mot_De_Passe,
            'Panneau_solaire': tefDataDefault.Panneau_solaire.default,
            'Panneau_solaire_etat': "",
            'Batterie_etat': "",
            'Etat_recharge': "",
            'Type_alimentation': "",
            'Type_Batterie': tefDataDefault.Type_Batterie.default,
            'Sous_Seuil': "",
        };
    } else {
        tefData = objData;
    }
};
exports.getData = function () {
    return tefData;
};
exports.getDataDefault = function() {
    return tefDataDefault;
};
exports.getErrorFields = function () {
    return errorFields;
};
exports.hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
exports.getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};
exports.export = function () {
    var obj = {
        'Typologie_TEF': tefData.Typologie_TEF,
        'Nom_Identifiant': tefData.Nom_Identifiant,

        'Type_Ligne_L1': tefData.Type_Ligne_L1,
        'Impedance_Ligne_L1': tefData.Impedance_Ligne_L1,


        'Temps_Duree_Fixe_TMAX': tefData.Temps_Duree_Fixe_TMAX,
        'Temps_Anti_Bavard_TAB': tefData.Temps_Anti_Bavard_TAB,
        'Temps_Anti_Bavard_TAB_sec': tefData.Temps_Anti_Bavard_TAB_sec,
        'Temps_Mise_A_Repos_No_Rep_L1_sec': tefData.Temps_Mise_A_Repos_No_Rep_L1_sec,


        'Modalite_Communication_L1': tefData.Modalite_Communication_L1,


        'Typologie_Signalisation_L1': tefData.Typologie_Signalisation_L1,
        'Duree_Signalisation_En_Sortie_L1_msec': tefData.Duree_Signalisation_En_Sortie_L1_msec,
        'Code_Identifiant_L1': tefData.Code_Identifiant_L1,
        'Duree_5Ton_L1': tefData.Duree_5Ton_L1,
        'Relais_MTR': tefData.Relais_MTR,


        'Mode_Attente_L1': tefData.Mode_Attente_L1,
        'Duree_Attente_Acquittement_L1_sec': tefData.Duree_Attente_Acquittement_L1_sec,
        'Emission_Message_Vocal_Mode_Attente_L1': tefData.Emission_Message_Vocal_Mode_Attente_L1,

        'Detection_Occupation_Liberation_L1': tefData.Detection_Occupation_Liberation_L1,
        'Duree_Signalisation_Detectee_Liberer_Communication_L1_sec': tefData.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec,
        'Emission_Message_Vocal_Detection_Occupation_Liberation_L1': tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1,


        'Signalisation_Retour_Appel_L1': tefData.Signalisation_Retour_Appel_L1,

        'Duree_Signalisation_Retour_Appel_L1_msec': tefData.Duree_Signalisation_Retour_Appel_L1_msec,

        'Niveau_Signalisation_Retour_Appel_L1_dB': tefData.Niveau_Signalisation_Retour_Appel_L1_dB,


        'Modalite_Reponse_L1': tefData.Modalite_Reponse_L1,
        'Nombre_Trains_Sonnerie_L1': tefData.Nombre_Trains_Sonnerie_L1,


        'Sonnerie': tefData.Sonnerie,
        'Duree_Sonnerie_Interieure_msec': tefData.Duree_Sonnerie_Interieure_msec,
        'Duree_Extention_Sonnerie_msec': tefData.Duree_Extention_Sonnerie_msec,
        'Module_Interface_Aerienne_L1': tefData.Module_Interface_Aerienne_L1,

        'Niveau_Emission_Ligne_Analogique_L1_dB': tefData.Niveau_Emission_Ligne_Analogique_L1_dB,

        'Extintion_Automatique_WiFi': tefData.Extintion_Automatique_WiFi,
        'Extintion_Automatique_WiFi_min': tefData.Extintion_Automatique_WiFi_min,
        'Extintion_Automatique_Eth': tefData.Extintion_Automatique_Eth,
        'Extintion_Automatique_Eth_min': tefData.Extintion_Automatique_Eth_min,
        'Niveau_de_sortie': tefData.Niveau_de_sortie,
        'Niveau_entrant': tefData.Niveau_entrant,
        //'Mot_De_Passe': tefData.Mot_De_Passe,
        'Panneau_solaire': tefData.Panneau_solaire,
        // 'Panneau_solaire_etat': tefData.Panneau_solaire_etat,
        // 'Batterie_etat': tefData.Batterie_etat,
        // 'Type_alimentation':tefData.Type_alimentation,
        'Type_Batterie': tefData.Type_Batterie,
    };
    return obj;
};
exports.normalize = function () {
    // Setting initial data according to checkboxes with unchecked values
    // (unchecked checkboxes are not trasmitted in HTTP POST request).
    if (typeof tefData.Type_Ligne_L1 === 'undefined') {
        tefData.Type_Ligne_L1 = '2_fils';
    }
    // if (typeof tefData.Type_Ligne_L2 === 'undefined') {
    //     tefData.Type_Ligne_L2 = '2_fils';
    // }
    if (typeof tefData.Impedance_Ligne_L1 === 'undefined') {
        tefData.Impedance_Ligne_L1 = '600_Ohm';
    }
    // if (typeof tefData.Impedance_Ligne_L2 === 'undefined') {
    //     tefData.Impedance_Ligne_L2 = '600_Ohm';
    // }
    // if (typeof tefData.Priorite_Ligne === 'undefined') {
    //     tefData.Priorite_Ligne = 'L1';
    // }
    if (typeof tefData.Temps_Duree_Fixe_TMAX === 'undefined') {
        tefData.Temps_Duree_Fixe_TMAX = 'pas_activee';
    }
    if (typeof tefData.Temps_Anti_Bavard_TAB === 'undefined') {
        tefData.Temps_Anti_Bavard_TAB = 'pas_activee';
    }
    if (typeof tefData.Modalite_Communication_L1 === 'undefined') {
        tefData.Modalite_Communication_L1 = 'half_duplex';
    }
    // if (typeof tefData.Modalite_Communication_L2 === 'undefined') {
    //     tefData.Modalite_Communication_L2 = 'half_duplex';
    // }
    if (typeof tefData.Typologie_Signalisation_L1 === 'undefined') {
        tefData.Typologie_Signalisation_L1 = '5Tons';
    }
    // if (typeof tefData.Typologie_Signalisation_L2 === 'undefined') {
    //     tefData.Typologie_Signalisation_L2 = '5Tons';
    // }
    if (typeof tefData.Code_Identifiant_L1 === 'undefined') {
        tefData.Code_Identifiant_L1 = '';
    }
    // if (typeof tefData.Code_Identifiant_L2 === 'undefined') {
    //     tefData.Code_Identifiant_L2 = '';
    // }
    if (typeof tefData.Mode_Attente_L1 === 'undefined') {
        tefData.Mode_Attente_L1 = 'sans_acquittement';
    }
    if (typeof tefData.Emission_Message_Vocal_Mode_Attente_L1 === 'undefined') {
        tefData.Emission_Message_Vocal_Mode_Attente_L1 = 'pas_activee';
    }
    // if (typeof tefData.Mode_Attente_L2 === 'undefined') {
    //     tefData.Mode_Attente_L2 = 'sans_acquittement';
    // }
    // if (typeof tefData.Emission_Message_Vocal_Mode_Attente_L2 === 'undefined') {
    //     tefData.Emission_Message_Vocal_Mode_Attente_L2 = 'pas_activee';
    // }
    if (typeof tefData.Detection_Occupation_Liberation_L1 === 'undefined') {
        tefData.Detection_Occupation_Liberation_L1 = 'pas_activee';
    }
    if (typeof tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1 === 'undefined') {
        tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1 = 'pas_activee';
    }
    // if (typeof tefData.Detection_Occupation_Liberation_L2 === 'undefined') {
    //     tefData.Detection_Occupation_Liberation_L2 = 'pas_activee';
    // }
    // if (typeof tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2 === 'undefined') {
    //     tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2 = 'pas_activee';
    // }
    if (typeof tefData.Module_Interface_Aerienne_L1 === 'undefined') {
        tefData.Module_Interface_Aerienne_L1 = 'pas_present';
    }
    if (typeof tefData.Extintion_Automatique_WiFi === 'undefined') {
        tefData.Extintion_Automatique_WiFi = 'pas_activee';
    }
    console.log("MODELS: " + tefData.Extintion_Automatique_WiFi);
    if (typeof tefData.Extintion_Automatique_Eth === 'undefined') {
        tefData.Extintion_Automatique_Eth = 'pas_activee';
    }
    if (typeof tefData.Panneau_solaire === 'undefined') {
        tefData.Panneau_solaire = 'pas_activee';
    } else {
        tefData.Panneau_solaire = 'activee';
    }
    if (typeof tefData.Type_Batterie === 'undefined') {
        tefData.Type_Batterie = 'Non_rechargeable';
    }
    else
    {
        tefData.Type_Batterie = 'Rechargeable';
    }  
};
exports.validate = function () {

    if (tefDataDefault === null) {
        tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/hi.ini', 'utf-8'));
    }

    checkNotEmpty(tefData.Nom_Identifiant, 'Nom_Identifiant');
    tefData.Type_Ligne_L1 = checkFieldInList(tefData.Type_Ligne_L1, 'Type_Ligne_L1', tefDataDefault.Type_Ligne_L1);
    //tefData.Type_Ligne_L2 = checkFieldInList(tefData.Type_Ligne_L2, 'Type_Ligne_L2', tefDataDefault.Type_Ligne_L2);
    tefData.Impedance_Ligne_L1 = checkFieldInList(tefData.Impedance_Ligne_L1, 'Impedance_Ligne_L1', tefDataDefault.Impedance_Ligne_L1);
    //tefData.Impedance_Ligne_L2 = checkFieldInList(tefData.Impedance_Ligne_L2, 'Impedance_Ligne_L2', tefDataDefault.Impedance_Ligne_L2);
    //tefData.Priorite_Ligne = checkFieldInList(tefData.Priorite_Ligne, 'Priorite_Ligne', tefDataDefault.Priorite_Ligne);
    tefData.Temps_Duree_Fixe_TMAX = checkFieldInList(tefData.Temps_Duree_Fixe_TMAX, 'Temps_Duree_Fixe_TMAX', tefDataDefault.Temps_Duree_Fixe_TMAX);
    tefData.Temps_Anti_Bavard_TAB = checkFieldInList(tefData.Temps_Anti_Bavard_TAB, 'Temps_Anti_Bavard_TAB', tefDataDefault.Temps_Anti_Bavard_TAB);
    tefData.Temps_Anti_Bavard_TAB_sec = checkFieldInRange(tefData.Temps_Anti_Bavard_TAB_sec, 'Temps_Anti_Bavard_TAB_sec', tefDataDefault.Temps_Anti_Bavard_TAB_sec);
    tefData.Temps_Mise_A_Repos_No_Rep_L1_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_L1_sec, 'Temps_Mise_A_Repos_No_Rep_L1_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_L1_sec);
    //tefData.Temps_Mise_A_Repos_No_Rep_L2_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_L2_sec, 'Temps_Mise_A_Repos_No_Rep_L2_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_L2_sec);
    tefData.Modalite_Communication_L1 = checkFieldInList(tefData.Modalite_Communication_L1, 'Modalite_Communication_L1', tefDataDefault.Modalite_Communication_L1);
    //tefData.Modalite_Communication_L2 = checkFieldInList(tefData.Modalite_Communication_L2, 'Modalite_Communication_L2', tefDataDefault.Modalite_Communication_L2);
    tefData.Typologie_Signalisation_L1 = checkFieldInList(tefData.Typologie_Signalisation_L1, 'Typologie_Signalisation_L1', tefDataDefault.Typologie_Signalisation_L1);
    switch (tefData.Typologie_Signalisation_L1) {
        case '2200Hz':
            tefData.Duree_Signalisation_Retour_Appel_L1_msec = checkFieldInRange(tefData.Duree_Signalisation_Retour_Appel_L1_msec, 'Duree_Signalisation_Retour_Appel_L1_msec', tefDataDefault.Duree_Signalisation_Retour_Appel_L1_msec);
            tefData.Niveau_Signalisation_Retour_Appel_L1_dB = checkFieldInRange(tefData.Niveau_Signalisation_Retour_Appel_L1_dB, 'Niveau_Signalisation_Retour_Appel_L1_dB', tefDataDefault.Niveau_Signalisation_Retour_Appel_L1_dB);
            break;
        case '5Tons':
            checkNotEmpty(tefData.Code_Identifiant_L1, 'Code_Identifiant_L1');
            break;
    }
    //tefData.Typologie_Signalisation_L2 = checkFieldInList(tefData.Typologie_Signalisation_L2, 'Typologie_Signalisation_L2', tefDataDefault.Typologie_Signalisation_L2);
    // switch (tefData.Typologie_Signalisation_L2) {
    //     case '2200Hz':
    //         tefData.Duree_Signalisation_Retour_Appel_L2_msec = checkFieldInRange(tefData.Duree_Signalisation_Retour_Appel_L2_msec, 'Duree_Signalisation_Retour_Appel_L2_msec', tefDataDefault.Duree_Signalisation_Retour_Appel_L2_msec);
    //         tefData.Niveau_Signalisation_Retour_Appel_L2_dB = checkFieldInRange(tefData.Niveau_Signalisation_Retour_Appel_L2_dB, 'Niveau_Signalisation_Retour_Appel_L2_dB', tefDataDefault.Niveau_Signalisation_Retour_Appel_L2_dB);
    //         break;
    //     case '5Tons':
    //         checkNotEmpty(tefData.Code_Identifiant_L2, 'Code_Identifiant_L2');
    //         break;
    // }
    tefData.Mode_Attente_L1 = checkFieldInList(tefData.Mode_Attente_L1, 'Mode_Attente_L1', tefDataDefault.Mode_Attente_L1);
    tefData.Duree_Attente_Acquittement_L1_sec = checkFieldInRange(tefData.Duree_Attente_Acquittement_L1_sec, 'Duree_Attente_Acquittement_L1_sec', tefDataDefault.Duree_Attente_Acquittement_L1_sec);
    tefData.Emission_Message_Vocal_Mode_Attente_L1 = checkFieldInList(tefData.Emission_Message_Vocal_Mode_Attente_L1, 'Emission_Message_Vocal_Mode_Attente_L1', tefDataDefault.Emission_Message_Vocal_Mode_Attente_L1);
    //tefData.Mode_Attente_L2 = checkFieldInList(tefData.Mode_Attente_L2, 'Mode_Attente_L2', tefDataDefault.Mode_Attente_L2);
    //tefData.Duree_Attente_Acquittement_L2_sec = checkFieldInRange(tefData.Duree_Attente_Acquittement_L2_sec, 'Duree_Attente_Acquittement_L2_sec', tefDataDefault.Duree_Attente_Acquittement_L2_sec);
    //tefData.Emission_Message_Vocal_Mode_Attente_L2 = checkFieldInList(tefData.Emission_Message_Vocal_Mode_Attente_L2, 'Emission_Message_Vocal_Mode_Attente_L2', tefDataDefault.Emission_Message_Vocal_Mode_Attente_L2);
    tefData.Detection_Occupation_Liberation_L1 = checkFieldInList(tefData.Detection_Occupation_Liberation_L1, 'Detection_Occupation_Liberation_L1', tefDataDefault.Detection_Occupation_Liberation_L1);
    tefData.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec = checkFieldInRange(tefData.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec, 'Duree_Signalisation_Detectee_Liberer_Communication_L1_sec', tefDataDefault.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec);
    tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1 = checkFieldInList(tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1, 'Emission_Message_Vocal_Detection_Occupation_Liberation_L1', tefDataDefault.Emission_Message_Vocal_Detection_Occupation_Liberation_L1);
    //tefData.Detection_Occupation_Liberation_L2 = checkFieldInList(tefData.Detection_Occupation_Liberation_L2, 'Detection_Occupation_Liberation_L2', tefDataDefault.Detection_Occupation_Liberation_L2);
    //tefData.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec = checkFieldInRange(tefData.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec, 'Duree_Signalisation_Detectee_Liberer_Communication_L2_sec', tefDataDefault.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec);
    //tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2 = checkFieldInList(tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2, 'Emission_Message_Vocal_Detection_Occupation_Liberation_L2', tefDataDefault.Emission_Message_Vocal_Detection_Occupation_Liberation_L2);
    tefData.Modalite_Reponse_L1 = checkFieldInList(tefData.Modalite_Reponse_L1, 'Modalite_Reponse_L1', tefDataDefault.Modalite_Reponse_L1);
    tefData.Nombre_Trains_Sonnerie_L1 = checkFieldInRange(tefData.Nombre_Trains_Sonnerie_L1, 'Nombre_Trains_Sonnerie_L1', tefDataDefault.Nombre_Trains_Sonnerie_L1);
    //tefData.Modalite_Reponse_L2 = checkFieldInList(tefData.Modalite_Reponse_L2, 'Modalite_Reponse_L2', tefDataDefault.Modalite_Reponse_L2);
    //tefData.Nombre_Trains_Sonnerie_L2 = checkFieldInRange(tefData.Nombre_Trains_Sonnerie_L2, 'Nombre_Trains_Sonnerie_L2', tefDataDefault.Nombre_Trains_Sonnerie_L2);
    tefData.Sonnerie = checkFieldInList(tefData.Sonnerie, 'Sonnerie', tefDataDefault.Sonnerie);
    tefData.Duree_Sonnerie_Interieure_msec = checkFieldInRange(tefData.Duree_Sonnerie_Interieure_msec, 'Duree_Sonnerie_Interieure_msec', tefDataDefault.Duree_Sonnerie_Interieure_msec);
    tefData.Duree_Extention_Sonnerie_msec = checkFieldInRange(tefData.Duree_Extention_Sonnerie_msec, 'Duree_Extention_Sonnerie_msec', tefDataDefault.Duree_Extention_Sonnerie_msec);
    tefData.Module_Interface_Aerienne_L1 = checkFieldInList(tefData.Module_Interface_Aerienne_L1, 'Module_Interface_Aerienne_L1', tefDataDefault.Module_Interface_Aerienne_L1);
    //tefData.Module_Interface_Aerienne_L2 = checkFieldInList(tefData.Module_Interface_Aerienne_L2, 'Module_Interface_Aerienne_L2', tefDataDefault.Module_Interface_Aerienne_L2);
    //tefData.Niveau_Emission_Ligne_Analogique_L1_dB = checkFieldInRange(tefData.Niveau_Emission_Ligne_Analogique_L1_dB, 'Niveau_Emission_Ligne_Analogique_L1_dB', tefDataDefault.Niveau_Emission_Ligne_Analogique_L1_dB);
    //tefData.Niveau_Emission_Ligne_Analogique_L2_dB = checkFieldInRange(tefData.Niveau_Emission_Ligne_Analogique_L2_dB, 'Niveau_Emission_Ligne_Analogique_L2_dB', tefDataDefault.Niveau_Emission_Ligne_Analogique_L2_dB);

    tefData.Panneau_solaire = checkFieldInList(tefData.Panneau_solaire, 'Panneau_solaire', tefDataDefault.Panneau_solaire);
    //tefData.Module_cle = checkFieldInList(tefData.Module_cle, 'Module_cle', tefDataDefault.Module_cle);
    //tefData.Type_Batterie = checkFieldInList(tefData.Type_Batterie, 'Type_Batterie', tefDataDefault.Type_Batterie);


    tefData.Extintion_Automatique_WiFi = checkFieldInList(tefData.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', tefDataDefault.Extintion_Automatique_WiFi);
    tefData.Extintion_Automatique_WiFi_min = checkFieldInRange(tefData.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', tefDataDefault.Extintion_Automatique_WiFi_min);
    tefData.Extintion_Automatique_Eth = checkFieldInList(tefData.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', tefDataDefault.Extintion_Automatique_Eth);
    tefData.Extintion_Automatique_Eth_min = checkFieldInRange(tefData.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', tefDataDefault.Extintion_Automatique_Eth_min);

    if (errorFields.length > 0) {
        return false;
    }
    return true;
};
checkNotEmpty = function (field, fieldName) {
    if (typeof field === 'undefined') {
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (field === '') {
            errorFields.push({'field': fieldName, 'value': 'error_vide'});
        }
    }
};
inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};
checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};
checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
