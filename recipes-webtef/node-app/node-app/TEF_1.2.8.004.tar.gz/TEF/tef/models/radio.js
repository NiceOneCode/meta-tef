/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var tefData;
var tefDataDefault = null;
var errorFields;
exports.init = function (objData) {
    tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/radio.ini', 'utf-8'));
    errorFields = [];
    if (objData === false) {
        // no previous data defined,
        // so setting default values
        /*if (tefDataDefault === null) {
            tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/radio.ini', 'utf-8'));
        }*/
        tefData = {
            'Typologie_TEF': tefDataDefault.Typologie_TEF,
            'Nom_Identifiant': tefDataDefault.Nom_Identifiant,
            'Temps_Duree_Fixe_TMAX': tefDataDefault.Temps_Duree_Fixe_TMAX.default,
            'Temps_Anti_Bavard_TAB': tefDataDefault.Temps_Anti_Bavard_TAB.default,
            'Temps_Anti_Bavard_TAB_sec': tefDataDefault.Temps_Anti_Bavard_TAB_sec.default,
            'Temps_Attente_Message_Connection_sec': tefDataDefault.Temps_Attente_Message_Connection_sec.default,
            'Temps_Mise_A_Repos_No_Rep_sec': tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec.default,
            'Modalite_Communication': tefDataDefault.Modalite_Communication.default,
            'Nombre_Type_Cartes_SIM': tefDataDefault.Nombre_Type_Cartes_SIM.default,
            'Reseau_Principal': tefDataDefault.Reseau_Principal.default,
            'Reseau_Secours': tefDataDefault.Reseau_Secours.default,
            'Numero_Fonctionnel': tefDataDefault.Numero_Fonctionnel.default,
            'Code_Maintenance_Distance': tefDataDefault.Code_Maintenance_Distance.default,
            'Numero_Bouton_1': tefDataDefault.Numero_Bouton_1.default,
            'Numero_Bouton_2': tefDataDefault.Numero_Bouton_2.default,
            'Numero_Bouton_3': tefDataDefault.Numero_Bouton_3.default,
            'Cascade_Appels': tefDataDefault.Cascade_Appels.default,
            'Temps_Attente_sec': tefDataDefault.Temps_Attente_sec.default,
            'Priorite_Appel_1': tefDataDefault.Priorite_Appel_1.default,
            'Numeros_1_Appel_1': tefDataDefault.Numeros_1_Appel_1.default,
            'Numeros_2_Appel_1': tefDataDefault.Numeros_2_Appel_1.default,
            'Numeros_3_Appel_1': tefDataDefault.Numeros_3_Appel_1.default,
            'Numeros_4_Appel_1': tefDataDefault.Numeros_4_Appel_1.default,
            'Numeros_5_Appel_1': tefDataDefault.Numeros_5_Appel_1.default,
            'Numeros_6_Appel_1': tefDataDefault.Numeros_6_Appel_1.default,
            'Numeros_7_Appel_1': tefDataDefault.Numeros_7_Appel_1.default,
            'Numeros_8_Appel_1': tefDataDefault.Numeros_8_Appel_1.default,
            'Priorite_Appel_2': tefDataDefault.Priorite_Appel_2.default,
            'Numeros_1_Appel_2': tefDataDefault.Numeros_1_Appel_2.default,
            'Numeros_2_Appel_2': tefDataDefault.Numeros_2_Appel_2.default,
            'Numeros_3_Appel_2': tefDataDefault.Numeros_3_Appel_2.default,
            'Numeros_4_Appel_2': tefDataDefault.Numeros_4_Appel_2.default,
            'Numeros_5_Appel_2': tefDataDefault.Numeros_5_Appel_2.default,
            'Numeros_6_Appel_2': tefDataDefault.Numeros_6_Appel_2.default,
            'Numeros_7_Appel_2': tefDataDefault.Numeros_7_Appel_2.default,
            'Numeros_8_Appel_2': tefDataDefault.Numeros_8_Appel_2.default,
            'Priorite_Appel_3': tefDataDefault.Priorite_Appel_3.default,
            'Numeros_1_Appel_3': tefDataDefault.Numeros_1_Appel_3.default,
            'Numeros_2_Appel_3': tefDataDefault.Numeros_2_Appel_3.default,
            'Numeros_3_Appel_3': tefDataDefault.Numeros_3_Appel_3.default,
            'Numeros_4_Appel_3': tefDataDefault.Numeros_4_Appel_3.default,
            'Numeros_5_Appel_3': tefDataDefault.Numeros_5_Appel_3.default,
            'Numeros_6_Appel_3': tefDataDefault.Numeros_6_Appel_3.default,
            'Numeros_7_Appel_3': tefDataDefault.Numeros_7_Appel_3.default,
            'Numeros_8_Appel_3': tefDataDefault.Numeros_8_Appel_3.default,
            'Temps_Commutation_Radio_min': tefDataDefault.Temps_Commutation_Radio_min.default,
            'Attente_de_Connexion': tefDataDefault.Attente_de_Connexion.default,
            'Pas_Confirme_de_Connexion': tefDataDefault.Pas_Confirme_de_Connexion.default,
            'Raccroche': tefDataDefault.Raccroche.default,
            'Contact_Sortie_1': tefDataDefault.Contact_Sortie_1.default,
            'Contact_Sortie_1_Denomination': tefDataDefault.Contact_Sortie_1_Denomination.default,
            'Contact_Sortie_1_Numero_SMS': tefDataDefault.Contact_Sortie_1_Numero_SMS.default,
            'Contact_Sortie_1_Etat': tefDataDefault.Contact_Sortie_1_Etat.default,
            'Contact_Sortie_2': tefDataDefault.Contact_Sortie_2.default,
            'Contact_Sortie_2_Denomination': tefDataDefault.Contact_Sortie_2_Denomination.default,
            'Contact_Sortie_2_Numero_SMS': tefDataDefault.Contact_Sortie_2_Numero_SMS.default,
            'Contact_Sortie_2_Etat': tefDataDefault.Contact_Sortie_2_Etat.default,
            'Contact_Sortie_3': tefDataDefault.Contact_Sortie_3.default,
            'Contact_Sortie_3_Denomination': tefDataDefault.Contact_Sortie_3_Denomination.default,
            'Contact_Sortie_3_Numero_SMS': tefDataDefault.Contact_Sortie_3_Numero_SMS.default,
            'Contact_Sortie_3_Etat': tefDataDefault.Contact_Sortie_3_Etat.default,
            'Contact_Sortie_4': tefDataDefault.Contact_Sortie_4.default,
            'Contact_Sortie_4_Denomination': tefDataDefault.Contact_Sortie_4_Denomination.default,
            'Contact_Sortie_4_Numero_SMS': tefDataDefault.Contact_Sortie_4_Numero_SMS.default,
            'Contact_Sortie_4_Etat': tefDataDefault.Contact_Sortie_4_Etat.default,
            'Contact_Entree_1': tefDataDefault.Contact_Entree_1.default,
            'Contact_Entree_1_Denomination': tefDataDefault.Contact_Entree_1_Denomination.default,
            'Contact_Entree_1_Numero_SMS': tefDataDefault.Contact_Entree_1_Numero_SMS.default,
            'Contact_Entree_1_Etat': tefDataDefault.Contact_Entree_1_Etat.default,
            'Contact_Entree_2': tefDataDefault.Contact_Entree_2.default,
            'Contact_Entree_2_Denomination': tefDataDefault.Contact_Entree_2_Denomination.default,
            'Contact_Entree_2_Numero_SMS': tefDataDefault.Contact_Entree_2_Numero_SMS.default,
            'Contact_Entree_2_Etat': tefDataDefault.Contact_Entree_2_Etat.default,
            'Contact_Entree_3': tefDataDefault.Contact_Entree_3.default,
            'Contact_Entree_3_Denomination': tefDataDefault.Contact_Entree_3_Denomination.default,
            'Contact_Entree_3_Numero_SMS': tefDataDefault.Contact_Entree_3_Numero_SMS.default,
            'Contact_Entree_3_Etat': tefDataDefault.Contact_Entree_3_Etat.default,
            'Contact_Entree_4': tefDataDefault.Contact_Entree_4.default,
            'Contact_Entree_4_Denomination': tefDataDefault.Contact_Entree_4_Denomination.default,
            'Contact_Entree_4_Numero_SMS': tefDataDefault.Contact_Entree_4_Numero_SMS.default,
            'Contact_Entree_4_Etat': tefDataDefault.Contact_Entree_4_Etat.default,
            'Modalite_Reponse': tefDataDefault.Modalite_Reponse.default,
            'Nombre_Trains_Sonnerie': tefDataDefault.Nombre_Trains_Sonnerie.default,
            'Sonnerie': tefDataDefault.Sonnerie.default,
            'Duree_Sonnerie_Interieure_msec': tefDataDefault.Duree_Sonnerie_Interieure_msec.default,
            'Duree_Extention_Sonnerie_msec': tefDataDefault.Duree_Extention_Sonnerie_msec.default,
            'Extintion_Automatique_WiFi': tefDataDefault.Extintion_Automatique_WiFi.default,
            'Extintion_Automatique_WiFi_min': tefDataDefault.Extintion_Automatique_WiFi_min.default,
            'Extintion_Automatique_Eth': tefDataDefault.Extintion_Automatique_Eth.default,
            'Extintion_Automatique_Eth_min': tefDataDefault.Extintion_Automatique_Eth_min.default,
            'Mot_De_Passe': tefDataDefault.Mot_De_Passe,
        };
    } else {
        tefData = objData;
    }
};
exports.getData = function () {
    return tefData;
};
exports.getDataDefault = function() {
    return tefDataDefault;
};
exports.getErrorFields = function () {
    return errorFields;
};
exports.hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
exports.getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};
exports.export = function () {
    var obj = {
        'Typologie_TEF': tefData.Typologie_TEF,
        'Nom_Identifiant': tefData.Nom_Identifiant,
        'Temps_Duree_Fixe_TMAX': tefData.Temps_Duree_Fixe_TMAX,
        'Temps_Anti_Bavard_TAB': tefData.Temps_Anti_Bavard_TAB,
        'Temps_Anti_Bavard_TAB_sec': tefData.Temps_Anti_Bavard_TAB_sec,
        'Temps_Attente_Message_Connection_sec': tefData.Temps_Attente_Message_Connection_sec,
        'Temps_Mise_A_Repos_No_Rep_sec': tefData.Temps_Mise_A_Repos_No_Rep_sec,
        'Modalite_Communication': tefData.Modalite_Communication,
        'Nombre_Type_Cartes_SIM': tefData.Nombre_Type_Cartes_SIM,
        'Reseau_Principal': tefData.Reseau_Principal,
        'Reseau_Secours': tefData.Reseau_Secours,
        'Numero_Fonctionnel': tefData.Numero_Fonctionnel,
        'Code_Maintenance_Distance': tefData.Code_Maintenance_Distance,
        'Numero_Bouton_1': tefData.Numero_Bouton_1,
        'Numero_Bouton_2': tefData.Numero_Bouton_2,
        'Numero_Bouton_3': tefData.Numero_Bouton_3,
        'Cascade_Appels': tefData.Cascade_Appels,
        'Temps_Attente_sec': tefData.Temps_Attente_sec,
        'Priorite_Appel_1': tefData.Priorite_Appel_1,
        'Numeros_1_Appel_1': tefData.Numeros_1_Appel_1,
        'Numeros_2_Appel_1': tefData.Numeros_2_Appel_1,
        'Numeros_3_Appel_1': tefData.Numeros_3_Appel_1,
        'Numeros_4_Appel_1': tefData.Numeros_4_Appel_1,
        'Numeros_5_Appel_1': tefData.Numeros_5_Appel_1,
        'Numeros_6_Appel_1': tefData.Numeros_6_Appel_1,
        'Numeros_7_Appel_1': tefData.Numeros_7_Appel_1,
        'Numeros_8_Appel_1': tefData.Numeros_8_Appel_1,
        'Priorite_Appel_2': tefData.Priorite_Appel_2,
        'Numeros_1_Appel_2': tefData.Numeros_1_Appel_2,
        'Numeros_2_Appel_2': tefData.Numeros_2_Appel_2,
        'Numeros_3_Appel_2': tefData.Numeros_3_Appel_2,
        'Numeros_4_Appel_2': tefData.Numeros_4_Appel_2,
        'Numeros_5_Appel_2': tefData.Numeros_5_Appel_2,
        'Numeros_6_Appel_2': tefData.Numeros_6_Appel_2,
        'Numeros_7_Appel_2': tefData.Numeros_7_Appel_2,
        'Numeros_8_Appel_2': tefData.Numeros_8_Appel_2,
        'Priorite_Appel_3': tefData.Priorite_Appel_3,
        'Numeros_1_Appel_3': tefData.Numeros_1_Appel_3,
        'Numeros_2_Appel_3': tefData.Numeros_2_Appel_3,
        'Numeros_3_Appel_3': tefData.Numeros_3_Appel_3,
        'Numeros_4_Appel_3': tefData.Numeros_4_Appel_3,
        'Numeros_5_Appel_3': tefData.Numeros_5_Appel_3,
        'Numeros_6_Appel_3': tefData.Numeros_6_Appel_3,
        'Numeros_7_Appel_3': tefData.Numeros_7_Appel_3,
        'Numeros_8_Appel_3': tefData.Numeros_8_Appel_3,
        'Temps_Commutation_Radio_min': tefData.Temps_Commutation_Radio_min,
        'Attente_de_Connexion': tefData.Attente_de_Connexion,
        'Pas_Confirme_de_Connexion': tefData.Pas_Confirme_de_Connexion,
        'Raccroche': tefData.Raccroche,
        'Contact_Sortie_1': tefData.Contact_Sortie_1,
        'Contact_Sortie_1_Denomination': tefData.Contact_Sortie_1_Denomination,
        'Contact_Sortie_1_Numero_SMS': tefData.Contact_Sortie_1_Numero_SMS,
        'Contact_Sortie_1_Etat': tefData.Contact_Sortie_1_Etat,
        'Contact_Sortie_2': tefData.Contact_Sortie_2,
        'Contact_Sortie_2_Denomination': tefData.Contact_Sortie_2_Denomination,
        'Contact_Sortie_2_Numero_SMS': tefData.Contact_Sortie_2_Numero_SMS,
        'Contact_Sortie_2_Etat': tefData.Contact_Sortie_2_Etat,
        'Contact_Sortie_3': tefData.Contact_Sortie_3,
        'Contact_Sortie_3_Denomination': tefData.Contact_Sortie_3_Denomination,
        'Contact_Sortie_3_Numero_SMS': tefData.Contact_Sortie_3_Numero_SMS,
        'Contact_Sortie_3_Etat': tefData.Contact_Sortie_3_Etat,
        'Contact_Sortie_4': tefData.Contact_Sortie_4,
        'Contact_Sortie_4_Denomination': tefData.Contact_Sortie_4_Denomination,
        'Contact_Sortie_4_Numero_SMS': tefData.Contact_Sortie_4_Numero_SMS,
        'Contact_Sortie_4_Etat': tefData.Contact_Sortie_4_Etat,
        'Contact_Entree_1': tefData.Contact_Entree_1,
        'Contact_Entree_1_Denomination': tefData.Contact_Entree_1_Denomination,
        'Contact_Entree_1_Numero_SMS': tefData.Contact_Entree_1_Numero_SMS,
        'Contact_Entree_1_Etat': tefData.Contact_Entree_1_Etat,
        'Contact_Entree_2': tefData.Contact_Entree_2,
        'Contact_Entree_2_Denomination': tefData.Contact_Entree_2_Denomination,
        'Contact_Entree_2_Numero_SMS': tefData.Contact_Entree_2_Numero_SMS,
        'Contact_Entree_2_Etat': tefData.Contact_Entree_2_Etat,
        'Contact_Entree_3': tefData.Contact_Entree_3,
        'Contact_Entree_3_Denomination': tefData.Contact_Entree_3_Denomination,
        'Contact_Entree_3_Numero_SMS': tefData.Contact_Entree_3_Numero_SMS,
        'Contact_Entree_3_Etat': tefData.Contact_Entree_3_Etat,
        'Contact_Entree_4': tefData.Contact_Entree_4,
        'Contact_Entree_4_Denomination': tefData.Contact_Entree_4_Denomination,
        'Contact_Entree_4_Numero_SMS': tefData.Contact_Entree_4_Numero_SMS,
        'Contact_Entree_4_Etat': tefData.Contact_Entree_4_Etat,
        'Modalite_Reponse': tefData.Modalite_Reponse,
        'Nombre_Trains_Sonnerie': tefData.Nombre_Trains_Sonnerie,
        'Sonnerie': tefData.Sonnerie,
        'Duree_Sonnerie_Interieure_msec': tefData.Duree_Sonnerie_Interieure_msec,
        'Duree_Extention_Sonnerie_msec': tefData.Duree_Extention_Sonnerie_msec,
        'Extintion_Automatique_WiFi': tefData.Extintion_Automatique_WiFi,
        'Extintion_Automatique_WiFi_min': tefData.Extintion_Automatique_WiFi_min,
        'Extintion_Automatique_Eth': tefData.Extintion_Automatique_Eth,
        'Extintion_Automatique_Eth_min': tefData.Extintion_Automatique_Eth_min,
        //'Mot_De_Passe': tefData.Mot_De_Passe,
    };
    return obj;
};
exports.normalize = function () {
    // Setting initial data according to checkboxes with unchecked values
    // (unchecked checkboxes are not trasmitted in HTTP POST request).
    if (typeof tefData.Temps_Duree_Fixe_TMAX === 'undefined') {
        tefData.Temps_Duree_Fixe_TMAX = 'pas_activee';
    }
    if (typeof tefData.Temps_Anti_Bavard_TAB === 'undefined') {
        tefData.Temps_Anti_Bavard_TAB = 'pas_activee';
    }
    if (typeof tefData.Modalite_Communication === 'undefined') {
        tefData.Modalite_Communication = 'half_duplex';
    }
    if (typeof tefData.Detection_Occupation_Liberation === 'undefined') {
        tefData.Detection_Occupation_Liberation = 'pas_activee';
    }
    if (typeof tefData.Extintion_Automatique_WiFi === 'undefined') {
        tefData.Extintion_Automatique_WiFi = 'pas_activee';
    }
    if (typeof tefData.Extintion_Automatique_Eth === 'undefined') {
        tefData.Extintion_Automatique_Eth = 'pas_activee';
    }
};
exports.validate = function () {

    if (tefDataDefault === null) {
        tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/radio.ini', 'utf-8'));
    }

    checkNotEmpty(tefData.Nom_Identifiant, 'Nom_Identifiant');

    tefData.Temps_Duree_Fixe_TMAX = checkFieldInList(tefData.Temps_Duree_Fixe_TMAX, 'Temps_Duree_Fixe_TMAX', tefDataDefault.Temps_Duree_Fixe_TMAX);
    tefData.Temps_Anti_Bavard_TAB = checkFieldInList(tefData.Temps_Anti_Bavard_TAB, 'Temps_Anti_Bavard_TAB', tefDataDefault.Temps_Anti_Bavard_TAB);
    tefData.Temps_Anti_Bavard_TAB_sec = checkFieldInRange(tefData.Temps_Anti_Bavard_TAB_sec, 'Temps_Anti_Bavard_TAB_sec', tefDataDefault.Temps_Anti_Bavard_TAB_sec);
    tefData.Temps_Attente_Message_Connection_sec = checkFieldInRange(tefData.Temps_Attente_Message_Connection_sec, 'Temps_Attente_Message_Connection_sec', tefDataDefault.Temps_Attente_Message_Connection_sec);
    tefData.Temps_Mise_A_Repos_No_Rep_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_sec, 'Temps_Mise_A_Repos_No_Rep_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec);
    tefData.Modalite_Communication = checkFieldInList(tefData.Modalite_Communication, 'Modalite_Communication', tefDataDefault.Modalite_Communication);
    tefData.Nombre_Type_Cartes_SIM = checkFieldInList(tefData.Nombre_Type_Cartes_SIM, 'Nombre_Type_Cartes_SIM', tefDataDefault.Nombre_Type_Cartes_SIM);
//            tefData.Reseau_Principal = tefData.Reseau_Principal
//            tefData.Reseau_Secours =tefData.Reseau_Secours;
//            tefData.Numero_Fonctionnel=tefData.Numero_Fonctionnel;
//            tefData.Code_Maintenance_Distance=tefData.Code_Maintenance_Distance;
//            tefData.Numero_Bouton_1=tefData.Numero_Bouton_1;
//            tefData.Numero_Bouton_2=tefData.Numero_Bouton_2;
//            tefData.Numero_Bouton_3=tefData.Numero_Bouton_3;
    tefData.Cascade_Appels = checkFieldInList(tefData.Cascade_Appels, 'Cascade_Appels', tefDataDefault.Cascade_Appels);
    tefData.Temps_Attente_sec = checkFieldInRange(tefData.Temps_Attente_sec, 'Temps_Attente_sec', tefDataDefault.Temps_Attente_sec);
    tefData.Priorite_Appel_1 = checkFieldInList(tefData.Priorite_Appel_1, 'Priorite_Appel_1', tefDataDefault.Priorite_Appel_1);
//                tefData.Numeros_1_Appel_1 = tefData.Numeros_1_Appel_1;
//                tefData.Numeros_2_Appel_1 = tefData.Numeros_2_Appel_1;
//                tefData.Numeros_3_Appel_1 = tefData.Numeros_3_Appel_1;
//                tefData.Numeros_4_Appel_1 = tefData.Numeros_4_Appel_1;
//                tefData.Numeros_5_Appel_1 = tefData.Numeros_5_Appel_1;
//                tefData.Numeros_6_Appel_1 = tefData.Numeros_6_Appel_1;
//                tefData.Numeros_7_Appel_1 = tefData.Numeros_7_Appel_1;
//                tefData.Numeros_8_Appel_1 = tefData.Numeros_8_Appel_1;
    tefData.Priorite_Appel_2 = checkFieldInList(tefData.Priorite_Appel_2, 'Priorite_Appel_2', tefDataDefault.Priorite_Appel_2);
//                tefData.Numeros_1_Appel_2 = tefData.Numeros_1_Appel_2,
//                tefData.Numeros_2_Appel_2 = tefData.Numeros_2_Appel_2,
//                tefData.Numeros_3_Appel_2 = tefData.Numeros_3_Appel_2,
//                tefData.Numeros_4_Appel_2 = tefData.Numeros_4_Appel_2,
//                tefData.Numeros_5_Appel_2 = tefData.Numeros_5_Appel_2,
//                tefData.Numeros_6_Appel_2 = tefData.Numeros_6_Appel_2,
//                tefData.Numeros_7_Appel_2 = tefData.Numeros_7_Appel_2,
//                tefData.Numeros_8_Appel_2 = tefData.Numeros_8_Appel_2,
    tefData.Priorite_Appel_3 = checkFieldInList(tefData.Priorite_Appel_3, 'Priorite_Appel_3', tefDataDefault.Priorite_Appel_3);
//                tefData.Numeros_1_Appel_3 = tefData.Numeros_1_Appel_3,
//                tefData.Numeros_2_Appel_3 = tefData.Numeros_2_Appel_3,
//                tefData.Numeros_3_Appel_3 = tefData.Numeros_3_Appel_3,
//                tefData.Numeros_4_Appel_3 = tefData.Numeros_4_Appel_3,
//                tefData.Numeros_5_Appel_3 = tefData.Numeros_5_Appel_3,
//                tefData.Numeros_6_Appel_3 = tefData.Numeros_6_Appel_3,
//                tefData.Numeros_7_Appel_3 = tefData.Numeros_7_Appel_3,
//                tefData.Numeros_8_Appel_3 = tefData.Numeros_8_Appel_3,
    tefData.Temps_Commutation_Radio_min = checkFieldInRange(tefData.Temps_Commutation_Radio_min, 'Temps_Commutation_Radio_min', tefDataDefault.Temps_Commutation_Radio_min);
    tefData.Attente_de_Connexion = checkFieldInList(tefData.Attente_de_Connexion, 'Attente_de_Connexion', tefDataDefault.Attente_de_Connexion);
    tefData.Pas_Confirme_de_Connexion = checkFieldInList(tefData.Pas_Confirme_de_Connexion, 'Pas_Confirme_de_Connexion', tefDataDefault.Pas_Confirme_de_Connexion);
    tefData.Raccroche = checkFieldInList(tefData.Raccroche, 'Raccroche', tefDataDefault.Raccroche);
    tefData.Contact_Sortie_1 = checkFieldInList(tefData.Contact_Sortie_1, 'Contact_Sortie_1', tefDataDefault.Contact_Sortie_1);
//                tefData.Contact_Sortie_1_Denomination = tefData.Contact_Sortie_1_Denomination;
//                tefData.Contact_Sortie_1_Numero_SMS = tefData.Contact_Sortie_1_Numero_SMS;
    tefData.Contact_Sortie_1_Etat = checkFieldInList(tefData.Contact_Sortie_1_Etat, 'Contact_Sortie_1_Etat', tefDataDefault.Contact_Sortie_1_Etat);
    tefData.Contact_Sortie_2 = checkFieldInList(tefData.Contact_Sortie_2, 'Contact_Sortie_2', tefDataDefault.Contact_Sortie_2);
//                tefData.Contact_Sortie_2_Denomination = tefData.Contact_Sortie_2_Denomination;
//                tefData.Contact_Sortie_2_Numero_SMS = tefData.Contact_Sortie_2_Numero_SMS;
    tefData.Contact_Sortie_2_Etat = checkFieldInList(tefData.Contact_Sortie_2_Etat, 'Contact_Sortie_2_Etat', tefDataDefault.Contact_Sortie_2_Etat);
    tefData.Contact_Sortie_3 = checkFieldInList(tefData.Contact_Sortie_3, 'Contact_Sortie_3', tefDataDefault.Contact_Sortie_3);
//                tefData.Contact_Sortie_3_Denomination = tefData.Contact_Sortie_3_Denomination;
//                tefData.Contact_Sortie_3_Numero_SMS = tefData.Contact_Sortie_3_Numero_SMS;
    tefData.Contact_Sortie_3_Etat = checkFieldInList(tefData.Contact_Sortie_3_Etat, 'Contact_Sortie_3_Etat', tefDataDefault.Contact_Sortie_3_Etat);
    tefData.Contact_Sortie_4 = checkFieldInList(tefData.Contact_Sortie_4, 'Contact_Sortie_4', tefDataDefault.Contact_Sortie_4);
//                tefData.Contact_Sortie_4_Denomination = tefData.Contact_Sortie_4_Denomination;
//                tefData.Contact_Sortie_4_Numero_SMS = tefData.Contact_Sortie_4_Numero_SMS;
    tefData.Contact_Sortie_4_Etat = checkFieldInList(tefData.Contact_Sortie_4_Etat, 'Contact_Sortie_4_Etat', tefDataDefault.Contact_Sortie_4_Etat);
    tefData.Contact_Entree_1 = checkFieldInList(tefData.Contact_Entree_1, 'Contact_Entree_1', tefDataDefault.Contact_Entree_1);
//                tefData.Contact_Entree_1_Denomination = tefData.Contact_Entree_1_Denomination;
//                tefData.Contact_Entree_1_Numero_SMS = tefData.Contact_Entree_1_Numero_SMS;
    tefData.Contact_Entree_1_Etat = checkFieldInList(tefData.Contact_Entree_1_Etat, 'Contact_Entree_1_Etat', tefDataDefault.Contact_Entree_1_Etat);
    tefData.Contact_Entree_2 = checkFieldInList(tefData.Contact_Entree_2, 'Contact_Entree_2', tefDataDefault.Contact_Entree_2);
//                tefData.Contact_Entree_2_Denomination = tefData.Contact_Entree_2_Denomination;
//                tefData.Contact_Entree_2_Numero_SMS = tefData.Contact_Entree_2_Numero_SMS;
    tefData.Contact_Entree_2_Etat = checkFieldInList(tefData.Contact_Entree_2_Etat, 'Contact_Entree_2_Etat', tefDataDefault.Contact_Entree_2_Etat);
    tefData.Contact_Entree_3 = checkFieldInList(tefData.Contact_Entree_3, 'Contact_Entree_3', tefDataDefault.Contact_Entree_3);
//                tefData.Contact_Entree_3_Denomination = tefData.Contact_Entree_3_Denomination;
//                tefData.Contact_Entree_3_Numero_SMS = tefData.Contact_Entree_3_Numero_SMS;
    tefData.Contact_Entree_3_Etat = checkFieldInList(tefData.Contact_Entree_3_Etat, 'Contact_Entree_3_Etat', tefDataDefault.Contact_Entree_3_Etat);
    tefData.Contact_Entree_4 = checkFieldInList(tefData.Contact_Entree_4, 'Contact_Entree_4', tefDataDefault.Contact_Entree_4);
//                tefData.Contact_Entree_4_Denomination = tefData.Contact_Entree_4_Denomination;
//                tefData.Contact_Entree_4_Numero_SMS = tefData.Contact_Entree_4_Numero_SMS;
    tefData.Contact_Entree_4_Etat = checkFieldInList(tefData.Contact_Entree_4_Etat, 'Contact_Entree_4_Etat', tefDataDefault.Contact_Entree_4_Etat);
    tefData.Modalite_Reponse = checkFieldInList(tefData.Modalite_Reponse, 'Modalite_Reponse', tefDataDefault.Modalite_Reponse);
    tefData.Nombre_Trains_Sonnerie = checkFieldInRange(tefData.Nombre_Trains_Sonnerie, 'Nombre_Trains_Sonnerie', tefDataDefault.Nombre_Trains_Sonnerie);
    tefData.Sonnerie = checkFieldInList(tefData.Sonnerie, 'Sonnerie', tefDataDefault.Sonnerie);
    tefData.Duree_Sonnerie_Interieure_msec = checkFieldInRange(tefData.Duree_Sonnerie_Interieure_msec, 'Duree_Sonnerie_Interieure_msec', tefDataDefault.Duree_Sonnerie_Interieure_msec);
    tefData.Duree_Extention_Sonnerie_msec = checkFieldInRange(tefData.Duree_Extention_Sonnerie_msec, 'Duree_Extention_Sonnerie_msec', tefDataDefault.Duree_Extention_Sonnerie_msec);
    tefData.Extintion_Automatique_WiFi = checkFieldInList(tefData.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', tefDataDefault.Extintion_Automatique_WiFi);
    tefData.Extintion_Automatique_WiFi_min = checkFieldInRange(tefData.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', tefDataDefault.Extintion_Automatique_WiFi_min);
    tefData.Extintion_Automatique_Eth = checkFieldInList(tefData.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', tefDataDefault.Extintion_Automatique_Eth);
    tefData.Extintion_Automatique_Eth_min = checkFieldInRange(tefData.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', tefDataDefault.Extintion_Automatique_Eth_min);
    if (errorFields.length > 0) {
        return false;
    }
    return true;
};
checkNotEmpty = function (field, fieldName) {
    if (typeof field === 'undefined') {
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (field === '') {
            errorFields.push({'field': fieldName, 'value': 'error_vide'});
        }
    }
};
inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};
checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};
checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
