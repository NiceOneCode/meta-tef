/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var tefmanreg;
var tefmanregDefault = null;
var errorFields;

exports.init = function (objData) {
    errorFields = [];
    if (objData === false) {
        // no previous data defined,
        // so setting default values
        if (tefmanregDefault === null) {
            tefmanregDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/manreg.ini', 'utf-8'));
        }
        tefmanreg = {
            'Type_de_cable': tefmanregDefault.Type_de_cable.default,
            'Niveau_de_sortie': tefmanregDefault.Niveau_de_sortie.default,
            'Niveau_entrant': tefmanregDefault.Niveau_entrant.default,
            'Mic_on': 1,
            'Audio_on':1,
            'Alfa':0,
        };
    } else {
        tefmanreg = objData;
    }
};

exports.setMicOFF=function()
{
      tefmanreg.Mic_on=1;
};
exports.setMicON=function()
{
      tefmanreg.Mic_on=0;
};

exports.setAudioOFF=function()
{
      tefmanreg.Audio_on=1;
};
exports.setAudioON=function()
{
      tefmanreg.Audio_on=0;
};
exports.setMicLevel=function(level)
{
      tefmanreg.Niveau_de_sortie=level;
      var num=parseInt(level, 10);

      tefmanreg.Alfa=(-1*(num + 15));
    //  console.log ("###### tefmanreg.Alfa" + tefmanreg.Alfa  );
};
exports.setAudioLevel=function(level)
{
      tefmanreg.Niveau_entrant=level;
};



exports.getData = function () {
    return tefmanreg;
};
exports.getErrorFields = function () {
    return errorFields;
};
exports.hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
exports.getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};
exports.export = function () {
    var obj = {
        'Type_de_cable': tefmanreg.Type_de_cable,
        'Niveau_de_sortie': tefmanreg.Niveau_de_sortie,
        'Niveau_entrant': tefmanreg.Niveau_entrant,
        'Mic_on': tefmanreg.Mic_on,
        'Audio_on':tefmanreg.Audio_on,
    };
    return obj;
};
exports.normalize = function () {

};
exports.validate = function () {

    // if (tefDataDefault === null) {
    //     tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibccla.ini', 'utf-8'));
    // }
    //
    // checkNotEmpty(tefData.Nom_Identifiant, 'Nom_Identifiant');
    // tefData.Temps_Duree_Fixe_TMAX = checkFieldInList(tefData.Temps_Duree_Fixe_TMAX, 'Temps_Duree_Fixe_TMAX', tefDataDefault.Temps_Duree_Fixe_TMAX);
    // tefData.Temps_Anti_Bavard_TAB = checkFieldInList(tefData.Temps_Anti_Bavard_TAB, 'Temps_Anti_Bavard_TAB', tefDataDefault.Temps_Anti_Bavard_TAB);
    // tefData.Temps_Anti_Bavard_TAB_sec = checkFieldInRange(tefData.Temps_Anti_Bavard_TAB_sec, 'Temps_Anti_Bavard_TAB_sec', tefDataDefault.Temps_Anti_Bavard_TAB_sec);
    // tefData.Temps_Mise_A_Repos_No_Rep_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_sec, 'Temps_Mise_A_Repos_No_Rep_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec);
    // tefData.Temps_Attente_Code_Deblocage_Clavier_sec = checkFieldInRange(tefData.Temps_Attente_Code_Deblocage_Clavier_sec, 'Temps_Attente_Code_Deblocage_Clavier_sec', tefDataDefault.Temps_Attente_Code_Deblocage_Clavier_sec);
    // tefData.Temporisation_Attente_Numerotation_sec = checkFieldInRange(tefData.Temporisation_Attente_Numerotation_sec, 'Temporisation_Attente_Numerotation_sec', tefDataDefault.Temporisation_Attente_Numerotation_sec);
    // checkNotEmpty(tefData.Code_Deblocage, 'Code_Deblocage');
    // tefData.Activation_Tonalite_Invitation_Transmettre = checkFieldInList(tefData.Activation_Tonalite_Invitation_Transmettre, 'Activation_Tonalite_Invitation_Transmettre', tefDataDefault.Activation_Tonalite_Invitation_Transmettre);
    // tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec = checkFieldInRange(tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec, 'Temporisation_Attente_Tonalite_Invitation_Transmettre_msec', tefDataDefault.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec);
    // tefData.Modalite_Communication = checkFieldInList(tefData.Modalite_Communication, 'Modalite_Communication', tefDataDefault.Modalite_Communication);
    // tefData.Detection_Occupation_Liberation = checkFieldInList(tefData.Detection_Occupation_Liberation, 'Detection_Occupation_Liberation', tefDataDefault.Detection_Occupation_Liberation);
    // tefData.Temps_Mise_A_Repos_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_sec, 'Temps_Mise_A_Repos_sec', tefDataDefault.Temps_Mise_A_Repos_sec);
    // tefData.Modalite_Reponse = checkFieldInList(tefData.Modalite_Reponse, 'Modalite_Reponse', tefDataDefault.Modalite_Reponse);
    // tefData.Nombre_Trains_Sonnerie = checkFieldInRange(tefData.Nombre_Trains_Sonnerie, 'Nombre_Trains_Sonnerie', tefDataDefault.Nombre_Trains_Sonnerie);
    // tefData.Niveau_Emission_Ligne_Analogique_dB = checkFieldInRange(tefData.Niveau_Emission_Ligne_Analogique_dB, 'Niveau_Emission_Ligne_Analogique_dB', tefDataDefault.Niveau_Emission_Ligne_Analogique_dB);
    // tefData.Duree_Signalisation_Associee_Bouton_R_msec = checkFieldInRange(tefData.Duree_Signalisation_Associee_Bouton_R_msec, 'Duree_Signalisation_Associee_Bouton_R_msec', tefDataDefault.Duree_Signalisation_Associee_Bouton_R_msec);
    // tefData.Duree_Mark_msec = checkFieldInRange(tefData.Duree_Mark_msec, 'Duree_Mark_msec', tefDataDefault.Duree_Mark_msec);
    // tefData.Duree_Space_msec = checkFieldInRange(tefData.Duree_Space_msec, 'Duree_Space_msec', tefDataDefault.Duree_Space_msec);
    // tefData.Echelle = checkFieldInRange(tefData.Echelle, 'Echelle', tefDataDefault.Echelle);
    // tefData.Niveau_Emission_DTMF_dB = checkFieldInRange(tefData.Niveau_Emission_DTMF_dB, 'Niveau_Emission_DTMF_dB', tefDataDefault.Niveau_Emission_DTMF_dB);
    // tefData.Extintion_Automatique_WiFi = checkFieldInList(tefData.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', tefDataDefault.Extintion_Automatique_WiFi);
    // tefData.Extintion_Automatique_WiFi_min = checkFieldInRange(tefData.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', tefDataDefault.Extintion_Automatique_WiFi_min);
    // tefData.Extintion_Automatique_Eth = checkFieldInList(tefData.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', tefDataDefault.Extintion_Automatique_Eth);
    // tefData.Extintion_Automatique_Eth_min = checkFieldInRange(tefData.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', tefDataDefault.Extintion_Automatique_Eth_min);
    // if (errorFields.length > 0) {
    //     return false;
    // }
    return true;
};
checkNotEmpty = function (field, fieldName) {
    if (typeof field === 'undefined') {
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (field === '') {
            errorFields.push({'field': fieldName, 'value': 'error_vide'});
        }
    }
};
inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};
checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};
checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
