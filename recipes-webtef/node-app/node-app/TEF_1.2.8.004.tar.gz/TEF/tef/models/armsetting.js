/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var sys = require('util');
var exec = require('child_process').exec;

var local_armsettings_file    = __dirname + '/../database/local_settings.ini';
var default_armsetting_file   = __dirname + '/../database/default/armSettingsDefault.ini';


function puts(error, stdout, stderr) { sys.puts(stdout) }
//exec("ls -la", puts);
//exec("sync",puts);



var armSetting = null;
var armSettingDefault = null;
var armLocalDefault;
var errorFields;


exports.init = function (objData) {
    errorFields = [];
    if (objData === false)
    {

      if ( fs.existsSync(local_armsettings_file))
      {
        try
        {
            armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
        }
        catch(e)
        {
            armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
        }

      }
      else
      {
        armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
      }
      armSetting =
      {
            'Nom_Identifiant': armLocalDefault.Settings.Nom_Identifiant,
            'Extintion_Automatique_WiFi': armLocalDefault.Settings.Extintion_Automatique_WiFi,
            'Extintion_Automatique_WiFi_min': armLocalDefault.Settings.Extintion_Automatique_WiFi_min,
            'Extintion_Automatique_Eth': armLocalDefault.Settings.Extintion_Automatique_Eth,
            'Extintion_Automatique_Eth_min': armLocalDefault.Settings.Extintion_Automatique_Eth_min,
            'Niveau_de_sortie': armLocalDefault.Settings.Niveau_de_sortie,
            'Niveau_entrant': armLocalDefault.Settings.Niveau_entrant,
            'Mot_De_Passe': armLocalDefault.Settings.Mot_De_Passe,
        };
    } else {
        armSetting = objData;
    }
};

exports.save_arm_setting=function(tefData){

  if(armSetting == null)
  {
    armSetting =
    {
          'Nom_Identifiant':  tefData.Nom_Identifiant,
          'Extintion_Automatique_WiFi': tefData.Extintion_Automatique_WiFi,
          'Extintion_Automatique_WiFi_min': tefData.Extintion_Automatique_WiFi_min,
          'Extintion_Automatique_Eth': tefData.Extintion_Automatique_Eth,
          'Extintion_Automatique_Eth_min': tefData.Extintion_Automatique_Eth_min,
          'Niveau_de_sortie': tefData.Niveau_de_sortie,
          'Niveau_entrant': tefData.Niveau_entrant,
      };
  }
  else
  {
  armSetting.Nom_Identifiant = tefData.Nom_Identifiant;
  armSetting.Extintion_Automatique_WiFi = tefData.Extintion_Automatique_WiFi;
  armSetting.Extintion_Automatique_WiFi_min = tefData.Extintion_Automatique_WiFi_min;
  armSetting.Extintion_Automatique_Eth = tefData.Extintion_Automatique_Eth;
  armSetting.Extintion_Automatique_Eth_min = tefData.Extintion_Automatique_Eth_min;
  armSetting.Niveau_de_sortie = tefData.Niveau_de_sortie;
  armSetting.Niveau_entrant = tefData.Niveau_entrant;
}
  chkInter();  
  if(validate())
  {
      var local_Settings = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));

      local_Settings.Settings.Nom_Identifiant = armSetting.Nom_Identifiant;
      local_Settings.Settings.Extintion_Automatique_WiFi = armSetting.Extintion_Automatique_WiFi;
      local_Settings.Settings.Extintion_Automatique_WiFi_min = armSetting.Extintion_Automatique_WiFi_min;
      local_Settings.Settings.Extintion_Automatique_Eth = armSetting.Extintion_Automatique_Eth;
      local_Settings.Settings.Extintion_Automatique_Eth_min = armSetting.Extintion_Automatique_Eth_min;
      local_Settings.Settings.Niveau_de_sortie = armSetting.Niveau_de_sortie;
      local_Settings.Settings.Niveau_entrant = armSetting.Niveau_entrant;
      fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings.Settings, { section: 'Settings' }));
      exec("sync",puts);
      var timeout_data_halt;
      if (armSetting.Extintion_Automatique_Eth == 'activee'){
        timeout_data_halt = armSetting.Extintion_Automatique_Eth_min + " ";
      } else { timeout_data_halt = "0 " }
      if (armSetting.Extintion_Automatique_WiFi == 'activee'){
        timeout_data_halt += armSetting.Extintion_Automatique_WiFi_min + " ";
      } else { timeout_data_halt += "0 " }

      timeout_data_halt += "1";
      console.log("LAN shutdown status: ETH/WIFI/NODE_MODULE: " + timeout_data_halt);
      //fs.writeFileSync("/dev/dmg/wd_start", timeout_data_halt);
      exec("echo " + timeout_data_halt + " > /dev/dmg/wd_start",puts);

  }
};



getData = function () {
    return armSetting;
};

exports.getTimer = function () {
  var  lanS = 1440;
  var  wifS = 1440;
  if(armSetting.Extintion_Automatique_Eth == 'activee')
  {
     lanS = armSetting.Extintion_Automatique_Eth_min;
  }
  if(armSetting.Extintion_Automatique_WiFi=='activee')
  {
     wifS = armSetting.Extintion_Automatique_WiFi_min;
  }

  timers=
  {
      lan_min: lanS,
      wifi_min: wifS,
  }
  return timers;
};

exports.loadData = function (tefData, Tipo)
{
  tefData.Nom_Identifiant = armSetting.Nom_Identifiant;
  tefData.Extintion_Automatique_WiFi = armSetting.Extintion_Automatique_WiFi;
  tefData.Extintion_Automatique_WiFi_min = armSetting.Extintion_Automatique_WiFi_min;
  tefData.Extintion_Automatique_Eth = armSetting.Extintion_Automatique_Eth;
  tefData.Extintion_Automatique_Eth_min = armSetting.Extintion_Automatique_Eth_min;
  if ((Tipo != "BL") && (Tipo != "HI") && (Tipo != "HI2")){
    tefData.Niveau_de_sortie = armSetting.Niveau_de_sortie;
    tefData.Niveau_entrant = armSetting.Niveau_entrant;
  }
  tefData.Mot_De_Passe = armSetting.Mot_De_Passe;
  return tefData;
};

getErrorFields = function () {
    return errorFields;
};
hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};

var chkInter = function () {
    if (typeof armSetting.Extintion_Automatique_WiFi === 'undefined') {
        armSetting.Extintion_Automatique_WiFi = 'pas_activee';
    }
    if (typeof armSetting.Extintion_Automatique_Eth === 'undefined') {
        armSetting.Extintion_Automatique_Eth = 'pas_activee';
    }
    return true;
};

validate = function () {

    if (armSettingDefault === null) {
        armSettingDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
        console.log("FILE: " + default_armsetting_file);
    }
    checkNotEmpty(armSetting.Nom_Identifiant, 'Nom_Identifiant');
    armSetting.Extintion_Automatique_WiFi = checkFieldInList(armSetting.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', armSettingDefault.Extintion_Automatique_WiFi);
    armSetting.Extintion_Automatique_WiFi_min = checkFieldInRange(armSetting.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', armSettingDefault.Extintion_Automatique_WiFi_min);
    armSetting.Extintion_Automatique_Eth = checkFieldInList(armSetting.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', armSettingDefault.Extintion_Automatique_Eth);
    armSetting.Extintion_Automatique_Eth_min = checkFieldInRange(armSetting.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', armSettingDefault.Extintion_Automatique_Eth_min);
    if(errorFields != undefined){
      if (errorFields.length > 0) {
          return true;
      }
    }

    return true;
};
checkNotEmpty = function (field, fieldName) {
    if (typeof field === 'undefined') {
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (field === '') {
            errorFields.push({'field': fieldName, 'value': 'error_vide'});
        }
    }
};
inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};
checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};
checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
