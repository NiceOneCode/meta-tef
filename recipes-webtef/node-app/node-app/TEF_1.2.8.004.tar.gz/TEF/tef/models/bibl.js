/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var tefData;
var tefDataDefault = null;
var errorFields;
var tefLocal_Settings = null;

var local_armsettings_file    = __dirname + '/../database/local_settings.ini';
var default_armsetting_file   = __dirname + '/../database/default/armSettingsDefault.ini'
var armLocalDefault;
if ( fs.existsSync(local_armsettings_file))
{
  try
  {
      armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  }
  catch(e)
  {
      armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
  }

}
else
{
  armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
}

exports.init = function (objData) {
    tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibl.ini', 'utf-8'));
    errorFields = [];
    if (objData === false) {
        // no previous data defined,
        // so setting default values
        /*if (tefDataDefault === null) {
            tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibl.ini', 'utf-8'));
        }*/
        console.log("Utilizzo dei valori di default");
        tefData = {
            'Typologie_TEF': tefDataDefault.Typologie_TEF,
            'Nom_Identifiant': tefDataDefault.Nom_Identifiant,
            'Temps_Duree_Fixe_TMAX': tefDataDefault.Temps_Duree_Fixe_TMAX.default,
            'Temps_Anti_Bavard_TAB': tefDataDefault.Temps_Anti_Bavard_TAB.default,
            'Temps_Anti_Bavard_TAB_sec': tefDataDefault.Temps_Anti_Bavard_TAB_sec.default,
            'Temps_Mise_A_Repos_No_Rep_sec': tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec.default,
            'Typologie_Signalisation': tefDataDefault.Typologie_Signalisation.default,
            'Duree_Signal_50Hz_En_Sortie_msec': tefDataDefault.Duree_Signal_50Hz_En_Sortie_msec.default,
            'Duree_Signalisation_En_Sortie_msec': tefDataDefault.Duree_Signalisation_En_Sortie_msec.default,
            'Modalite_Communication': tefDataDefault.Modalite_Communication.default,
            'Detection_Occupation_Liberation': tefDataDefault.Detection_Occupation_Liberation.default,
            'Relais_MTR': tefDataDefault.Relais_MTR.default,
            'Temps_Mise_A_Repos_sec': tefDataDefault.Temps_Mise_A_Repos_sec.default,
            'Emission_Message_Vocal': tefDataDefault.Emission_Message_Vocal.default,
            'Signalisation_Retour_Appel': tefDataDefault.Signalisation_Retour_Appel.default,
            'Duree_Emission_msec': tefDataDefault.Duree_Emission_msec.default,
            'Niveau_Emission_dB': tefDataDefault.Niveau_Emission_dB.default,
            'Modalite_Reponse': tefDataDefault.Modalite_Reponse.default,
            'Nombre_Trains_Sonnerie': tefDataDefault.Nombre_Trains_Sonnerie.default,
            'Sonnerie': tefDataDefault.Sonnerie.default,
            'Duree_Sonnerie_Interieure_msec': tefDataDefault.Duree_Sonnerie_Interieure_msec.default,
            'Duree_Extention_Sonnerie_msec': tefDataDefault.Duree_Extention_Sonnerie_msec.default,
            'Module_Interface_Aerienne': tefDataDefault.Module_Interface_Aerienne.default,
            'Niveau_Emission_Ligne_Analogique_dB': tefDataDefault.Niveau_Emission_Ligne_Analogique_dB.default,
            'Extintion_Automatique_WiFi': tefDataDefault.Extintion_Automatique_WiFi.default,
            'Extintion_Automatique_WiFi_min': tefDataDefault.Extintion_Automatique_WiFi_min.default,
            'Extintion_Automatique_Eth': tefDataDefault.Extintion_Automatique_Eth.default,
            'Extintion_Automatique_Eth_min': tefDataDefault.Extintion_Automatique_Eth_min.default,
            'Type_de_cable': tefDataDefault.Type_de_cable.default,
            'Niveau_de_sortie': tefDataDefault.Niveau_de_sortie.default,
            'Niveau_entrant': tefDataDefault.Niveau_entrant.default,
            'Mot_De_Passe': tefDataDefault.Mot_De_Passe,
            'Panneau_solaire': tefDataDefault.Panneau_solaire.default,
            'Module_cle': tefDataDefault.Module_cle.default,
            'Panneau_solaire_etat': "",
            'Batterie_etat': "",
            'Etat_recharge': "",
            'Type_alimentation': "",
            'Type_Batterie': tefDataDefault.Type_Batterie.default,
            'Sous_Seuil': "",

        };
    } else {
        tefData = objData;
        //tefData.Niveau_de_sortie = armLocalDefault.Settings.Niveau_de_sortie;
        //tefData.Niveau_entrant = armLocalDefault.Settings.Niveau_entrant;
        //console.log("INIT con dati dal form. Panneau_solaire: " + tefData.Panneau_solaire);
    }
};
exports.getData = function () {
    return tefData;
};
exports.getDataDefault = function() {
    return tefDataDefault;
};
exports.getErrorFields = function () {
    return errorFields;
};
exports.hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
exports.getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};
exports.export = function () {
    var obj = {
        'Typologie_TEF': tefData.Typologie_TEF,
        'Nom_Identifiant': tefData.Nom_Identifiant,
        //'Temps_Duree_Fixe_TMAX': tefData.Temps_Duree_Fixe_TMAX,
        'Temps_Anti_Bavard_TAB': tefData.Temps_Anti_Bavard_TAB,
        'Temps_Anti_Bavard_TAB_sec': tefData.Temps_Anti_Bavard_TAB_sec,
        'Temps_Mise_A_Repos_No_Rep_sec': tefData.Temps_Mise_A_Repos_No_Rep_sec,
        'Typologie_Signalisation': tefData.Typologie_Signalisation,
        'Duree_Signal_50Hz_En_Sortie_msec': tefData.Duree_Signal_50Hz_En_Sortie_msec,
        'Duree_Signalisation_En_Sortie_msec': tefData.Duree_Signalisation_En_Sortie_msec,
        'Modalite_Communication': tefData.Modalite_Communication,
        'Detection_Occupation_Liberation': tefData.Detection_Occupation_Liberation,
        'Relais_MTR': tefData.Relais_MTR,
        'Temps_Mise_A_Repos_sec': tefData.Temps_Mise_A_Repos_sec,
        'Emission_Message_Vocal': tefData.Emission_Message_Vocal,
        'Signalisation_Retour_Appel': tefData.Signalisation_Retour_Appel,
        'Duree_Emission_msec': tefData.Duree_Emission_msec,
        'Niveau_Emission_dB': tefData.Niveau_Emission_dB,
        'Modalite_Reponse': tefData.Modalite_Reponse,
        'Nombre_Trains_Sonnerie': tefData.Nombre_Trains_Sonnerie,
        'Sonnerie': tefData.Sonnerie,
        'Duree_Sonnerie_Interieure_msec': tefData.Duree_Sonnerie_Interieure_msec,
        'Duree_Extention_Sonnerie_msec': tefData.Duree_Extention_Sonnerie_msec,
        'Module_Interface_Aerienne': tefData.Module_Interface_Aerienne,
        'Niveau_Emission_Ligne_Analogique_dB': tefData.Niveau_Emission_Ligne_Analogique_dB,
        'Extintion_Automatique_WiFi': tefData.Extintion_Automatique_WiFi,
        'Extintion_Automatique_WiFi_min': tefData.Extintion_Automatique_WiFi_min,
        'Extintion_Automatique_Eth': tefData.Extintion_Automatique_Eth,
        'Extintion_Automatique_Eth_min': tefData.Extintion_Automatique_Eth_min,
        'Type_de_cable': tefData.Type_de_cable,
        'Niveau_de_sortie': tefData.Niveau_de_sortie,
        'Niveau_entrant': tefData.Niveau_entrant,
        //'Mot_De_Passe': tefData.Mot_De_Passe,
        'Panneau_solaire': tefData.Panneau_solaire,
        'Module_cle': tefData.Module_cle,
        // 'Panneau_solaire_etat': tefData.Panneau_solaire_etat,
        // 'Batterie_etat': tefData.Batterie_etat,
        // 'Type_alimentation':tefData.Type_alimentation,
        'Type_Batterie': tefData.Type_Batterie,
    };
    console.log("Export. Arienne: " + tefData.Module_Interface_Aerienne);
    return obj;
};
exports.normalize = function () {
    // Setting initial data according to checkboxes with unchecked values
    // (unchecked checkboxes are not trasmitted in HTTP POST request).
    if (typeof tefData.Temps_Duree_Fixe_TMAX === 'undefined') {
        tefData.Temps_Duree_Fixe_TMAX = 'pas_activee';
    }
    if (typeof tefData.Temps_Anti_Bavard_TAB === 'undefined') {
        tefData.Temps_Anti_Bavard_TAB = 'pas_activee';
    }
    if (typeof tefData.Typologie_Signalisation === 'undefined') {
        tefData.Typologie_Signalisation = '50Hz';
    }
    if (typeof tefData.Modalite_Communication === 'undefined') {
        tefData.Modalite_Communication = 'half_duplex';
    }
    if (typeof tefData.Detection_Occupation_Liberation === 'undefined') {
        tefData.Detection_Occupation_Liberation = 'pas_activee';
    }
    if (typeof tefData.Relais_MTR === 'undefined') {
        tefData.Relais_MTR = 'pas_activee';
    }
    if (typeof tefData.Emission_Message_Vocal === 'undefined') {
        tefData.Emission_Message_Vocal = 'pas_activee';
    }
    if (typeof tefData.Signalisation_Retour_Appel === 'undefined') {
        tefData.Signalisation_Retour_Appel = 'pas_activee';
    }
    if (typeof tefData.Module_Interface_Aerienne === 'undefined') {
        tefData.Module_Interface_Aerienne = 'pas_present';
    }
    if (typeof tefData.Extintion_Automatique_WiFi === 'undefined') {
        tefData.Extintion_Automatique_WiFi = 'pas_activee';
    }
    if (typeof tefData.Extintion_Automatique_Eth === 'undefined') {
        tefData.Extintion_Automatique_Eth = 'pas_activee';
    }
    if (typeof tefData.Panneau_solaire === 'undefined') {
        tefData.Panneau_solaire = 'pas_activee';
    } else {
        tefData.Panneau_solaire = 'activee';
    }
    if (typeof tefData.Module_cle === 'undefined') {
        tefData.Module_cle = 'pas_activee';
    }
    if (typeof tefData.Type_Batterie === 'undefined') {
        tefData.Type_Batterie = 'Non_rechargeable';
    }
    else
    {
        tefData.Type_Batterie = 'Rechargeable';
    }  

    //console.log("Normalize. Arienne: " + tefData.Module_Interface_Aerienne);
};
exports.validate = function () {

    if (tefDataDefault === null) {
        tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibl.ini', 'utf-8'));
    }

    if (typeof tefData.Nom_Identifiant === 'undefined') {
        errorFields.push({'field': 'Nom_Identifiant', 'value': 'error_pas_present'});
    } else {
        if (tefData.Nom_Identifiant === '') {
            errorFields.push({'field': 'Nom_Identifiant', 'value': 'error_vide'});
        }
    }

    tefData.Temps_Duree_Fixe_TMAX = checkFieldInList(tefData.Temps_Duree_Fixe_TMAX, 'Temps_Duree_Fixe_TMAX', tefDataDefault.Temps_Duree_Fixe_TMAX);
    tefData.Temps_Anti_Bavard_TAB = checkFieldInList(tefData.Temps_Anti_Bavard_TAB, 'Temps_Anti_Bavard_TAB', tefDataDefault.Temps_Anti_Bavard_TAB);
    tefData.Temps_Anti_Bavard_TAB_sec = checkFieldInRange(tefData.Temps_Anti_Bavard_TAB_sec, 'Temps_Anti_Bavard_TAB_sec', tefDataDefault.Temps_Anti_Bavard_TAB_sec);

    tefData.Temps_Mise_A_Repos_No_Rep_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_sec, 'Temps_Mise_A_Repos_No_Rep_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec);

    tefData.Typologie_Signalisation = checkFieldInList(tefData.Typologie_Signalisation, 'Typologie_Signalisation', tefDataDefault.Typologie_Signalisation);
    tefData.Duree_Signal_50Hz_En_Sortie_msec = checkFieldInRange(tefData.Duree_Signal_50Hz_En_Sortie_msec, 'Duree_Signal_50Hz_En_Sortie_msec', tefDataDefault.Duree_Signal_50Hz_En_Sortie_msec);
    tefData.Duree_Signalisation_En_Sortie_msec = checkFieldInRange(tefData.Duree_Signalisation_En_Sortie_msec, 'Duree_Signalisation_En_Sortie_msec', tefDataDefault.Duree_Signalisation_En_Sortie_msec);

    tefData.Modalite_Communication = checkFieldInList(tefData.Modalite_Communication, 'Modalite_Communication', tefDataDefault.Modalite_Communication);

    tefData.Detection_Occupation_Liberation = checkFieldInList(tefData.Detection_Occupation_Liberation, 'Detection_Occupation_Liberation', tefDataDefault.Detection_Occupation_Liberation);
    tefData.Relais_MTR = checkFieldInList(tefData.Relais_MTR, 'Relais_MTR', tefDataDefault.Relais_MTR);

    tefData.Temps_Mise_A_Repos_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_sec, 'Temps_Mise_A_Repos_sec', tefDataDefault.Temps_Mise_A_Repos_sec);
    tefData.Emission_Message_Vocal = checkFieldInList(tefData.Emission_Message_Vocal, 'Emission_Message_Vocal', tefDataDefault.Emission_Message_Vocal);

    tefData.Signalisation_Retour_Appel = checkFieldInList(tefData.Signalisation_Retour_Appel, 'Signalisation_Retour_Appel', tefDataDefault.Signalisation_Retour_Appel);
    tefData.Duree_Emission_msec = checkFieldInRange(tefData.Duree_Emission_msec, 'Duree_Emission_msec', tefDataDefault.Duree_Emission_msec);
    tefData.Niveau_Emission_dB = checkFieldInRange(tefData.Niveau_Emission_dB, 'Niveau_Emission_dB', tefDataDefault.Niveau_Emission_dB);

    tefData.Modalite_Reponse = checkFieldInList(tefData.Modalite_Reponse, 'Modalite_Reponse', tefDataDefault.Modalite_Reponse);
    tefData.Nombre_Trains_Sonnerie = checkFieldInRange(tefData.Nombre_Trains_Sonnerie, 'Nombre_Trains_Sonnerie', tefDataDefault.Nombre_Trains_Sonnerie);

    tefData.Sonnerie = checkFieldInList(tefData.Sonnerie, 'Sonnerie', tefDataDefault.Sonnerie);
    tefData.Duree_Sonnerie_Interieure_msec = checkFieldInRange(tefData.Duree_Sonnerie_Interieure_msec, 'Duree_Sonnerie_Interieure_msec', tefDataDefault.Duree_Sonnerie_Interieure_msec);
    tefData.Duree_Extention_Sonnerie_msec = checkFieldInRange(tefData.Duree_Extention_Sonnerie_msec, 'Duree_Extention_Sonnerie_msec', tefDataDefault.Duree_Extention_Sonnerie_msec);

    tefData.Module_Interface_Aerienne = checkFieldInList(tefData.Module_Interface_Aerienne, 'Module_Interface_Aerienne', tefDataDefault.Module_Interface_Aerienne);

    tefData.Niveau_Emission_Ligne_Analogique_dB = checkFieldInRange(tefData.Niveau_Emission_Ligne_Analogique_dB, 'Niveau_Emission_Ligne_Analogique_dB', tefDataDefault.Niveau_Emission_Ligne_Analogique_dB);

    tefData.Panneau_solaire = checkFieldInList(tefData.Panneau_solaire, 'Panneau_solaire', tefDataDefault.Panneau_solaire);
    tefData.Module_cle = checkFieldInList(tefData.Module_cle, 'Module_cle', tefDataDefault.Module_cle);
    tefData.Type_Batterie = checkFieldInList(tefData.Type_Batterie, 'Type_Batterie', tefDataDefault.Type_Batterie);

    tefData.Extintion_Automatique_WiFi = checkFieldInList(tefData.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', tefDataDefault.Extintion_Automatique_WiFi);
    tefData.Extintion_Automatique_WiFi_min = checkFieldInRange(tefData.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', tefDataDefault.Extintion_Automatique_WiFi_min);

    tefData.Extintion_Automatique_Eth = checkFieldInList(tefData.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', tefDataDefault.Extintion_Automatique_Eth);
    tefData.Extintion_Automatique_Eth_min = checkFieldInRange(tefData.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', tefDataDefault.Extintion_Automatique_Eth_min);

    if (errorFields.length > 0) {
        return false;
    }
    return true;
};

inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};

checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};

checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
