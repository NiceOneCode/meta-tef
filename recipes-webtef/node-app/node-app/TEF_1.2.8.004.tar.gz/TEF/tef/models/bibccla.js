/**
 *
 * @type {Module fs|Module fs}
 */

var fs = require('fs');
var ini = require('ini');
var tefData;
var tefDataDefault = null;
var errorFields;
var tefLocal_Settings = null;

var local_armsettings_file    = __dirname + '/../database/local_settings.ini';
var default_armsetting_file   = __dirname + '/../database/default/armSettingsDefault.ini'
var armLocalDefault;
if ( fs.existsSync(local_armsettings_file))
{
  try
  {
      armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  }
  catch(e)
  {
      armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
  }

}
else
{
  armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
}



exports.init = function (objData) {
    tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibccla.ini', 'utf-8'));
    errorFields = [];
    console.log("INIT");
    if (objData === false) {
        // no previous data defined,
        /*if (tefDataDefault === null) {
            tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibccla.ini', 'utf-8'));
        }*/
        tefData = {
            'Typologie_TEF': tefDataDefault.Typologie_TEF,
            'Nom_Identifiant': tefDataDefault.Nom_Identifiant,
            'Temps_Duree_Fixe_TMAX': tefDataDefault.Temps_Duree_Fixe_TMAX.default,
            'Temps_Anti_Bavard_TAB': tefDataDefault.Temps_Anti_Bavard_TAB.default,
            'Temps_Anti_Bavard_TAB_sec': tefDataDefault.Temps_Anti_Bavard_TAB_sec.default,
            'Temps_Mise_A_Repos_No_Rep_sec': tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec.default,
            'Temps_Attente_Code_Deblocage_Clavier_sec': tefDataDefault.Temps_Attente_Code_Deblocage_Clavier_sec.default,
            'Temporisation_Attente_Numerotation_sec': tefDataDefault.Temporisation_Attente_Numerotation_sec.default,
            'Code_Deblocage': tefDataDefault.Code_Deblocage.default,
            'Activation_Tonalite_Invitation_Transmettre': tefDataDefault.Activation_Tonalite_Invitation_Transmettre.default,
            'Temporisation_Attente_Tonalite_Invitation_Transmettre_msec': tefDataDefault.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.default,
            'Modalite_Communication': tefDataDefault.Modalite_Communication.default,
            'Detection_Occupation_Liberation': tefDataDefault.Detection_Occupation_Liberation.default,
            'Temps_Mise_A_Repos_sec': tefDataDefault.Temps_Mise_A_Repos_sec.default,
            'Modalite_Reponse': tefDataDefault.Modalite_Reponse.default,
            'Nombre_Trains_Sonnerie': tefDataDefault.Nombre_Trains_Sonnerie.default,
            'Niveau_Emission_Ligne_Analogique_dB': tefDataDefault.Niveau_Emission_Ligne_Analogique_dB.default,
            'Duree_Signalisation_Associee_Bouton_R_msec': tefDataDefault.Duree_Signalisation_Associee_Bouton_R_msec.default,
            'Duree_Mark_msec': tefDataDefault.Duree_Mark_msec.default,
            'Duree_Space_msec': tefDataDefault.Duree_Space_msec.default,
            'Echelle': tefDataDefault.Echelle.default,
            'Niveau_Emission_DTMF_dB': tefDataDefault.Niveau_Emission_DTMF_dB.default,
            'Extintion_Automatique_WiFi': tefDataDefault.Extintion_Automatique_WiFi.default,
            'Extintion_Automatique_WiFi_min': tefDataDefault.Extintion_Automatique_WiFi_min.default,
            'Extintion_Automatique_Eth': tefDataDefault.Extintion_Automatique_Eth.default,
            'Extintion_Automatique_Eth_min': tefDataDefault.Extintion_Automatique_Eth_min.default,
            'Type_de_cable': tefDataDefault.Type_de_cable.default,
            'Niveau_de_sortie': tefDataDefault.Niveau_de_sortie.default,
            'Niveau_entrant': tefDataDefault.Niveau_entrant.default.default,
            'Mot_De_Passe': tefDataDefault.Mot_De_Passe,
        };

    } else {
        tefData = objData;
        tefData.Niveau_de_sortie = armLocalDefault.Settings.Niveau_de_sortie;
        tefData.Niveau_entrant = armLocalDefault.Settings.Niveau_entrant;
    }
};
exports.getData = function () {
    return tefData;
};
exports.getDataDefault = function() {
    return tefDataDefault;
};
exports.getErrorFields = function () {
    return errorFields;
};
exports.hasError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return true;
        }
    }
    return false;
};
exports.getError = function (field) {
    for (var f in errorFields) {
        if (errorFields[f].field === field) {
            return errorFields[f].value;
        }
    }
    return false;
};
exports.export = function () {
    var obj = {
        'Typologie_TEF': tefData.Typologie_TEF,
        'Nom_Identifiant': tefData.Nom_Identifiant,
        //'Temps_Duree_Fixe_TMAX': tefData.Temps_Duree_Fixe_TMAX,
        'Temps_Anti_Bavard_TAB': tefData.Temps_Anti_Bavard_TAB,
        'Temps_Anti_Bavard_TAB_sec': tefData.Temps_Anti_Bavard_TAB_sec,
        'Temps_Mise_A_Repos_No_Rep_sec': tefData.Temps_Mise_A_Repos_No_Rep_sec,
        'Temps_Attente_Code_Deblocage_Clavier_sec': tefData.Temps_Attente_Code_Deblocage_Clavier_sec,
        'Temporisation_Attente_Numerotation_sec': tefData.Temporisation_Attente_Numerotation_sec,
        'Code_Deblocage': tefData.Code_Deblocage,
        'Activation_Tonalite_Invitation_Transmettre': tefData.Activation_Tonalite_Invitation_Transmettre,
        'Temporisation_Attente_Tonalite_Invitation_Transmettre_msec': tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec,
        'Modalite_Communication': tefData.Modalite_Communication,
        'Detection_Occupation_Liberation': tefData.Detection_Occupation_Liberation,
        'Temps_Mise_A_Repos_sec': tefData.Temps_Mise_A_Repos_sec,
        'Modalite_Reponse': tefData.Modalite_Reponse,
        'Nombre_Trains_Sonnerie': tefData.Nombre_Trains_Sonnerie,
        'Niveau_Emission_Ligne_Analogique_dB': tefData.Niveau_Emission_Ligne_Analogique_dB,
        'Duree_Signalisation_Associee_Bouton_R_msec': tefData.Duree_Signalisation_Associee_Bouton_R_msec,
        'Duree_Mark_msec': tefData.Duree_Mark_msec,
        'Duree_Space_msec': tefData.Duree_Space_msec,
        'Echelle': tefData.Echelle,
        'Niveau_Emission_DTMF_dB': tefData.Niveau_Emission_DTMF_dB,
        'Extintion_Automatique_WiFi': tefData.Extintion_Automatique_WiFi,
        'Extintion_Automatique_WiFi_min': tefData.Extintion_Automatique_WiFi_min,
        'Extintion_Automatique_Eth': tefData.Extintion_Automatique_Eth,
        'Extintion_Automatique_Eth_min': tefData.Extintion_Automatique_Eth_min,
        'Type_de_cable': tefData.Type_de_cable,
        'Niveau_de_sortie': tefData.Niveau_de_sortie,
        'Niveau_entrant': tefData.Niveau_entrant,
        //'Mot_De_Passe': tefData.Mot_De_Passe,
    };
    console.log("EXPORT: " + tefData.Niveau_de_sortie);
    return obj;
};
exports.normalize = function () {
    // Setting initial data according to checkboxes with unchecked values
    // (unchecked checkboxes are not trasmitted in HTTP POST request).
    if (typeof tefData.Temps_Duree_Fixe_TMAX === 'undefined') {
        tefData.Temps_Duree_Fixe_TMAX = 'pas_activee';
    }
    if (typeof tefData.Temps_Anti_Bavard_TAB === 'undefined') {
        tefData.Temps_Anti_Bavard_TAB = 'pas_activee';
    }
    if (typeof tefData.Code_Deblocage === 'undefined') {
        tefData.Code_Deblocage = '';
    }
    if (typeof tefData.Activation_Tonalite_Invitation_Transmettre === 'undefined') {
        tefData.Activation_Tonalite_Invitation_Transmettre = 'pas_activee';
    }
    if (typeof tefData.Modalite_Communication === 'undefined') {
        tefData.Modalite_Communication = 'half_duplex';
    }
    if (typeof tefData.Detection_Occupation_Liberation === 'undefined') {
        tefData.Detection_Occupation_Liberation = 'pas_activee';
    }
    if (typeof tefData.Extintion_Automatique_WiFi === 'undefined') {
        tefData.Extintion_Automatique_WiFi = 'pas_activee';
    }
    if (typeof tefData.Extintion_Automatique_Eth === 'undefined') {
        tefData.Extintion_Automatique_Eth = 'pas_activee';
    }
};
exports.validate = function () {

    if (tefDataDefault === null) {
        tefDataDefault = ini.parse(fs.readFileSync(__dirname + '/../database/default/bibccla.ini', 'utf-8'));
    }

    checkNotEmpty(tefData.Nom_Identifiant, 'Nom_Identifiant');
    tefData.Temps_Duree_Fixe_TMAX = checkFieldInList(tefData.Temps_Duree_Fixe_TMAX, 'Temps_Duree_Fixe_TMAX', tefDataDefault.Temps_Duree_Fixe_TMAX);
    tefData.Temps_Anti_Bavard_TAB = checkFieldInList(tefData.Temps_Anti_Bavard_TAB, 'Temps_Anti_Bavard_TAB', tefDataDefault.Temps_Anti_Bavard_TAB);
    tefData.Temps_Anti_Bavard_TAB_sec = checkFieldInRange(tefData.Temps_Anti_Bavard_TAB_sec, 'Temps_Anti_Bavard_TAB_sec', tefDataDefault.Temps_Anti_Bavard_TAB_sec);
    tefData.Temps_Mise_A_Repos_No_Rep_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_No_Rep_sec, 'Temps_Mise_A_Repos_No_Rep_sec', tefDataDefault.Temps_Mise_A_Repos_No_Rep_sec);
    tefData.Temps_Attente_Code_Deblocage_Clavier_sec = checkFieldInRange(tefData.Temps_Attente_Code_Deblocage_Clavier_sec, 'Temps_Attente_Code_Deblocage_Clavier_sec', tefDataDefault.Temps_Attente_Code_Deblocage_Clavier_sec);
    tefData.Temporisation_Attente_Numerotation_sec = checkFieldInRange(tefData.Temporisation_Attente_Numerotation_sec, 'Temporisation_Attente_Numerotation_sec', tefDataDefault.Temporisation_Attente_Numerotation_sec);
    checkNotEmpty(tefData.Code_Deblocage, 'Code_Deblocage');
    tefData.Activation_Tonalite_Invitation_Transmettre = checkFieldInList(tefData.Activation_Tonalite_Invitation_Transmettre, 'Activation_Tonalite_Invitation_Transmettre', tefDataDefault.Activation_Tonalite_Invitation_Transmettre);
    tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec = checkFieldInRange(tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec, 'Temporisation_Attente_Tonalite_Invitation_Transmettre_msec', tefDataDefault.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec);
    tefData.Modalite_Communication = checkFieldInList(tefData.Modalite_Communication, 'Modalite_Communication', tefDataDefault.Modalite_Communication);
    tefData.Detection_Occupation_Liberation = checkFieldInList(tefData.Detection_Occupation_Liberation, 'Detection_Occupation_Liberation', tefDataDefault.Detection_Occupation_Liberation);
    tefData.Temps_Mise_A_Repos_sec = checkFieldInRange(tefData.Temps_Mise_A_Repos_sec, 'Temps_Mise_A_Repos_sec', tefDataDefault.Temps_Mise_A_Repos_sec);
    tefData.Modalite_Reponse = checkFieldInList(tefData.Modalite_Reponse, 'Modalite_Reponse', tefDataDefault.Modalite_Reponse);
    tefData.Nombre_Trains_Sonnerie = checkFieldInRange(tefData.Nombre_Trains_Sonnerie, 'Nombre_Trains_Sonnerie', tefDataDefault.Nombre_Trains_Sonnerie);
    tefData.Niveau_Emission_Ligne_Analogique_dB = checkFieldInRange(tefData.Niveau_Emission_Ligne_Analogique_dB, 'Niveau_Emission_Ligne_Analogique_dB', tefDataDefault.Niveau_Emission_Ligne_Analogique_dB);
    tefData.Duree_Signalisation_Associee_Bouton_R_msec = checkFieldInRange(tefData.Duree_Signalisation_Associee_Bouton_R_msec, 'Duree_Signalisation_Associee_Bouton_R_msec', tefDataDefault.Duree_Signalisation_Associee_Bouton_R_msec);
    tefData.Duree_Mark_msec = checkFieldInRange(tefData.Duree_Mark_msec, 'Duree_Mark_msec', tefDataDefault.Duree_Mark_msec);
    tefData.Duree_Space_msec = checkFieldInRange(tefData.Duree_Space_msec, 'Duree_Space_msec', tefDataDefault.Duree_Space_msec);
    tefData.Echelle = checkFieldInRange(tefData.Echelle, 'Echelle', tefDataDefault.Echelle);
    tefData.Niveau_Emission_DTMF_dB = checkFieldInRange(tefData.Niveau_Emission_DTMF_dB, 'Niveau_Emission_DTMF_dB', tefDataDefault.Niveau_Emission_DTMF_dB);
    tefData.Extintion_Automatique_WiFi = checkFieldInList(tefData.Extintion_Automatique_WiFi, 'Extintion_Automatique_WiFi', tefDataDefault.Extintion_Automatique_WiFi);
    tefData.Extintion_Automatique_WiFi_min = checkFieldInRange(tefData.Extintion_Automatique_WiFi_min, 'Extintion_Automatique_WiFi_min', tefDataDefault.Extintion_Automatique_WiFi_min);
    tefData.Extintion_Automatique_Eth = checkFieldInList(tefData.Extintion_Automatique_Eth, 'Extintion_Automatique_Eth', tefDataDefault.Extintion_Automatique_Eth);
    tefData.Extintion_Automatique_Eth_min = checkFieldInRange(tefData.Extintion_Automatique_Eth_min, 'Extintion_Automatique_Eth_min', tefDataDefault.Extintion_Automatique_Eth_min);
    if (errorFields.length > 0) {
        return false;
    }
    return true;
};
checkNotEmpty = function (field, fieldName) {
    if (typeof field === 'undefined') {
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (field === '') {
            errorFields.push({'field': fieldName, 'value': 'error_vide'});
        }
    }
};
inArray = function (needle, haystack) {
    for (var i in haystack) {
        if (needle === haystack[i]) {
            return true;
        }
    }
    return false;
};
checkFieldInList = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (!inArray(field, valDefaults.values)) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_valeur_refuse'});
        }
    }
    return field;
};
checkFieldInRange = function (field, fieldName, valDefaults) {
    if (typeof field === 'undefined') {
        field = valDefaults.default;
        errorFields.push({'field': fieldName, 'value': 'error_pas_present'});
    } else {
        if (isNaN(parseInt(field))) {
            field = valDefaults.default;
            errorFields.push({'field': fieldName, 'value': 'error_pas_valid_valeur'});
        } else {
            if (parseInt(field) < valDefaults.min || parseInt(field) > valDefaults.max) {
                field = valDefaults.default;
                errorFields.push({'field': fieldName, 'value': 'error_pas_dans_le_range'});
            }
        }
    }
    return parseInt(field);
};
