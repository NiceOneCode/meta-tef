
var GetInitARM = require('./structures/GetInitARM');
var SetCFG_M = require('./structures/SetConfigurationBCM');
var SetCFG_CLA = require('./structures/SetConfigurationBCCLA');
var SetCFG_PRO = require('./structures/SetConfigurationBCPRO');
var SetCFG_BL = require('./structures/SetConfigurationBIBL');
var SetCFG_HI = require('./structures/SetConfigurationHI');
var SetCFG_HI2 = require('./structures/SetConfigurationHI2');
var SetMAN_CNF = require('./structures/SetCalibrationManual');
var SetMAN_CNFL2 = require('./structures/SetCalibrationManualL2');
var SetPHO_BOK = require('./structures/SetPhoneBookBCPRO');


var messageParser;
var messageSender;
var messageRawSender;
var messageSenderInitARM;
var messageRawSenderInitARM;

var Commands = function (parser, sender, rawSender, senderInitARM, rawSenderInitARM) {
    messageParser = parser;
    messageSender = sender;
    messageRawSender = rawSender;
    messageSenderInitARM = senderInitARM;
    messageRawSenderInitARM = rawSenderInitARM;
};

Commands.prototype.getInitARM = function (handlerReply) {
    messageParser.addReplyHandler(0xFF, handlerReply);
    var initARM = new GetInitARM(null);
    messageSenderInitARM(initARM.getMessage(), true);
};

Commands.prototype.getConfigurationbcm = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationbcm = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_M(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getConfigurationbccla = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationbccla = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_CLA(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};


Commands.prototype.getConfigurationbibl = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationbibl = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_BL(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getConfigurationhi = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationhi = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_HI(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getConfigurationhi2 = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationhi2 = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_HI2(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getConfigurationbcpro = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.setConfigurationbcpro = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x01, handlerReply);
    var setCFG = new SetCFG_PRO(configData);
    var message = "01" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getConfiguration = function (handlerReply) {
    messageParser.addReplyHandler(0xF1, handlerReply);
    var message = "F1";
    messageSender(message, true);
};

Commands.prototype.reboot = function (handlerReply) {
    messageParser.addReplyHandler(0x77, handlerReply);
    messageSender("77", true);
};

Commands.prototype.eraseFlash = function (handlerReply) {
    messageParser.addReplyHandler(0x4F, handlerReply);
    messageRawSender("02535003", true);
};

var splittedFirmware;
var countSplittedFirmware = 0;


Commands.prototype.sendFirmware = function (firmware, handlerReply) {
        countSplittedFirmware = 0;
        messageParser.addReplyHandler(0x41, keepOnSendingFirmware);
        messageParser.addReplyHandler(0x53, handlerReply);
        splittedFirmware = firmware.split("a");
    keepOnSendingFirmware();
};

function keepOnSendingFirmware() {
    if (countSplittedFirmware < splittedFirmware.length) {
        var chunk = splittedFirmware[countSplittedFirmware] + "a";
        console.log('countSplittedFirmware = ' + countSplittedFirmware);
        countSplittedFirmware++;
        messageRawSender(chunk, false);
    } else {
        countSplittedFirmware = 0;
    }
}

Commands.prototype.setManualSetting = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x20, handlerReply);
    var setCFG = new SetMAN_CNF(configData);
    var message = "20" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getManualSetting = function (handlerReply) {
    messageParser.addReplyHandler(0x21, handlerReply);
    var message = "21";
    messageSender(message, true);
};

Commands.prototype.saveManualSetting = function (handlerReply) {
    messageParser.addReplyHandler(0x22, handlerReply);
    var message = "22";
    messageSender(message, false);
};

Commands.prototype.setManualSettingL2 = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x50, handlerReply);
    var setCFG = new SetMAN_CNFL2(configData);
    var message = "50" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getManualSettingL2 = function (handlerReply) {
    messageParser.addReplyHandler(0x51, handlerReply);
    var message = "51";
    messageSender(message, true);
};

Commands.prototype.saveManualSettingL2 = function (handlerReply) {
    messageParser.addReplyHandler(0x52, handlerReply);
    var message = "52";
    messageSender(message, false);
};

Commands.prototype.setPhoneBook = function (configData, handlerReply) {
    messageParser.addReplyHandler(0x0A, handlerReply);
    var setCFG = new SetPHO_BOK(configData);
    var message = "0A" + setCFG.getString();
    messageSender(message, false);
};

Commands.prototype.getPhoneBook = function (handlerReply) {
    messageParser.addReplyHandler(0xFA, handlerReply);
    var message = "FA";
    messageSender(message, true);
};

module.exports = Commands;
