/*
 *
 *
 */
var AudioMaxLength = 10;


var GetInitARM = require('./structures/GetInitARM');
var GetCFG_M = require('./structures/GetConfigurationBCM');
var SetCFG_M = require('./structures/SetConfigurationBCM');
var GetCFG_CLA = require('./structures/GetConfigurationBCCLA');
var SetCFG_CLA = require('./structures/SetConfigurationBCCLA');
var GetCFG_PRO = require('./structures/GetConfigurationBCPRO');
var SetCFG_PRO = require('./structures/SetConfigurationBCPRO');

var GetCFG_BL = require('./structures/GetConfigurationBIBL');
var SetCFG_BL = require('./structures/SetConfigurationBIBL');

var GetCFG_HI = require('./structures/GetConfigurationHI');
var SetCFG_HI = require('./structures/SetConfigurationHI');

var GetCFG_HI2 = require('./structures/GetConfigurationHI2');
var SetCFG_HI2 = require('./structures/SetConfigurationHI2');

var GetMAN_CFG = require('./structures/GetCalibrationManual');
var SetMAN_CFG = require('./structures/SetCalibrationManual');
var GetMAN_CFGL2 = require('./structures/GetCalibrationManualL2');
var SetMAN_CFGL2 = require('./structures/SetCalibrationManualL2');
var GetPHO_BOK = require('./structures/GetPhoneBookBCPRO');
var SetPHO_BOK = require('./structures/SetPhoneBookBCPRO');
var SendFunction = require('./index.js');

var exec = require('child_process').exec;

var hGetConfiguration;
var hSetConfiguration;
var hReboot;
var hEraseFlash;
var hSendFirmware;
var hSendFirmwareFinished;

var hSetManualSetting;
var hGetManualSetting;
var hSaveManualSetting;
var hSetManualSettingL2;
var hGetManualSettingL2;
var hSaveManualSettingL2;
var hSetPhoneBook;
var hGetPhoneBook;

var fs = require('fs');
var sys = require('util');
function puts(error, stdout, stderr) { sys.puts(stdout) }


module.exports.addReplyHandler = function (messageCode, handler) {
    switch (messageCode) {
        case 0xFF: // init ARM
            hInitARM = handler;
            break;
        case 0xF1: // get configuration
            hGetConfiguration = handler;
            break;
        case 0x01: // set configuration
            hSetConfiguration = handler;
            break;
        case 0x77: // reboot
            hReboot = handler;
            break;
        case 0x4F: // erase flash
            hEraseFlash = handler;
            break;
        case 0x41: // send firmware
            hSendFirmware = handler;
            break;
        case 0x53: // send firmware finished
            hSendFirmwareFinished = handler;
            break;
        case 0x20: // send firmware finished
            hSetManualSetting = handler;
            break;
        case 0x21: // send firmware finished
            hGetManualSetting = handler;
            break;
       case 0x22: // send firmware finished
            hSaveManualSetting = handler;
            break;
        case 0x50: // send firmware finished
            hSetManualSettingL2 = handler;
            break;
        case 0x51: // send firmware finished
            hGetManualSettingL2 = handler;
            break;
       case 0x52: // send firmware finished
            hSaveManualSettingL2 = handler;
            break;
       case 0x0A: // send firmware finished
            hSetPhoneBook = handler;
            break;
       case 0xFA: // send firmware finished
            hGetPhoneBook = handler;
            break;
    }
};

module.exports.parse = function (buffer, keepSending) {
    // TODO check message length
    // TODO check message checksum
    //console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + buffer);
    var result;
    switch (buffer[0]) {
        case 0x02:
            switch (buffer[1]) {
                case 0x53:
                    switch (buffer[2]) {
                        case 0x4F:
                            if (typeof (hEraseFlash) === "function") {
                                clearInterval(keepSending);
                                hEraseFlash();
                            }
                            break;
                        case 0x41:
                            if (typeof (hSendFirmware) === "function") {
                                clearInterval(keepSending);
                                hSendFirmware();
                            }
                            break;
                        case 0x53:
                            if (typeof (hSendFirmwareFinished) === "function") {
                                clearInterval(keepSending);
                                hSendFirmwareFinished();
                            }
                            break;
                        default:
                            console.log("WRONG 0x02 0x53 RECEIVED MESSAGE:");
                            console.log(buffer.toString("hex"));
                            return false;
                            break;
                    }
                    break;
                default:
                    console.log("WRONG 0x02 RECEIVED MESSAGE:");
                    console.log(buffer.toString("hex"));
                    return false;
            }
            break;
        case 0xAA:
            //console.log("Dopo AA: " + buffer[2]);
            switch (buffer[2]) {
                case 0xFF: // init ARM:
                    result = new GetInitARM(buffer);
                    if (typeof (hInitARM) === "function") {
                        clearInterval(keepSending);
                        hInitARM(result);
                    }
                    break;
                case 0xF1: // get configuration
                     var content = Buffer.alloc(buffer.length - 4);
                     buffer.copy(content, 0, 3, buffer.length);
                     switch (buffer[7])
                     {
                       case 0X8:
                              console.log("Inizio analisi configurazione HI2");
                              result = new GetCFG_HI2(content);

                       break;
                       case 0X7:
                              console.log("Inizio analisi configurazione HI");
                              result = new GetCFG_HI(content);

                       break;
                       case 0X6:
                              console.log("Inizio analisi configurazione BL");
                              result = new GetCFG_BL(content);

                       break;
                       case 0X5:
                              console.log("Inizio analisi configurazione BC.M");
                              result = new GetCFG_M(content);
                       break;
                       case 0X4:
                              console.log("Inizio analisi configurazione BC.CLA");
                              result = new GetCFG_CLA(content);
                       break;
                       case 0X3:
                       case 0X2:
                       case 0X1:
                              console.log("Inizio analisi configurazione BC.PRO");
                              result = new GetCFG_PRO(content);
                       break;
                     }
                    if (typeof (hGetConfiguration) === "function") {
                        clearInterval(keepSending);
                        hGetConfiguration(result);
                    }
                    break;
                case 0x01: // set configuration
//                    result = new SetCFG(buffer);// sendMessage("30", false);  //DA VEDERE SE LA FUNZIONE E' VISIBILE DA QUI...
                            // console.log("ACK INVIATO");
                    if (typeof (hSetConfiguration) === "function") {
                        clearInterval(keepSending);
                        hSetConfiguration(result);
                    }
                    break;
                case 0x77: // reboot
                    if (typeof (hReboot) === "function") {
                        clearInterval(keepSending);
                        hReboot();
                    }
                    break;
                case 0x20:
                      var content = Buffer.alloc(buffer.length - 4);
                      buffer.copy(content, 0, 3, buffer.length);
                      result = new GetMAN_CFG(content);
                      if (typeof (hSetManualSetting) === "function") {
                          clearInterval(keepSending);
                          hSetManualSetting(result);
                        }
                 break;
                case 0x21:
                     var content = Buffer.alloc(buffer.length - 4);
                     buffer.copy(content, 0, 3, buffer.length);
                     result = new GetMAN_CFG(content);
                     if (typeof (hGetManualSetting) === "function") {
                            clearInterval(keepSending);
                            hGetManualSetting(result);
                      }
                      break;
                 case 0x22:
                      if (typeof (hSaveManualSetting) === "function") {
                          clearInterval(keepSending);
                          hSaveManualSetting(result);
                        }
                      break;
                case 0x50:
                      var content = Buffer.alloc(buffer.length - 4);
                      buffer.copy(content, 0, 3, buffer.length);
                      result = new GetMAN_CFGL2(content);
                      if (typeof (hSetManualSettingL2) === "function") {
                          clearInterval(keepSending);
                          hSetManualSettingL2(result);
                        }
                 break;
                case 0x51:
                     var content = Buffer.alloc(buffer.length - 4);
                     buffer.copy(content, 0, 3, buffer.length);
                     result = new GetMAN_CFGL2(content);                     
                     if (typeof (hGetManualSettingL2) === "function") {
                            clearInterval(keepSending);
                            hGetManualSettingL2(result);
                      }
                      break;
                 case 0x52:
                      if (typeof (hSaveManualSettingL2) === "function") {
                          clearInterval(keepSending);
                          hSaveManualSettingL2(result);
                        }
                      break;
                case 0x0A:
                      if (typeof (hSetPhoneBook) === "function") {
                          clearInterval(keepSending);
                          hSetPhoneBook(result);
                      }
                      break;
                case 0xFA:
                     var content = Buffer.alloc(buffer.length - 4);
                     buffer.copy(content, 0, 3, buffer.length);
                     result = new GetPHO_BOK(content);
                     if (typeof (hGetPhoneBook) === "function") {
                            clearInterval(keepSending);
                            hGetPhoneBook(result);
                     }
                    break;

                case 0x30: // ILS Button pressed on MSP -> Delete local_settings file in order to let script create the new default valued one
                        clearInterval(keepSending);
                        console.log("ILS RESET RICEVUTO!");
                        var local_settings_path   = '/home/root/TEF/tef/database/local_settings.ini';
                        fs.exists(local_settings_path, function(exists) {
                          if(exists) {
                            fs.unlinkSync(local_settings_path);
                            SendFunction.ackIlsRest();
                            setTimeout(function() {
                                exec("reboot", puts);
                            }, 1000);
                          } else {
                            console.log("ERROR >> Deleting of local_settings NOT succeeded");
                          }
                        });
                        return false;
                    break;


                case 0x32: // Ack dall'MSP per riprodurre il file audio N....
                    //Determino il file da riprodurre
                    if(buffer.readUInt8(3) < 10){
                        content = "0" + buffer.readUInt8(3).toString();
                    }else{
                        content = buffer.readUInt8(3).toString();
                    }

                    if(buffer.readUInt8(3) < 5){
                            exec("/dev/dmg/play_wav.sh /dmg/audio_msg/" + content + ".wav " + AudioMaxLength, puts);
                            console.log("L'MSP concede la riproduzione audio. Riproduco quello ufficiale... N: " + content);   //Lo script si incazza se non lo trova?????????
                            setTimeout(function() {
                                SendFunction.FreeAudio("");
                                return false;
                            }, 11000);
                    }else{
                            content = "0" + (buffer.readUInt8(3) - 4).toString();
                            exec("/dev/dmg/play_wav.sh /tmp/tmp_" + content + ".wav " + AudioMaxLength, puts);
                            console.log("L'MSP concede la riproduzione audio. Riproduco il temporaneo... N: " + content);
                            setTimeout(function() {
                                SendFunction.FreeAudio("");
                                return false;
                            }, 11000);
                    }
                    break;


                case 0x31: // Richiesta dall'MSP di riprodurre il file audio N....
                    var FreeAudioSent = false;
                    var TimeStamp;
                    if(buffer.readUInt8(3) < 10){
                        content = "0" + buffer.readUInt8(3).toString();
                    }else{
                        content = buffer.readUInt8(3).toString();
                    }
                    console.log("Richiesta dall'MSP di riprodurre il file audio: " + content);
                    exec("/dev/dmg/play_wav.sh /dmg/audio_msg/" + content + ".wav " + AudioMaxLength, puts);  //Lo script si incazza se non lo trova?????????
                    console.log("/dev/dmg/play_wav.sh /dmg/audio_msg/" + content + ".wav " + AudioMaxLength);

                    setTimeout(function() {
                      TimeStamp = Date.now();
                      while (fs.existsSync("/dmg/audio_msg/playning")) {
                        if((Date.now() - TimeStamp) > (AudioMaxLength * 1000)){
                          console.log("Intervenuto timeout forzoso audio");
                          return false;
                          break;
                        }
                      }
                          SendFunction.FreeAudio("");
                          return false;
                    }, 1000);
                    break;


                case 0x33: // Ack dall'MSP per registrare il file audio N....
                    if(buffer.readUInt8(3) < 10){
                        content = "0" + buffer.readUInt8(3).toString();
                    }else{
                        content = buffer.readUInt8(3).toString();
                    }
                    console.log("L'MSP concede di registrare il file audio: " + content);
                    exec("/dev/dmg/rec_wav.sh /tmp/tmp_" + content + ".wav", puts);  //Lo script si incazza se non lo trova?????????
                    setTimeout(function() {
                        SendFunction.FreeAudio("");
                        return false;
                    }, 11000);
                    break;

                case 0x34:  // Ack FreeAudio
                    console.log("ACK del FreeAudio ricevuto dall'MSP.");
                    return false;
                    break;

                default:
                    console.log("WRONG 0xAA RECEIVED MESSAGE:");
                    console.log(buffer.toString("hex"));
                    return false;
                    break;
            }
            break;
        default:
            console.log("WRONG RECEIVED MESSAGE:");
            console.log(buffer.toString("hex"));
            return false;
            break;
    }
    return true;
};
