/**
 *
 */

 var fs = require('fs');
 var ini = require('ini');

var cmd_CMD_GET_CFG = "F1";

function isBitSet(byte, bit) {
    var value = byte & 0xFF;
    value = value >> bit;
    value = value & 0x01;
    if (value === 0x01) {
        return true;
    }
    return false;
}

var Parser = function (buffer) {
    if (Buffer.isBuffer(buffer) === true) {
        this.tefData = {};
        this.tefData.Typologie_TEF = "bibcpro";

        switch (buffer.readUInt8(4)) {
            case 1:
                 this.tefData.Typologie_BIBCPRO = "BI.BC.PRO1";
            break;
            case 2:
                this.tefData.Typologie_BIBCPRO = "BI.BC.PRO2";
            break;
            case 3:
                this.tefData.Typologie_BIBCPRO = "BI.BC.PRO3";
           break;
        }


        if (isBitSet(buffer[5], 1)) {
            this.tefData.Temps_Duree_Fixe_TMAX = "activee";
        } else {
            this.tefData.Temps_Duree_Fixe_TMAX = "pas_activee";
        }
        if (isBitSet(buffer[5], 0)) {
            this.tefData.Temps_Anti_Bavard_TAB = "activee";
        } else {
            this.tefData.Temps_Anti_Bavard_TAB = "pas_activee";
        }

        this.tefData.Temps_Anti_Bavard_TAB_sec = buffer.readUInt8(7) + 30;
        this.tefData.Temps_Mise_A_Repos_No_Rep_sec = buffer.readUInt8(9) + 10;
       console.log('byte 17 = ' + buffer[17] );
        if (isBitSet(buffer[17], 0) === true) {
          console.log('Activation_Tonalite_Invitation_Transmettre = activee');
            this.tefData.Activation_Tonalite_Invitation_Transmettre = "activee";
        } else {
          console.log('Activation_Tonalite_Invitation_Transmettre = pas_activee');
            this.tefData.Activation_Tonalite_Invitation_Transmettre = "pas_activee";
        }

          this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec=(buffer.readUInt8(21) *100 );
        if (isBitSet(buffer[5], 5)) {
            this.tefData.Modalite_Communication = "half_duplex";
        } else {
            this.tefData.Modalite_Communication = "full_duplex";
        }
        if (isBitSet(buffer[6], 2)) {
            this.tefData.Detection_Occupation_Liberation = "activee";
        } else {
            this.tefData.Detection_Occupation_Liberation = "pas_activee";
        }
        this.tefData.Temps_Mise_A_Repos_sec = buffer.readUInt8(10);
        if (isBitSet(buffer[5], 7)) {
            this.tefData.Modalite_Reponse = "ecoute_discrete";
        } else {
            if (isBitSet(buffer[5], 6)) {
                this.tefData.Modalite_Reponse = "decrochage_automatique";
            } else {
                this.tefData.Modalite_Reponse = "decrochage_manuel";
            }
        }
        this.tefData.Nombre_Trains_Sonnerie = buffer.readUInt8(11);
        this.tefData.Niveau_Emission_Ligne_Analogique_dB = -buffer.readUInt8(12);
        this.tefData.Duree_Signalisation_Associee_Bouton_R_msec = (buffer.readUInt8(22) * 10);

        this.tefData.Duree_Mark_msec=buffer.readUInt8(23)+65;
        this.tefData.Duree_Space_msec=buffer.readUInt8(24)+65;
        this.tefData.Echelle=buffer.readUInt8(25);
        this.tefData.Niveau_Emission_DTMF_dB=-buffer.readUInt8(26);


        this.tefData.Numerotation_1_Num_1=""
        this.tefData.Numerotation_2_Num_1=""
        this.tefData.Numerotation_3_Num_1=""

        var armsetting = require('../../models/armsetting')
        armsetting.init(false);
        this.tefData = armsetting.loadData(this.tefData, "BC");

    } else {
        this.message = cmd_CMD_GET_CFG;
    }
};

Parser.prototype.getTEFData = function () {
    return this.tefData;
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

//Command.prototype.getTEFType = function () {
//    return this.tefType;
//};
//
//Command.prototype.getBoard = function () {
//    return this.board;
//};
//
//Command.prototype.getFamily = function () {
//    return this.family;
//};
//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
