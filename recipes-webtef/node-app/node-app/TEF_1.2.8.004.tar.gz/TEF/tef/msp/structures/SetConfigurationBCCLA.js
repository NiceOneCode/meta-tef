/**
 *
 */

function unsetBit(num, bit) {
    return (num & ~(1 << bit));
}


function setBit(num, bit) {
    return (num | (1 << bit));
}

var buffer;

var Setter = function (tefData) {
    this.tefData = tefData;
    buffer = Buffer.alloc(34);

    /*
     * Version Configuration
     */
    buffer[0] = 0x01;
    buffer[1] = 0x00;
    buffer[2] = 0x00;
    buffer[3] = 0x00;
    buffer[4] = 0x04;

    switch (this.tefData.Temps_Duree_Fixe_TMAX) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
    }

    switch (this.tefData.Temps_Anti_Bavard_TAB) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (unsetBit(buffer[5], 0) & 0xFF);
            break;
    }

    buffer.writeUInt8(this.tefData.Temps_Anti_Bavard_TAB_sec - 30, 7);
    buffer.writeUInt8(30, 8);
    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_No_Rep_sec - 10, 9);

    buffer.writeUInt8(this.tefData.Temporisation_Attente_Numerotation_sec, 28);
    buffer.writeUInt8(this.tefData.Temps_Attente_Code_Deblocage_Clavier_sec,27);

    var app= Buffer.from( this.tefData.Code_Deblocage);
    console.log ( ' APP  is ' + app );
    for (i=0 ; i<5 ; i++)
    {
       buffer[29+i]=app[i]-48;
    }

    switch (this.tefData.Activation_Tonalite_Invitation_Transmettre) {
        case  "activee":
            buffer[17] = (setBit(buffer[17], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[17] = (unsetBit(buffer[17], 0) & 0xFF);
            break;
    }
    buffer.writeUInt8(this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec /100,21);



    switch (this.tefData.Modalite_Communication) {
        case  "half_duplex":
            buffer[5] = (setBit(buffer[5], 5) & 0xFF);
            break;
        case "full_duplex":
            buffer[5] = (unsetBit(buffer[5], 5) & 0xFF);
            break;
    }

    switch (this.tefData.Detection_Occupation_Liberation) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 2) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 2) & 0xFF);
            break;
    }

    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_sec, 10);

    switch (this.tefData.Modalite_Reponse) {
        case "ecoute_discrete":
            buffer[5] = (setBit(buffer[5], 7) & 0xFF);
            break;
        case "decrochage_automatique":
            buffer[5] = (setBit(buffer[5], 6) & 0xFF);
            break;
        case "decrochage_manuel":
            buffer[5] = (unsetBit(buffer[5], 7) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 6) & 0xFF);
            break;
    }
    buffer.writeUInt8(this.tefData.Nombre_Trains_Sonnerie, 11);
    var Niveau_Emission_Ligne_Analogique_dB_Val = this.tefData.Niveau_Emission_Ligne_Analogique_dB;
    if (Niveau_Emission_Ligne_Analogique_dB_Val < 0) Niveau_Emission_Ligne_Analogique_dB_Val * (-1);
    buffer.writeUInt8(Niveau_Emission_Ligne_Analogique_dB_Val, 12);

    buffer.writeUInt8((this.tefData.Duree_Signalisation_Associee_Bouton_R_msec /10), 22);

    buffer.writeUInt8((this.tefData.Duree_Mark_msec-65),23);
    buffer.writeUInt8((this.tefData.Duree_Space_msec-65),24);
    buffer.writeUInt8(this.tefData.Echelle,25);
    buffer.writeUInt8(-this.tefData.Niveau_Emission_DTMF_dB,26);

    var armsetting = require('../../models/armsetting');
    armsetting.save_arm_setting(this.tefData);

};

Setter.prototype.setTEFData = function (tefData) {
    this.tefData = tefData;
};

Setter.prototype.getString = function () {
    return buffer.toString("hex");
};

module.exports = Setter;
