/**
 *
 */
var cmd_CMD_GET_CFG = "F1";

function isBitSet(byte, bit) {
    var value = byte & 0xFF;
    value = value >> bit;
    value = value & 0x01;
    if (value === 0x01) {
        return true;
    }
    return false;
}



var Parser = function (buffer) {

        console.log("Analisi configurazione HI");
    if (Buffer.isBuffer(buffer) === true) {
        this.tefData = {};
        this.tefData.Typologie_TEF = "hi";




        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 5
        if (isBitSet(buffer[5], 0)) {
            this.tefData.Temps_Anti_Bavard_TAB = "activee";
        } else {
            this.tefData.Temps_Anti_Bavard_TAB = "pas_activee";
        }

        if (isBitSet(buffer[5], 1)) {
            this.tefData.Temps_Duree_Fixe_TMAX = "activee";
        } else {
            this.tefData.Temps_Duree_Fixe_TMAX = "pas_activee";
        }

        if (isBitSet(buffer[5], 2)) {
            this.tefData.Module_Interface_Aerienne_L1 = "present";
        } else {
            this.tefData.Module_Interface_Aerienne_L1 = "pas_present";
        }

        if (isBitSet(buffer[5], 3)) {
          if (isBitSet(buffer[5], 4)) {
              this.tefData.Sonnerie = "emission_sonnerie_pilotage_extension_sonnerie";
          } else {
              this.tefData.Sonnerie = "emission_sonnerie";
          }
        } else {
            if (isBitSet(buffer[5], 4)) {
                this.tefData.Sonnerie = "pilotage_extension_sonnerie";
            } else {
                this.tefData.Sonnerie = "aucune_sonnerie";
            }
        }

        if (isBitSet(buffer[5], 5)) {
            this.tefData.Modalite_Communication_L1 = "half_duplex";
        } else {
            this.tefData.Modalite_Communication_L1 = "full_duplex";
        }

        if (isBitSet(buffer[5], 7)) {
            this.tefData.Modalite_Reponse_L1 = "ecoute_discrete";
        } else {
            if (isBitSet(buffer[5], 6)) {
                this.tefData.Modalite_Reponse_L1 = "decrochage_automatique";
            } else {
                this.tefData.Modalite_Reponse_L1 = "decrochage_manuel";
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 6
        if (isBitSet(buffer[6], 2)) {
            this.tefData.Detection_Occupation_Liberation_L1 = "activee";
        } else {
            this.tefData.Detection_Occupation_Liberation_L1 = "pas_activee";
        }

        if (isBitSet(buffer[6], 3)) {
            this.tefData.Typologie_Signalisation = "2200Hz";
        } else {
            this.tefData.Typologie_Signalisation = "50Hz";
        }

        if (isBitSet(buffer[6], 4)) {
            this.tefData.Relais_MTR = "activee";
        } else {
            this.tefData.Relais_MTR = "pas_activee";
        }

        if (isBitSet(buffer[6], 5)) {
            this.tefData.Type_Ligne_L1 = "4_fils";
        } else {
            this.tefData.Type_Ligne_L1 = "2_fils";
        }


        if (isBitSet(buffer[6], 6)) {
            this.tefData.Signalisation_Retour_Appel_L1 = "activee";
        } else {
            this.tefData.Signalisation_Retour_Appel_L1 = "pas_activee";
        }

        // if (isBitSet(buffer[6], 7)) {
        //     this.tefData.Type_Ligne_L2 = "4_fils";
        // } else {
        //     this.tefData.Type_Ligne_L2 = "2_fils";
        // }


        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 7
        this.tefData.Temps_Anti_Bavard_TAB_sec = buffer.readUInt8(7) + 30;
        //Byte 8 - E' fisso a 30

        //Byte 9
        this.tefData.Temps_Mise_A_Repos_No_Rep_L1_sec = buffer.readUInt8(9) + 10;
        this.tefData.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec = buffer.readUInt8(10);
        this.tefData.Nombre_Trains_Sonnerie_L1 = buffer.readUInt8(11);
        this.tefData.Niveau_Emission_Ligne_Analogique_dB = -buffer.readUInt8(12);
        this.tefData.Duree_Sonnerie_Interieure_msec = buffer.readUInt8(13) * 200;
        this.tefData.Duree_Extention_Sonnerie_msec = buffer.readUInt8(14) * 200;

        //Bytes 15
        this.tefData.Duree_Signalisation_Retour_Appel_L1_msec = (buffer.readUInt8(15) * 200);

        //Byte 16
        this.tefData.Niveau_Signalisation_Retour_Appel_L1_dB = (-1) * buffer.readUInt8(16);

        //Byte 17
        if (isBitSet(buffer[17], 4) === true) {
            this.tefData.Impedance_Ligne_L1 = "HI";
        } else {
            this.tefData.Impedance_Ligne_L1 = "600_Ohm";
        }

        // if (isBitSet(buffer[17], 5) === true) {
        //     this.tefData.Impedance_Ligne_L2 = "HI";
        // } else {
        //     this.tefData.Impedance_Ligne_L2 = "600_Ohm";
        // }

        // if (isBitSet(buffer[17], 6) === true) {
        //     this.tefData.Priorite_Ligne = "L2";
        // } else {
        //     this.tefData.Priorite_Ligne = "L1";
        // }

        // if (isBitSet(buffer[17], 7) === true) {
        //     this.tefData.Modalite_Communication_L2 = "half_duplex";
        // } else {
        //     this.tefData.Modalite_Communication_L2 = "full_duplex";
        // }


        //Byte 18 - Stato pannello solare - Non assoggettabile ad una SET - Panneau_solaire_etat
        this.tefData.Panneau_solaire_etat = buffer.readUInt8(18);
        //Byte 19 - Stato batteria - Non assoggettabile ad una SET - Batterie_etat
        this.tefData.Batterie_etat = buffer.readUInt8(19);
        //Byte 20 - Tipo alimentazione - Non assoggettabile ad una SET - Type_alimentation
        this.tefData.Type_alimentation = buffer.readUInt8(20);


        //this.tefData.Temporisation_Attente_Numerotation_sec = buffer.readUInt8(28);
        //this.tefData.Temps_Attente_Code_Deblocage_Clavier_sec = buffer.readUInt8(27);

        //Bytes da 29 a 33   //NON USATO ???????????????????
        // var app =  new Buffer(5, 0);
        // for (i=0 ; i<5 ; i++)
        // {
        //     app[i]=buffer[29+i] +48;
        //     // console.log(' app ' +i + ' value ' + buffer[29+i] );
        //     // app[i]=app[i]+48;
        // }
        //this.tefData.Code_Deblocage = app.toString();



        //this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec=(buffer.readUInt8(21) *100 );
        //this.tefData.Duree_Signalisation_Associee_Bouton_R_msec = (buffer.readUInt8(22) * 10);
        //this.tefData.Duree_Mark_msec=buffer.readUInt8(23)+65;
        //this.tefData.Duree_Space_msec=buffer.readUInt8(24)+65;
        //this.tefData.Echelle=buffer.readUInt8(25);
        //this.tefData.Niveau_Emission_DTMF_dB=-buffer.readUInt8(26);

        //Byte 34
        this.tefData.Duree_Signalisation_En_Sortie_L1_msec = (buffer.readUInt8(34) * 200);

        //Byte 35
        //this.tefData.Duree_Signal_50Hz_En_Sortie_msec=buffer.readUInt8(35) * 200;

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        //Byte 36
        if (isBitSet(buffer[36], 0)) {
            this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1 = "activee";
        } else {
            this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1 = "pas_activee";
        }

        if (isBitSet(buffer[36], 1)) {
            this.tefData.Emission_Message_Vocal_Mode_Attente_L1 = "activee";
        } else {
            this.tefData.Emission_Message_Vocal_Mode_Attente_L1 = "pas_activee";
        }

        // if (isBitSet(buffer[36], 2)) {
        //     this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2 = "activee";
        // } else {
        //     this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2 = "pas_activee";
        // }

        // if (isBitSet(buffer[36], 3)) {
        //     this.tefData.Emission_Message_Vocal_Mode_Attente_L2 = "activee";
        // } else {
        //     this.tefData.Emission_Message_Vocal_Mode_Attente_L2 = "pas_activee";
        // }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        //Byte 37
        // if (isBitSet(buffer[37], 0)) {
        //     this.tefData.Module_cle = "activee";
        // } else {
        //     this.tefData.Module_cle = "pas_activee";
        // }
        if (isBitSet(buffer[37], 1)) {
            this.tefData.Panneau_solaire = "activee";
        } else {
            this.tefData.Panneau_solaire = "pas_activee";
        }

        if (isBitSet(buffer[37], 2)) {
            this.tefData.Etat_recharge = "activee";
        } else {
            this.tefData.Etat_recharge = "pas_activee";
        }
        if (isBitSet(buffer[37], 3)) {
            this.tefData.Type_Batterie = "Rechargeable";
        } else {
            this.tefData.Type_Batterie = "Non_rechargeable";
        }

        if (isBitSet(buffer[37], 4)) {
            this.tefData.Sous_Seuil = 1;
        } else {
            this.tefData.Sous_Seuil = 0;
        }



        //Byte 38
        this.tefData.Niveau_de_sortie = -buffer.readUInt8(38);

        //Byte 39
        this.tefData.Niveau_entrant = -buffer.readUInt8(39);

        //Byte 40
        if (isBitSet(buffer[40], 0)) {
            this.tefData.Typologie_Signalisation_L1 = "5Tons";
        } else {
            this.tefData.Typologie_Signalisation_L1 = "2200Hz";
        }

        // if (isBitSet(buffer[40], 1)) {
        //     this.tefData.Typologie_Signalisation_L2 = "5Tons";
        // } else {
        //     this.tefData.Typologie_Signalisation_L2 = "2200Hz";
        // }
        if (isBitSet(buffer[40], 2)) {
            this.tefData.Mode_Attente_L1 = "avec_acquittement";
        } else {
            this.tefData.Mode_Attente_L1 = "sans_acquittement";
        }
        // if (isBitSet(buffer[40], 3)) {
        //     this.tefData.Mode_Attente_L2 = "avec_acquittement";
        // } else {
        //     this.tefData.Mode_Attente_L2 = "sans_acquittement";
        // }

        // if (isBitSet(buffer[40], 4)) {
        //     this.tefData.Detection_Occupation_Liberation_L2 = "activee";
        // } else {
        //     this.tefData.Detection_Occupation_Liberation_L2 = "pas_activee";
        // }

        // if (isBitSet(buffer[40], 6)) {
        //     this.tefData.Modalite_Reponse_L2 = "ecoute_discrete";
        // } else {
        //     if (isBitSet(buffer[40], 5)) {
        //         this.tefData.Modalite_Reponse_L2 = "decrochage_automatique";
        //     } else {
        //         this.tefData.Modalite_Reponse_L2 = "decrochage_manuel";
        //     }
        // }
        // if (isBitSet(buffer[40], 7)) {
        //     this.tefData.Signalisation_Retour_Appel_L2 = "activee";
        // } else {
        //     this.tefData.Signalisation_Retour_Appel_L2 = "pas_activee";
        // }

        //Byte 41
        //this.tefData.Duree_Signalisation_Retour_Appel_L2_msec = (buffer.readUInt8(41) * 200) + 1000;

        //Byte 42
        this.tefData.Duree_5Ton_L1 = buffer.readUInt8(42);

        //Byte 43
        //this.tefData.Duree_5Ton_L2 = buffer.readUInt8(43);

        //Byte 44-48 - Code_Identifiant_L1
        var Code_Identifiant_L1 = ""
        for (var i = 0; i<5; i++){
          switch(buffer.readUInt8(44+i)){
            case 0x00: Code_Identifiant_L1 = Code_Identifiant_L1 + "0";
            break;
            case 0x01: Code_Identifiant_L1 = Code_Identifiant_L1 + "1";
            break;
            case 0x02: Code_Identifiant_L1 = Code_Identifiant_L1 + "2";
            break;
            case 0x03: Code_Identifiant_L1 = Code_Identifiant_L1 + "3";
            break;
            case 0x04: Code_Identifiant_L1 = Code_Identifiant_L1 + "4";
            break;
            case 0x05: Code_Identifiant_L1 = Code_Identifiant_L1 + "5";
            break;
            case 0x06: Code_Identifiant_L1 = Code_Identifiant_L1 + "6";
            break;
            case 0x07: Code_Identifiant_L1 = Code_Identifiant_L1 + "7";
            break;
            case 0x08: Code_Identifiant_L1 = Code_Identifiant_L1 + "8";
            break;
            case 0x09: Code_Identifiant_L1 = Code_Identifiant_L1 + "9";
            break;
            case 0x0A: Code_Identifiant_L1 = Code_Identifiant_L1 + "A";
            break;
            case 0x0B: Code_Identifiant_L1 = Code_Identifiant_L1 + "B";
            break;
            case 0x0C: Code_Identifiant_L1 = Code_Identifiant_L1 + "D";
            break;
            case 0x0D: Code_Identifiant_L1 = Code_Identifiant_L1 + "R";
            break;
            case 0x0E: Code_Identifiant_L1 = Code_Identifiant_L1 + "G";
            break;
            }
          }
          this.tefData.Code_Identifiant_L1 = Code_Identifiant_L1;

          //Byte 49-53 - Code_Identifiant_L2
          // var Code_Identifiant_L2 = ""
          // for (var i = 0; i<5; i++){
          //   switch(buffer.readUInt8(49+i)){
          //     case 0x00: Code_Identifiant_L2 = Code_Identifiant_L2 + "0";
          //     break;
          //     case 0x01: Code_Identifiant_L2 = Code_Identifiant_L2 + "1";
          //     break;
          //     case 0x02: Code_Identifiant_L2 = Code_Identifiant_L2 + "2";
          //     break;
          //     case 0x03: Code_Identifiant_L2 = Code_Identifiant_L2 + "3";
          //     break;
          //     case 0x04: Code_Identifiant_L2 = Code_Identifiant_L2 + "4";
          //     break;
          //     case 0x05: Code_Identifiant_L2 = Code_Identifiant_L2 + "5";
          //     break;
          //     case 0x06: Code_Identifiant_L2 = Code_Identifiant_L2 + "6";
          //     break;
          //     case 0x07: Code_Identifiant_L2 = Code_Identifiant_L2 + "7";
          //     break;
          //     case 0x08: Code_Identifiant_L2 = Code_Identifiant_L2 + "8";
          //     break;
          //     case 0x09: Code_Identifiant_L2 = Code_Identifiant_L2 + "9";
          //     break;
          //     case 0x0A: Code_Identifiant_L2 = Code_Identifiant_L2 + "A";
          //     break;
          //     case 0x0B: Code_Identifiant_L2 = Code_Identifiant_L2 + "B";
          //     break;
          //     case 0x0C: Code_Identifiant_L2 = Code_Identifiant_L2 + "D";
          //     break;
          //     case 0x0D: Code_Identifiant_L2 = Code_Identifiant_L2 + "R";
          //     break;
          //     case 0x0E: Code_Identifiant_L2 = Code_Identifiant_L2 + "G";
          //     break;
          //     }
          //   }
          //   this.tefData.Code_Identifiant_L2 = Code_Identifiant_L2;

            //Byte 54
            //this.tefData.Niveau_Signalisation_Retour_Appel_L2_dB = buffer.readUInt8(54);

            //Byte 55
            this.tefData.Duree_Attente_Acquittement_L1_sec = (buffer.readUInt8(55) + 1) * 5;

            //Byte 56
            //this.tefData.Duree_Attente_Acquittement_L2_sec = (buffer.readUInt8(56) + 1) * 5;

            //Byte 57
            //this.tefData.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec = buffer.readUInt8(57) + 3;

            //Byte 58
            //this.tefData.Nombre_Trains_Sonnerie_L2 = buffer.readUInt8(58);

            //Byte 59
            //this.tefData.Temps_Mise_A_Repos_No_Rep_L2_sec = buffer.readUInt8(59) + 10;

            //Byte 60
            //this.tefData.Duree_Signalisation_En_Sortie_L2_msec = (buffer.readUInt8(60) * 200) + 2000;



        var armsetting = require('../../models/armsetting')
        armsetting.init(false);
        this.tefData = armsetting.loadData(this.tefData, "HI");

        console.log("Dal Parser Niveau_de_sortie=" +   this.tefData.Niveau_de_sortie + " Buffer: " + buffer.readUInt8(38));
        console.log("Dal Parser Niveau_entrant=" +   this.tefData.Niveau_entrant + " Buffer: " + buffer.readUInt8(39));

    } else {
      console.log("Dentro analisi configurazione HI - ELSE");
        this.message = cmd_CMD_GET_CFG;
    }
};

Parser.prototype.getTEFData = function () {
    return this.tefData;
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

//Command.prototype.getTEFType = function () {
//    return this.tefType;
//};
//
//Command.prototype.getBoard = function () {
//    return this.board;
//};
//
//Command.prototype.getFamily = function () {
//    return this.family;
//};
//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
