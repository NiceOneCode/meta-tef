/**
 *
 */
var fs = require('fs');
var ini = require('ini');


var buffer;

var Setter = function (tefmanreg) {
    this.tefmanreg = tefmanreg;
    buffer = Buffer.alloc(4);


    buffer.writeUInt8(this.tefmanreg.Audio_on, 0);
    buffer.writeUInt8(this.tefmanreg.Mic_on, 1);

    buffer.writeUInt8(-this.tefmanreg.Niveau_de_sortie, 2);
    buffer.writeUInt8(-this.tefmanreg.Niveau_entrant, 3);

};

Setter.prototype.setTEFmanreg = function (tefmanreg) {
    this.tefmanreg = tefmanreg;
};

Setter.prototype.getString = function () {
    return buffer.toString("hex");
};

module.exports = Setter;
