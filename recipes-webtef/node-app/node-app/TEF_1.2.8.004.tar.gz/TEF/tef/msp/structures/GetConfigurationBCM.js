/**
 *
 */
 var fs = require('fs');
 var ini = require('ini');

var cmd_CMD_GET_CFG = "F1";

function isBitSet(byte, bit) {
    var value = byte & 0xFF;
    value = value >> bit;
    value = value & 0x01;
    if (value === 0x01) {
        return true;
    }
    return false;
}

var Parser = function (buffer) {
    if (Buffer.isBuffer(buffer) === true) {
        this.tefData = {};
        this.tefData.Typologie_TEF = "bibcm";

        if (isBitSet(buffer[5], 1)) {
            this.tefData.Temps_Duree_Fixe_TMAX = "activee";
        } else {
            this.tefData.Temps_Duree_Fixe_TMAX = "pas_activee";
        }
        if (isBitSet(buffer[5], 0)) {
            this.tefData.Temps_Anti_Bavard_TAB = "activee";
        } else {
            this.tefData.Temps_Anti_Bavard_TAB = "pas_activee";
        }

        this.tefData.Temps_Anti_Bavard_TAB_sec = buffer.readUInt8(7) + 30;
        this.tefData.Temps_Mise_A_Repos_No_Rep_sec = buffer.readUInt8(9) + 10;
        if (isBitSet(buffer[5], 5)) {
            this.tefData.Modalite_Communication = "half_duplex";
        } else {
            this.tefData.Modalite_Communication = "full_duplex";
        }
        if (isBitSet(buffer[6], 2)) {
            this.tefData.Detection_Occupation_Liberation = "activee";
        } else {
            this.tefData.Detection_Occupation_Liberation = "pas_activee";
        }
        this.tefData.Temps_Mise_A_Repos_sec = buffer.readUInt8(10);
        if (isBitSet(buffer[5], 7)) {
            this.tefData.Modalite_Reponse = "ecoute_discrete";
        } else {
            if (isBitSet(buffer[5], 6)) {
                this.tefData.Modalite_Reponse = "decrochage_automatique";
            } else {
                this.tefData.Modalite_Reponse = "decrochage_manuel";
            }
        }
        this.tefData.Nombre_Trains_Sonnerie = buffer.readUInt8(11);
        this.tefData.Niveau_Emission_Ligne_Analogique_dB = -buffer.readUInt8(12);
        var armsetting = require('../../models/armsetting')
        armsetting.init(false);
        this.tefData = armsetting.loadData(this.tefData, "BC");
    } else {
        this.message = cmd_CMD_GET_CFG;
    }
};

Parser.prototype.getTEFData = function () {
    return this.tefData;
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

//Command.prototype.getTEFType = function () {
//    return this.tefType;
//};
//
//Command.prototype.getBoard = function () {
//    return this.board;
//};
//
//Command.prototype.getFamily = function () {
//    return this.family;
//};
//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
