/**
 *
 */
 var fs = require('fs');
 var ini = require('ini');

var cmd_CMD_GET_MAN = "50";


var Parser = function (buffer) {

    if (Buffer.isBuffer(buffer) === true) {
        this.tefmanreg = {};
        for( i=0; i< 4; i++)
        {
          buffer[i]=(buffer[i] & 0x7F);
        }

        this.tefmanreg.Audio_on = buffer.readUInt8(0);
        this.tefmanreg.Mic_on = buffer.readUInt8(1);
        this.tefmanreg.Niveau_de_sortie = -buffer.readUInt8(2);
        this.tefmanreg.Niveau_entrant = -buffer.readUInt8(3);
        this.tefmanreg.Alfa =(-1*(this.tefmanreg.Niveau_de_sortie + 15));

    } else {
        this.message = cmd_CMD_GET_MAN;
    }
};

Parser.prototype.getTEFmanreg = function () {
    return this.tefmanreg;
};

Parser.prototype.getCode = function () {
    return "50";
};

Parser.prototype.getMessage = function () {
    return this.message;
};




module.exports = Parser;
