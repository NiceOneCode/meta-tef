/**
 *
 */
var cmd_CMD_GET_CFG = "F1";

function isBitSet(byte, bit) {
    var value = byte & 0xFF;
    value = value >> bit;
    value = value & 0x01;
    if (value === 0x01) {
        return true;
    }
    return false;
}



var Parser = function (buffer) {

        console.log("Analisi configurazione BL");
    if (Buffer.isBuffer(buffer) === true) {
        this.tefData = {};
        this.tefData.Typologie_TEF = "bibl";




        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 5
        if (isBitSet(buffer[5], 0)) {
            this.tefData.Temps_Anti_Bavard_TAB = "activee";
        } else {
            this.tefData.Temps_Anti_Bavard_TAB = "pas_activee";
        }

        if (isBitSet(buffer[5], 1)) {
            this.tefData.Temps_Duree_Fixe_TMAX = "activee";
        } else {
            this.tefData.Temps_Duree_Fixe_TMAX = "pas_activee";
        }

        if (isBitSet(buffer[5], 2)) {
            this.tefData.Module_Interface_Aerienne = "present";
        } else {
            this.tefData.Module_Interface_Aerienne = "pas_present";
        }

        if (isBitSet(buffer[5], 3)) {
          if (isBitSet(buffer[5], 4)) {
              this.tefData.Sonnerie = "emission_sonnerie_pilotage_extension_sonnerie";
          } else {
              this.tefData.Sonnerie = "emission_sonnerie";
          }
        } else {
            if (isBitSet(buffer[5], 4)) {
                this.tefData.Sonnerie = "pilotage_extension_sonnerie";
            } else {
                this.tefData.Sonnerie = "aucune_sonnerie";
            }
        }

        if (isBitSet(buffer[5], 5)) {
            this.tefData.Modalite_Communication = "half_duplex";
        } else {
            this.tefData.Modalite_Communication = "full_duplex";
        }

        if (isBitSet(buffer[5], 7)) {
            this.tefData.Modalite_Reponse = "ecoute_discrete";
        } else {
            if (isBitSet(buffer[5], 6)) {
                this.tefData.Modalite_Reponse = "decrochage_automatique";
            } else {
                this.tefData.Modalite_Reponse = "decrochage_manuel";
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 6
        if (isBitSet(buffer[6], 2)) {
            this.tefData.Detection_Occupation_Liberation = "activee";
        } else {
            this.tefData.Detection_Occupation_Liberation = "pas_activee";
        }

        if (isBitSet(buffer[6], 3)) {
            this.tefData.Typologie_Signalisation = "2200Hz";
        } else {
            this.tefData.Typologie_Signalisation = "50Hz";
        }

        if (isBitSet(buffer[6], 4)) {
            this.tefData.Relais_MTR = "activee";
        } else {
            this.tefData.Relais_MTR = "pas_activee";
        }

        if (isBitSet(buffer[6], 6)) {
            this.tefData.Signalisation_Retour_Appel = "activee";
        } else {
            this.tefData.Signalisation_Retour_Appel = "pas_activee";
        }



        /////////////////////////////////////////////////////////////////////////////////////////
        //Byte 7
        this.tefData.Temps_Anti_Bavard_TAB_sec = buffer.readUInt8(7) + 30;
        //Byte 8 - E' fisso a 30

        //Byte 9
        this.tefData.Temps_Mise_A_Repos_No_Rep_sec = buffer.readUInt8(9) + 10;
        this.tefData.Temps_Mise_A_Repos_sec = buffer.readUInt8(10);
        this.tefData.Nombre_Trains_Sonnerie = buffer.readUInt8(11);
        this.tefData.Niveau_Emission_Ligne_Analogique_dB = -buffer.readUInt8(12);
        this.tefData.Duree_Sonnerie_Interieure_msec = buffer.readUInt8(13) * 200;
        this.tefData.Duree_Extention_Sonnerie_msec = buffer.readUInt8(14) * 200;

        //Bytes 15
        this.tefData.Duree_Emission_msec = (buffer.readUInt8(15) * 200);

        //Byte 16
        this.tefData.Niveau_Emission_dB = -buffer.readUInt8(16);

        //Byte 17   //NON USATO ???????????????????
        // if (isBitSet(buffer[17], 0) === true) {
        //     this.tefData.Activation_Tonalite_Invitation_Transmettre = "activee";
        // } else {
        //     this.tefData.Activation_Tonalite_Invitation_Transmettre = "pas_activee";
        // }

        //Byte 18 - Stato pannello solare - Non assoggettabile ad una SET - Panneau_solaire_etat
        this.tefData.Panneau_solaire_etat = buffer.readUInt8(18);
        //Byte 19 - Stato batteria - Non assoggettabile ad una SET - Batterie_etat
        this.tefData.Batterie_etat = buffer.readUInt8(19);
        //Byte 20 - Tipo alimentazione - Non assoggettabile ad una SET - Type_alimentation
        this.tefData.Type_alimentation = buffer.readUInt8(20);


        //this.tefData.Temporisation_Attente_Numerotation_sec = buffer.readUInt8(28);
        //this.tefData.Temps_Attente_Code_Deblocage_Clavier_sec = buffer.readUInt8(27);

        //Bytes da 29 a 33   //NON USATO ???????????????????
        // var app =  new Buffer(5, 0);
        // for (i=0 ; i<5 ; i++)
        // {
        //     app[i]=buffer[29+i] +48;
        //     // console.log(' app ' +i + ' value ' + buffer[29+i] );
        //     // app[i]=app[i]+48;
        // }
        //this.tefData.Code_Deblocage = app.toString();



        //this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec=(buffer.readUInt8(21) *100 );
        //this.tefData.Duree_Signalisation_Associee_Bouton_R_msec = (buffer.readUInt8(22) * 10);
        //this.tefData.Duree_Mark_msec=buffer.readUInt8(23)+65;
        //this.tefData.Duree_Space_msec=buffer.readUInt8(24)+65;
        //this.tefData.Echelle=buffer.readUInt8(25);
        //this.tefData.Niveau_Emission_DTMF_dB=-buffer.readUInt8(26);

        //Byte 34
        this.tefData.Duree_Signalisation_En_Sortie_msec=buffer.readUInt8(34) * 200;

        //Byte 35
        this.tefData.Duree_Signal_50Hz_En_Sortie_msec=buffer.readUInt8(35) * 200;

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        //Byte 36
        if (isBitSet(buffer[36], 0)) {
            this.tefData.Emission_Message_Vocal = "activee";
        } else {
            this.tefData.Emission_Message_Vocal = "pas_activee";
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        //Byte 37
        if (isBitSet(buffer[37], 0)) {
            this.tefData.Module_cle = "activee";
        } else {
            this.tefData.Module_cle = "pas_activee";
        }
        if (isBitSet(buffer[37], 1)) {
            this.tefData.Panneau_solaire = "activee";
        } else {
            this.tefData.Panneau_solaire = "pas_activee";
        }

        if (isBitSet(buffer[37], 2)) {
            this.tefData.Etat_recharge = "activee";
        } else {
            this.tefData.Etat_recharge = "pas_activee";
        }
        if (isBitSet(buffer[37], 3)) {
            this.tefData.Type_Batterie = "Rechargeable";
        } else {
            this.tefData.Type_Batterie = "Non_rechargeable";
        }

        if (isBitSet(buffer[37], 4)) {
            this.tefData.Sous_Seuil = 1;
        } else {
            this.tefData.Sous_Seuil = 0;
        }



        //Byte 38
        this.tefData.Niveau_de_sortie = -buffer.readUInt8(38);

        //Byte 39
        this.tefData.Niveau_entrant = -buffer.readUInt8(39);

        var armsetting = require('../../models/armsetting')
        armsetting.init(false);
        this.tefData = armsetting.loadData(this.tefData, "BL");

        console.log("Dal Parser Niveau_de_sortie=" +   this.tefData.Niveau_de_sortie + " Buffer: " + buffer.readUInt8(38));
        console.log("Dal Parser Niveau_entrant=" +   this.tefData.Niveau_entrant + " Buffer: " + buffer.readUInt8(39));

    } else {
      console.log("Dentro analisi configurazione BL - ELSE");
        this.message = cmd_CMD_GET_CFG;
    }
};

Parser.prototype.getTEFData = function () {
    return this.tefData;
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

//Command.prototype.getTEFType = function () {
//    return this.tefType;
//};
//
//Command.prototype.getBoard = function () {
//    return this.board;
//};
//
//Command.prototype.getFamily = function () {
//    return this.family;
//};
//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
