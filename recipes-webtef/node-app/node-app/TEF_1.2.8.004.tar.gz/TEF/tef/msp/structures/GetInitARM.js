/**
 *
 */

var cmd_CMD_GET_INIT_ARM = "FF";

var Parser = function (buffer) {
    if (Buffer.isBuffer(buffer) === true) {
        this.versionFirmware = `${buffer[3]}.${buffer[4]}.${buffer[5]}.${buffer[6]}`;
        this.versionConfiguration = `${buffer[7]}.${buffer[8]}.${buffer[9]}.${buffer[10]}`;
        this.tefType = buffer[11];
        this.board = buffer[12];
    } else {
        this.message = cmd_CMD_GET_INIT_ARM;
    }
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

Parser.prototype.getVersionFirmware = function () {
    return this.versionFirmware;
};

Parser.prototype.getVersionConfiguration = function () {
    return this.versionConfiguration;
};

Parser.prototype.getTEFType = function () {
    return this.tefType;
};

Parser.prototype.getBoard = function () {
    return this.board;
};

//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
