/**
 *
 */

function unsetBit(num, bit) {
    return (num & ~(1 << bit));
}


function setBit(num, bit) {
    return (num | (1 << bit));
}

var buffer;

var Setter = function (tefData) {
    this.tefData = tefData;
    buffer = Buffer.alloc(61);

    /*
     * Version Configuration
     */
    buffer[0] = 0x01;
    buffer[1] = 0x00;
    buffer[2] = 0x00;
    buffer[3] = 0x00;

    buffer[4] = 0x06;  //TEF tipo BL

    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 5
    switch (this.tefData.Temps_Anti_Bavard_TAB) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (unsetBit(buffer[5], 0) & 0xFF);
            break;
    }

    switch (this.tefData.Temps_Duree_Fixe_TMAX) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
    }

    //Module_Interface_Aerienne
    switch (this.tefData.Module_Interface_Aerienne) {
        case  "present":
            buffer[5] = (setBit(buffer[5], 2) & 0xFF);
            break;
        case "pas_present":
            buffer[5] = (unsetBit(buffer[5], 2) & 0xFF);
            break;
    }


    switch (this.tefData.Sonnerie) {
        //00
        case "aucune_sonnerie":
          buffer[5] = (unsetBit(buffer[5], 4) & 0xFF);
          buffer[5] = (unsetBit(buffer[5], 3) & 0xFF);
          break;

        //01
        case "emission_sonnerie":
            buffer[5] = (setBit(buffer[5], 3) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 4) & 0xFF);
            break;

        //10
        case "pilotage_extension_sonnerie":
            buffer[5] = (setBit(buffer[5], 4) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 3) & 0xFF);
            break;

        //11
        case "emission_sonnerie_pilotage_extension_sonnerie":
            buffer[5] = (setBit(buffer[5], 4) & 0xFF);
            buffer[5] = (setBit(buffer[5], 3) & 0xFF);
            break;
    }

    switch (this.tefData.Modalite_Communication) {
        case  "half_duplex":
            buffer[5] = (setBit(buffer[5], 5) & 0xFF);
            break;
        case "full_duplex":
            buffer[5] = (unsetBit(buffer[5], 5) & 0xFF);
            break;
    }

    switch (this.tefData.Modalite_Reponse) {
        case "ecoute_discrete":
            buffer[5] = (setBit(buffer[5], 7) & 0xFF);
            break;
        case "decrochage_automatique":
            buffer[5] = (setBit(buffer[5], 6) & 0xFF);
            break;
        case "decrochage_manuel":
            buffer[5] = (unsetBit(buffer[5], 7) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 6) & 0xFF);
            break;
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 6
    switch (this.tefData.Detection_Occupation_Liberation) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 2) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 2) & 0xFF);
            break;
    }

    switch (this.tefData.Typologie_Signalisation) {
        case  "2200Hz":
            buffer[6] = (setBit(buffer[6], 3) & 0xFF);
            break;
        case "50Hz":
            buffer[6] = (unsetBit(buffer[6], 3) & 0xFF);
            break;
    }

    switch (this.tefData.Relais_MTR) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 4) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 4) & 0xFF);
            break;
    }

    switch (this.tefData.Signalisation_Retour_Appel) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 6) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 6) & 0xFF);
            break;
    }


    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 7
    buffer.writeUInt8(this.tefData.Temps_Anti_Bavard_TAB_sec - 30, 7);
    //Byte 8
    buffer.writeUInt8(30, 8);
    //Byte 9
    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_No_Rep_sec - 10, 9);
    //Byte 10
    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_sec, 10);
    //Byte 11
    buffer.writeUInt8(this.tefData.Nombre_Trains_Sonnerie, 11);
    //Byte 12
    buffer.writeUInt8(Niveau_Emission_Ligne_Analogique_dB_Val, 12);
    //Byte 13
    buffer.writeUInt8(this.tefData.Duree_Sonnerie_Interieure_msec / 200, 13);    //Da calcolare???
    //Byte 14
    buffer.writeUInt8(this.tefData.Duree_Extention_Sonnerie_msec / 200, 14);    //Da calcolare???

    //Bytes 15
    buffer.writeUInt8((this.tefData.Duree_Emission_msec / 200), 15);

    //Byte 16
    buffer.writeUInt8(-this.tefData.Niveau_Emission_dB, 16);


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 17
    //NON USATO ???????????????????
    // switch (this.tefData.Activation_Tonalite_Invitation_Transmettre) {
    //     case  "activee":
    //         buffer[17] = (setBit(buffer[17], 0) & 0xFF);
    //         break;
    //     case "pas_activee":
    //         buffer[17] = (unsetBit(buffer[17], 0) & 0xFF);
    //         break;
    // }

    //Byte 18 - Stato pannello solare - Non assoggettabile ad una SET - Panneau_solaire_etat
    //Byte 19 - Stato batteria - Non assoggettabile ad una SET - Batterie_etat
    //Byte 20 - Tipo alimentazione - Non assoggettabile ad una SET - Type_alimentation

    //Byte 21  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec /100,21);
    //Byte 22  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Signalisation_Associee_Bouton_R_msec /10), 22);
    //Byte 23  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Mark_msec-65),23);
    //Byte 24  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Space_msec-65),24);
    //Byte 25  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Echelle,25);
    //Byte 26  //NON USATO ???????????????????
    //buffer.writeUInt8(-this.tefData.Niveau_Emission_DTMF_dB,26);
    //Byte 27  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temps_Attente_Code_Deblocage_Clavier_sec,27);
    //Byte 28  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temporisation_Attente_Numerotation_sec, 28);

    //Bytes da 29 a 33   //NON USATO ???????????????????
    // var app= Buffer.from( this.tefData.Code_Deblocage);
    // console.log ( ' APP  is ' + app );
    // for (i=0 ; i<5 ; i++)
    // {
    //    buffer[29+i]=app[i]-48;
    // }

    //Byte 34
    buffer.writeUInt8(this.tefData.Duree_Signalisation_En_Sortie_msec / 200, 34);    //Da calcolare???

    //Byte 35
    buffer.writeUInt8(this.tefData.Duree_Signal_50Hz_En_Sortie_msec / 200, 35);    //Da calcolare???

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 36
    switch (this.tefData.Emission_Message_Vocal) {
        case  "activee":
            buffer[36] = (setBit(buffer[36], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[36] = (unsetBit(buffer[36], 0) & 0xFF);
            break;
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 37
    switch (this.tefData.Module_cle) {
        case  "activee":
            buffer[37] = (setBit(buffer[37], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[37] = (unsetBit(buffer[37], 0) & 0xFF);
            break;
    }
    switch (this.tefData.Panneau_solaire) {
        case  "activee":
            buffer[37] = (setBit(buffer[37], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[37] = (unsetBit(buffer[37], 1) & 0xFF);
            break;
    }
    switch (this.tefData.Type_Batterie) {
        case  "Rechargeable":
            buffer[37] = (setBit(buffer[37], 3) & 0xFF);
            break;
        case "Non_rechargeable":
            buffer[37] = (unsetBit(buffer[37], 3) & 0xFF);
            break;
    }

    //Byte 38 -
    buffer.writeUInt8(-this.tefData.Niveau_de_sortie, 38);

    //Byte 39 -
    buffer.writeUInt8(-this.tefData.Niveau_entrant, 39);

    var Niveau_Emission_Ligne_Analogique_dB_Val = this.tefData.Niveau_Emission_Ligne_Analogique_dB;
    if (Niveau_Emission_Ligne_Analogique_dB_Val < 0) Niveau_Emission_Ligne_Analogique_dB_Val * (-1);

    var armsetting = require('../../models/armsetting');
    armsetting.save_arm_setting(this.tefData);

};

Setter.prototype.setTEFData = function (tefData) {
    this.tefData = tefData;
};

Setter.prototype.getString = function () {
    return buffer.toString("hex");
};

module.exports = Setter;
