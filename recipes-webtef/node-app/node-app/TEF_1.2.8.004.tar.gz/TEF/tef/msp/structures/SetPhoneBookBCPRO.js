/**
 *
 */
 var fs = require('fs');
 var ini = require('ini');


function unsetBit(num, bit) {
    return (num & ~(1 << bit));
}


function setBit(num, bit) {
    return (num | (1 << bit));
}

function decode(num)
{

   switch (num) {
     case 0x30:
     case 0x31:
     case 0x32:
     case 0x33:
     case 0x34:
     case 0x35:
     case 0x36:
     case 0x37:
     case 0x38:
     case 0x39:
          return(num-0x30);
       break;
     case 0x41:
     case 0x42:
     case 0x43:
     case 0x44:
          return(num-0x37);
     break;
     case 0x23:
          return(0xE);
     break
     case 0x2A:
          return(0xF);
     break
     default:
          return(0xFF);
   }
}

function encode(num)
{

   switch (num) {
     case 0x00:
     case 0x01:
     case 0x02:
     case 0x03:
     case 0x04:
     case 0x05:
     case 0x06:
     case 0x07:
     case 0x08:
     case 0x09:
          return(num+0x30);
       break;
     case 0x0A:
     case 0x0B:
     case 0x0C:
     case 0x0D:
          return(num+0x37);
     break;
     case 0x0E:
          return(0x23);
     break
     case 0x0F:
          return(0x2A);
     break
     default:
          return(0x00);
   }
}

var buffer;

var Setter = function(tefData) {
  this.tefData = tefData;
  buffer = Buffer.alloc(48);

  /*
   * Version Configuration
   */


  for (i = 0; i < 48; i++) {
    buffer[i] = 0xFF;
  }



  console.log( " tefData.Numerotation_1_Num_1  " + this.tefData.Numerotation_1_Num_1 );
  console.log( " tefData.Numerotation_2_Num_1  " + this.tefData.Numerotation_2_Num_1 );
  console.log( " tefData.Numerotation_3_Num_1  " + this.tefData.Numerotation_3_Num_1 );

  console.log( " this.tefData.Typologie_BIBCPRO  " + this.tefData.Typologie_BIBCPRO );

  var test =this.tefData.Numerotation_1_Num_1.toString();
  if(test.length > 0)
  {
    console.log("load 1");
    var app = Buffer.from(this.tefData.Numerotation_1_Num_1);
    for (i = 0; i < 16; i++) {
      buffer[i] = decode(app[i]);
    }
  }

  if (this.tefData.Typologie_BIBCPRO !== "BI.BC.PRO1")
  {

      if( typeof this.tefData.Numerotation_2_Num_1 !== 'undefined' && this.tefData.Numerotation_2_Num_1  !== null)
      {
          console.log("load 2");
          var app1 = Buffer.from(this.tefData.Numerotation_2_Num_1);
          for (i = 0; i < 16; i++) {
            buffer[16 + i] = decode(app1[i]);
          }
        }
        if (this.tefData.Typologie_BIBCPRO === "BI.BC.PRO3")
        {
          if( typeof this.tefData.Numerotation_3_Num_1 !== 'undefined' && this.tefData.Numerotation_3_Num_1  !== null)
          {
            console.log("load 3");
            var app2 = Buffer.from(this.tefData.Numerotation_3_Num_1);
            for (i = 0; i < 16; i++) {
            buffer[32 +i] = decode(app2[i]);
            }
          }
        }
 }

};

Setter.prototype.setTEFData = function (tefData) {
    this.tefData = tefData;
};

Setter.prototype.getString = function () {
    return buffer.toString("hex");
};

module.exports = Setter;
