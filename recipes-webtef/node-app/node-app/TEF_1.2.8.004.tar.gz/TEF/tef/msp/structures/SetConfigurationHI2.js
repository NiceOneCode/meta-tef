/**
 *
 */

function unsetBit(num, bit) {
    return (num & ~(1 << bit));
}


function setBit(num, bit) {
    return (num | (1 << bit));
}

var buffer;

var Setter = function (tefData) {
    this.tefData = tefData;
    buffer = Buffer.alloc(61);

    /*
     * Version Configuration
     */
    buffer[0] = 0x01;
    buffer[1] = 0x00;
    buffer[2] = 0x00;
    buffer[3] = 0x00;

    buffer[4] = 0x08;  //TEF tipo HI2

    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 5
    switch (this.tefData.Temps_Anti_Bavard_TAB) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (unsetBit(buffer[5], 0) & 0xFF);
            break;
    }

    switch (this.tefData.Temps_Duree_Fixe_TMAX) {
        case  "activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[5] = (setBit(buffer[5], 1) & 0xFF);
            break;
    }

    //Module_Interface_Aerienne
    switch (this.tefData.Module_Interface_Aerienne_L1) {
        case  "present":
            buffer[5] = (setBit(buffer[5], 2) & 0xFF);
            break;
        case "pas_present":
            buffer[5] = (unsetBit(buffer[5], 2) & 0xFF);
            break;
    }

    switch (this.tefData.Sonnerie) {
        //00
        case "aucune_sonnerie":
          buffer[5] = (unsetBit(buffer[5], 4) & 0xFF);
          buffer[5] = (unsetBit(buffer[5], 3) & 0xFF);
          break;

        //01
        case "emission_sonnerie":
            buffer[5] = (setBit(buffer[5], 3) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 4) & 0xFF);
            break;

        //10
        case "pilotage_extension_sonnerie":
            buffer[5] = (setBit(buffer[5], 4) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 3) & 0xFF);
            break;

        //11
        case "emission_sonnerie_pilotage_extension_sonnerie":
            buffer[5] = (setBit(buffer[5], 4) & 0xFF);
            buffer[5] = (setBit(buffer[5], 3) & 0xFF);
            break;
    }

    switch (this.tefData.Modalite_Communication_L1) {
        case  "half_duplex":
            buffer[5] = (setBit(buffer[5], 5) & 0xFF);
            break;
        case "full_duplex":
            buffer[5] = (unsetBit(buffer[5], 5) & 0xFF);
            break;
    }

    switch (this.tefData.Modalite_Reponse_L1) {
        case "ecoute_discrete":
            buffer[5] = (setBit(buffer[5], 7) & 0xFF);
            break;
        case "decrochage_automatique":
            buffer[5] = (setBit(buffer[5], 6) & 0xFF);
            break;
        case "decrochage_manuel":
            buffer[5] = (unsetBit(buffer[5], 7) & 0xFF);
            buffer[5] = (unsetBit(buffer[5], 6) & 0xFF);
            break;
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 6
    switch (this.tefData.Detection_Occupation_Liberation_L1) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 2) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 2) & 0xFF);
            break;
    }

    // Typologie_Signalisation
    buffer[6] = (setBit(buffer[6], 3) & 0xFF);


    switch (this.tefData.Relais_MTR) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 4) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 4) & 0xFF);
            break;
    }

    switch (this.tefData.Type_Ligne_L1) {
        case  "4_fils":
            buffer[6] = (setBit(buffer[6], 5) & 0xFF);
            break;
        case "2_fils":
            buffer[6] = (unsetBit(buffer[6], 5) & 0xFF);
            break;
    }


    switch (this.tefData.Signalisation_Retour_Appel_L1) {
        case  "activee":
            buffer[6] = (setBit(buffer[6], 6) & 0xFF);
            break;
        case "pas_activee":
            buffer[6] = (unsetBit(buffer[6], 6) & 0xFF);
            break;
    }

    switch (this.tefData.Type_Ligne_L2) {
        case  "4_fils":
            buffer[6] = (setBit(buffer[6], 7) & 0xFF);
            break;
        case "2_fils":
            buffer[6] = (unsetBit(buffer[6], 7) & 0xFF);
            break;
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    //Byte 7
    buffer.writeUInt8(this.tefData.Temps_Anti_Bavard_TAB_sec - 30, 7);
    //Byte 8
    buffer.writeUInt8(30, 8);
    //Byte 9
    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_No_Rep_L1_sec - 10, 9);
    //Byte 10
    buffer.writeUInt8(this.tefData.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec, 10);
    //Byte 11
    buffer.writeUInt8(this.tefData.Nombre_Trains_Sonnerie_L1, 11);
    //Byte 12
    buffer.writeUInt8(Niveau_Emission_Ligne_Analogique_dB_Val, 12);
    //Byte 13
    buffer.writeUInt8(this.tefData.Duree_Sonnerie_Interieure_msec / 200, 13);    //Da calcolare???
    //Byte 14
    buffer.writeUInt8(this.tefData.Duree_Extention_Sonnerie_msec / 200, 14);    //Da calcolare???
    //Bytes 15
    buffer.writeUInt8(((this.tefData.Duree_Signalisation_Retour_Appel_L1_msec) / 200), 15);
    //Byte 16
    buffer.writeUInt8(-this.tefData.Niveau_Signalisation_Retour_Appel_L1_dB, 16);


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 17
    switch (this.tefData.Impedance_Ligne_L1) {
        case  "HI":
            buffer[17] = (setBit(buffer[17], 4) & 0xFF);
            break;
        case "600_Ohm":
            buffer[17] = (unsetBit(buffer[17], 4) & 0xFF);
            break;
    }

    switch (this.tefData.Impedance_Ligne_L2) {
        case  "HI":
            buffer[17] = (setBit(buffer[17], 5) & 0xFF);
            break;
        case "600_Ohm":
            buffer[17] = (unsetBit(buffer[17], 5) & 0xFF);
            break;
    }

    switch (this.tefData.Priorite_Ligne) {
        case  "L2":
            buffer[17] = (setBit(buffer[17], 6) & 0xFF);
            break;
        case "L1":
            buffer[17] = (unsetBit(buffer[17], 6) & 0xFF);
            break;
    }

    switch (this.tefData.Modalite_Communication_L2) {
        case  "half_duplex":
            buffer[17] = (setBit(buffer[17], 7) & 0xFF);
            break;
        case "full_duplex":
            buffer[17] = (unsetBit(buffer[17], 7) & 0xFF);
            break;
    }


    //Byte 18 - Stato pannello solare - Non assoggettabile ad una SET - Panneau_solaire_etat
    //Byte 19 - Stato batteria - Non assoggettabile ad una SET - Batterie_etat
    //Byte 20 - Tipo alimentazione - Non assoggettabile ad una SET - Type_alimentation

    //Byte 21  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec /100,21);
    //Byte 22  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Signalisation_Associee_Bouton_R_msec /10), 22);
    //Byte 23  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Mark_msec-65),23);
    //Byte 24  //NON USATO ???????????????????
    //buffer.writeUInt8((this.tefData.Duree_Space_msec-65),24);
    //Byte 25  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Echelle,25);
    //Byte 26  //NON USATO ???????????????????
    //buffer.writeUInt8(-this.tefData.Niveau_Emission_DTMF_dB,26);
    //Byte 27  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temps_Attente_Code_Deblocage_Clavier_sec,27);
    //Byte 28  //NON USATO ???????????????????
    //buffer.writeUInt8(this.tefData.Temporisation_Attente_Numerotation_sec, 28);

    //Bytes da 29 a 33   //NON USATO ???????????????????
    // var app= Buffer.from( this.tefData.Code_Deblocage);
    // console.log ( ' APP  is ' + app );
    // for (i=0 ; i<5 ; i++)
    // {
    //    buffer[29+i]=app[i]-48;
    // }

    //Byte 34
    buffer.writeUInt8((this.tefData.Duree_Signalisation_En_Sortie_L1_msec) / 200, 34);

    //Byte 35
    //buffer.writeUInt8((this.tefData.Duree_Signalisation_En_Sortie_L2_msec) / 200, 34);   //Da calcolare???

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 36
    switch (this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L1) {
        case  "activee":
            buffer[36] = (setBit(buffer[36], 0) & 0xFF);
            break;
        case "pas_activee":
            buffer[36] = (unsetBit(buffer[36], 0) & 0xFF);
            break;
    }
    switch (this.tefData.Emission_Message_Vocal_Mode_Attente_L1) {
        case  "activee":
            buffer[36] = (setBit(buffer[36], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[36] = (unsetBit(buffer[36], 1) & 0xFF);
            break;
    }
    switch (this.tefData.Emission_Message_Vocal_Detection_Occupation_Liberation_L2) {
        case  "activee":
            buffer[36] = (setBit(buffer[36], 2) & 0xFF);
            break;
        case "pas_activee":
            buffer[36] = (unsetBit(buffer[36], 2) & 0xFF);
            break;
    }
    switch (this.tefData.Emission_Message_Vocal_Mode_Attente_L2) {
        case  "activee":
            buffer[36] = (setBit(buffer[36], 3) & 0xFF);
            break;
        case "pas_activee":
            buffer[36] = (unsetBit(buffer[36], 3) & 0xFF);
            break;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //Byte 37
    // switch (this.tefData.Module_cle) {
    //     case  "activee":
    //         buffer[37] = (setBit(buffer[37], 0) & 0xFF);
    //         break;
    //     case "pas_activee":
    //         buffer[37] = (unsetBit(buffer[37], 0) & 0xFF);
    //         break;
    // }
    switch (this.tefData.Panneau_solaire) {
        case  "activee":
            buffer[37] = (setBit(buffer[37], 1) & 0xFF);
            break;
        case "pas_activee":
            buffer[37] = (unsetBit(buffer[37], 1) & 0xFF);
            break;
    }

    switch (this.tefData.Type_Batterie) {
        case  "Rechargeable":
            buffer[37] = (setBit(buffer[37], 3) & 0xFF);
            break;
        case "Non_rechargeable":
            buffer[37] = (unsetBit(buffer[37], 3) & 0xFF);
            break;
    }

    //Byte 38 -
    buffer.writeUInt8(-this.tefData.Niveau_de_sortie, 38);

    //Byte 39 -
    buffer.writeUInt8(-this.tefData.Niveau_entrant, 39);

    var Niveau_Emission_Ligne_Analogique_dB_Val = this.tefData.Niveau_Emission_Ligne_Analogique_dB;
    if (Niveau_Emission_Ligne_Analogique_dB_Val < 0) Niveau_Emission_Ligne_Analogique_dB_Val * (-1);


    //Byte 40
    switch (this.tefData.Typologie_Signalisation_L1) {
        case  "2200Hz":
            buffer[40] = (unsetBit(buffer[40], 0) & 0xFF);
            break;
        case "5Tons":
            buffer[40] = (setBit(buffer[40], 0) & 0xFF);
            break;
    }
    switch (this.tefData.Typologie_Signalisation_L2) {
        case  "2200Hz":
            buffer[40] = (unsetBit(buffer[40], 1) & 0xFF);
            break;
        case "5Tons":
            buffer[40] = (setBit(buffer[40], 1) & 0xFF);
            break;
    }
    switch (this.tefData.Mode_Attente_L1) {
        case  "sans_acquittement":
            buffer[40] = (unsetBit(buffer[40], 2) & 0xFF);
            break;
        case "avec_acquittement":
            buffer[40] = (setBit(buffer[40], 2) & 0xFF);
            break;
    }
    switch (this.tefData.Mode_Attente_L2) {
        case  "sans_acquittement":
            buffer[40] = (unsetBit(buffer[40], 3) & 0xFF);
            break;
        case "avec_acquittement":
            buffer[40] = (setBit(buffer[40], 3) & 0xFF);
            break;
    }
    switch (this.tefData.Detection_Occupation_Liberation_L2) {
        case  "activee":
            buffer[40] = (setBit(buffer[40], 4) & 0xFF);
            break;
        case "pas_activee":
            buffer[40] = (unsetBit(buffer[40], 4) & 0xFF);
            break;
    }
    switch (this.tefData.Modalite_Reponse_L2) {
        case "ecoute_discrete":
            buffer[40] = (setBit(buffer[40], 6) & 0xFF);
            break;
        case "decrochage_automatique":
            buffer[40] = (setBit(buffer[40], 5) & 0xFF);
            break;
        case "decrochage_manuel":
            buffer[40] = (unsetBit(buffer[40], 6) & 0xFF);
            buffer[40] = (unsetBit(buffer[40], 5) & 0xFF);
            break;
    }
    switch (this.tefData.Signalisation_Retour_Appel_L2) {
        case  "activee":
            buffer[40] = (setBit(buffer[40], 7) & 0xFF);
            break;
        case "pas_activee":
            buffer[40] = (unsetBit(buffer[40], 7) & 0xFF);
            break;
    }


    //Byte 41
    buffer.writeUInt8(((this.tefData.Duree_Signalisation_Retour_Appel_L2_msec) / 200), 41);

    //Byte 42
    buffer.writeUInt8(this.tefData.Duree_5Ton_L1, 42);

    //Byte 43
    buffer.writeUInt8(this.tefData.Duree_5Ton_L2, 43);

    //Byte 44-48 - Code_Identifiant_L1
    var Code_Identifiant_L1 = Buffer.from(this.tefData.Code_Identifiant_L1, 'utf-8');
    for (var i = 0; i<5; i++){
      switch(Code_Identifiant_L1[i]){
        case 48: buffer.writeUInt8(0x00, (49+i));
        break;
        case 49: buffer.writeUInt8(0x01, (44+i));
        break;
        case 50: buffer.writeUInt8(0x02, (44+i));
        break;
        case 51: buffer.writeUInt8(0x03, (44+i));
        break;
        case 52: buffer.writeUInt8(0x04, (44+i));
        break;
        case 53: buffer.writeUInt8(0x05, (44+i));
        break;
        case 54: buffer.writeUInt8(0x06, (44+i));
        break;
        case 55: buffer.writeUInt8(0x07, (44+i));
        break;
        case 56: buffer.writeUInt8(0x08, (44+i));
        break;
        case 57: buffer.writeUInt8(0x09, (44+i));
        break;
        case 65: buffer.writeUInt8(0x0A, (44+i));
        break;
        case 66: buffer.writeUInt8(0x0B, (44+i));
        break;
        case 68: buffer.writeUInt8(0x0C, (44+i));
        break;
        case 82: buffer.writeUInt8(0x0D, (44+i));
        break;
        case 71: buffer.writeUInt8(0x0E, (44+i));
        break;
        case 97: buffer.writeUInt8(0x0A, (44+i));
        break;
        case 98: buffer.writeUInt8(0x0B, (44+i));
        break;
        case 100: buffer.writeUInt8(0x0C, (44+i));
        break;
        case 114: buffer.writeUInt8(0x0D, (44+i));
        break;
        case 103: buffer.writeUInt8(0x0E, (44+i));
        break;
      }
    }
      //Byte 49-53 - Code_Identifiant_L2
      var Code_Identifiant_L2 = Buffer.from(this.tefData.Code_Identifiant_L2, 'utf-8');
      for (var ii = 0; ii<5; ii++){
        switch(Code_Identifiant_L2[ii]){
          case 48: buffer.writeUInt8(0x00, (49+ii));
          break;
          case 49: buffer.writeUInt8(0x01, (49+ii));
          break;
          case 50: buffer.writeUInt8(0x02, (49+ii));
          break;
          case 51: buffer.writeUInt8(0x03, (49+ii));
          break;
          case 52: buffer.writeUInt8(0x04, (49+ii));
          break;
          case 53: buffer.writeUInt8(0x05, (49+ii));
          break;
          case 54: buffer.writeUInt8(0x06, (49+ii));
          break;
          case 55: buffer.writeUInt8(0x07, (49+ii));
          break;
          case 56: buffer.writeUInt8(0x08, (49+ii));
          break;
          case 57: buffer.writeUInt8(0x09, (49+ii));
          break;
          case 65: buffer.writeUInt8(0x0A, (49+ii));
          break;
          case 66: buffer.writeUInt8(0x0B, (49+ii));
          break;
          case 68: buffer.writeUInt8(0x0C, (49+ii));
          break;
          case 82: buffer.writeUInt8(0x0D, (49+ii));
          break;
          case 71: buffer.writeUInt8(0x0E, (49+ii));
          break;
          case 97: buffer.writeUInt8(0x0A, (49+ii));
          break;
          case 98: buffer.writeUInt8(0x0B, (49+ii));
          break;
          case 100: buffer.writeUInt8(0x0C, (49+ii));
          break;
          case 114: buffer.writeUInt8(0x0D, (49+ii));
          break;
          case 103: buffer.writeUInt8(0x0E, (49+ii));
          break;
        }

    }

    //Byte 54
    buffer.writeUInt8(-this.tefData.Niveau_Signalisation_Retour_Appel_L2_dB, 54);

    //Byte 55
    buffer.writeUInt8((this.tefData.Duree_Attente_Acquittement_L1_sec / 5) - 1, 55);

    //Byte 56
    buffer.writeUInt8((this.tefData.Duree_Attente_Acquittement_L2_sec / 5) - 1, 56);

    //Byte 57
    buffer.writeUInt8(this.tefData.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec, 57);

    //Byte 58
    buffer.writeUInt8(this.tefData.Nombre_Trains_Sonnerie_L2, 58);

    //Byte 59
    buffer.writeUInt8(this.tefData.Temps_Mise_A_Repos_No_Rep_L2_sec - 10, 59);

    //Byte 60
    buffer.writeUInt8((this.tefData.Duree_Signalisation_En_Sortie_L2_msec) / 200, 60);

    var Niveau_Emission_Ligne_Analogique_dB_Val = this.tefData.Niveau_Emission_Ligne_Analogique_dB;
    if (Niveau_Emission_Ligne_Analogique_dB_Val < 0) Niveau_Emission_Ligne_Analogique_dB_Val * (-1);


    var armsetting = require('../../models/armsetting');
    armsetting.save_arm_setting(this.tefData);

};

Setter.prototype.setTEFData = function (tefData) {
    this.tefData = tefData;
};

Setter.prototype.getString = function () {
    return buffer.toString("hex");
};

module.exports = Setter;
