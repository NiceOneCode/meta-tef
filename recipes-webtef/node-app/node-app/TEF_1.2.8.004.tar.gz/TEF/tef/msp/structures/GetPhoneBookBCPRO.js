/**
 *
 */

 var fs = require('fs');
 var ini = require('ini');

var cmd_CMD_GET_PHO_BK = "FA";

function isBitSet(byte, bit) {
    var value = byte & 0xFF;
    value = value >> bit;
    value = value & 0x01;
    if (value === 0x01) {
        return true;
    }
    return false;
}
function decode(num)
{

   switch (num) {
     case 0x30:
     case 0x31:
     case 0x32:
     case 0x33:
     case 0x34:
     case 0x35:
     case 0x36:
     case 0x37:
     case 0x38:
     case 0x39:
          return(num-0x30);
       break;
     case 0x41:
     case 0x42:
     case 0x43:
     case 0x44:
          return(num-0x37);
     break;
     case 0x23:
          return(0xE);
     break
     case 0x2A:
          return(0xF);
     break
     default:
          return(0xFF);
   }
}

function encode(num)
{

   switch (num) {
     case 0x00:
     case 0x01:
     case 0x02:
     case 0x03:
     case 0x04:
     case 0x05:
     case 0x06:
     case 0x07:
     case 0x08:
     case 0x09:
          return(num+0x30);
       break;
     case 0x0A:
     case 0x0B:
     case 0x0C:
     case 0x0D:
          return(num+0x37);
     break;
     case 0x0E:
          return(0x23);
     break
     case 0x0F:
          return(0x2A);
     break
     default:
          return(0x20);
   }
}


var Parser = function (buffer) {
    if (Buffer.isBuffer(buffer) === true) {
        this.tefData = {};
        var app =  new Buffer(16, 0);
        for (i=0 ; i<16 ; i++)
        {
            app[i]=encode(buffer[i]);

        }
        var textChunk = app.toString('utf8');
        this.tefData.Numerotation_1_Num_1 ="";
        if(textChunk.length > 0)
        {
            this.tefData.Numerotation_1_Num_1 = textChunk.trim();
        }
        var app1 =  new Buffer(16, 0);
        for (i=0 ; i<16 ; i++)
        {
            app1[i]=encode(buffer[i+16]);
        }

        var textChunk1 = app1.toString('utf8');
        this.tefData.Numerotation_2_Num_1 ="";
        // if(textChunk1.length > 0 && this.tefData.Typologie_BIBCPRO !== "BI.BC.PRO1")
        // {
        //    console.log( " textChunk1.length  " + textChunk1.length );
        //    console.log( " this.tefData.Typologie_BIBCPRO  " + this.tefData.Typologie_BIBCPRO );
        //
        // }

        if(textChunk1.length > 0 )
        {
            this.tefData.Numerotation_2_Num_1 = textChunk1.trim();
        }


        var app2 =  new Buffer(16, 0);
        for (i=0 ; i<16 ; i++)
        {
            app2[i]=encode(buffer[i+32]);
        }
        var textChunk2 = app2.toString('utf8');
        this.tefData.Numerotation_3_Num_1 ="";

      //  if(textChunk2.length > 0 && this.tefData.Typologie_BIBCPRO === "BI.BC.PRO3")
      //  {
      //
      //
      //   console.log( " textChunk2.length  " + textChunk2.length );
      //   console.log( " this.tefData.Typologie_BIBCPRO  " + this.tefData.Typologie_BIBCPRO );
      // }

        if(textChunk2.length > 0)
        {
            this.tefData.Numerotation_3_Num_1 = textChunk2.trim();
        }


    } else {
        this.message = cmd_CMD_GET_PHO_BK;
    }
};

Parser.prototype.getTEFData = function () {
    return this.tefData;
};

Parser.prototype.getCode = function () {
    return "FF";
};

Parser.prototype.getMessage = function () {
    return this.message;
};

//Command.prototype.getTEFType = function () {
//    return this.tefType;
//};
//
//Command.prototype.getBoard = function () {
//    return this.board;
//};
//
//Command.prototype.getFamily = function () {
//    return this.family;
//};
//Command.prototype.getFamilyName = function () {
//    switch (this.family) {
//
//    }
//};


module.exports = Parser;
