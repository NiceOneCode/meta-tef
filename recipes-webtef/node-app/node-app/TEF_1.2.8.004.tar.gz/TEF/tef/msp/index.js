/**
 *
 * @type {Module serialport|Module serialport}
 */

var checksum = require('./utils/checksum');

var tefInfo = require('./tefInfo');
var messageParser = require('./parser');


var SerialPort;
if (process.env.debug === "true") {
    SerialPort = require('serialport');
} else {
    SerialPort = require('../../lib/serialport');
}


//Reading configuration parameter for serial port settings
console.log("---------------------------------------------");
console.log("MSP <-> ARM  Serial port settings:");
var ini = require('ini');
var fs = require('fs');
if ( fs.existsSync(__dirname + '/../config/config.ini'))
{
  try
  {
    var config = ini.parse(fs.readFileSync(__dirname + '/../config/config.ini', 'utf-8'));

    if (isNaN(parseInt(config.serial_params.sending_interval, 10))){
      var sending_interval = parseInt("1500", 10);
    }
    else {
      var sending_interval = parseInt(config.serial_params.sending_interval, 10);
    }

    if (isNaN(parseInt(config.serial_params.retry, 10))){
      var retry = parseInt("20", 10);
    }
    else {
      var retry = parseInt(config.serial_params.retry, 10);
    }

    if (isNaN(parseInt(config.serial_params.serial_speed, 10))){
      var serial_speed = parseInt("9600", 10);
    }
    else {
      var serial_speed = parseInt(config.serial_params.serial_speed, 10);
    }
    console.log("From config.ini");
  }
  catch(e)
  {
      var sending_interval = parseInt("1500", 10);
      var retry = parseInt("20", 10);
      var serial_speed = parseInt("9600", 10);
      console.log("From default - Error reading config.ini");
  }

}
else
{
  var sending_interval = parseInt("1500", 10);
  var retry = parseInt("20", 10);
  var serial_speed = parseInt("9600", 10);
  console.log("From default - config.ini missing");
}

console.log("Sending interval: " + sending_interval);
console.log("Number of retry: " + retry);
console.log("Baud speed: " + serial_speed);
console.log("");



var serialPort;
var monitorConsole;
var isConnected = false;
var keepSending = false;
var busy = false;
var len;
var entireMessage;
var receivingStatus = 0; // 0 -> nothing, 1 -> AA received, 2 -> length received, 3 -> body receiving
// 11 -> 0x02 received

var Commands = require('./commands');
commands = new Commands(messageParser, sendMessage, sendRaw, sendMessageInitARM, sendRawInitARM);
module.exports.commands = commands;


serialPort = new SerialPort(process.env.serial_port, {
    baudRate: serial_speed,
    platformOptions: {
        vmin: 1,
        vtime: 0
    }
});

serialPort.on('open', function () {
    isConnected = false;
    /*commands.getInitARM(function (message) {
        isConnected = true;
        tefInfo.parseInitARM(message);
    });*/
});

serialPort.on('close', function() {
});

serialPort.on('data', function (data) {
    var buffer = Buffer.from(data);
    var keep = true;
    var i = 0;
    while (keep) {
        switch (receivingStatus) {
            case 0:
                if (buffer[i] === 0xAA) {
                    receivingStatus = 1;
                    entireMessage = Buffer.from([0xAA], 'hex');
                }
                if (buffer[i] === 0x02) {
                    receivingStatus = 11;
                    entireMessage = Buffer.from([0x02], 'hex');
                }
                break;
            case 1:
                len = buffer[i];
                entireMessage = Buffer.concat([entireMessage, Buffer.from([buffer[i]])]);
                receivingStatus = 2;
                break;
            case 2:
                entireMessage = Buffer.concat([entireMessage, Buffer.from([buffer[i]])]);
                break;
            case 11:
                entireMessage = Buffer.concat([entireMessage, Buffer.from([buffer[i]])]);
                if (buffer[i] === 0x03) {
                    console.log(`MSP -> ARM : ${entireMessage.toString('hex')}`);
                    messageParser.parse(entireMessage, keepSending);
                    receivingStatus = 0;
                    return;
                }
                break;
        }
        i++;
        if (i >= buffer.length) {
            keep = false;
        }
    }
    if (typeof entireMessage !== 'undefined' && entireMessage !== null) {
      if (len === entireMessage.length - 2) {
          receivingStatus = 0;
          console.log(`MSP -> ARM : ${entireMessage.toString('hex')}`);
          if (typeof (monitorConsole) === 'function') {
              monitorConsole(entireMessage);
            }
            messageParser.parse(entireMessage, keepSending);
          }
  }
});

serialPort.on('error', function () {
});

//msp.init(function (data) {
//    io.emit('serial_receive', {data: data.toString("hex")});
//}, function () {
//
//}, function () {
//});

var io = null;

module.exports.retryInitARM = function(callback){
  isConnected = false;
  commands.getInitARM(function (message) {
    //console.log(message);
      console.log("getInitArm finished");
      isConnected = true;
      tefInfo.parseInitARM(message);
      callback();
  });
};

module.exports.setWebSocket = function (moduleIO) {
    io = moduleIO;
};

module.exports.isConnected = function () {
    return isConnected;
};

module.exports.getTEFInfo = function () {
    return tefInfo;
};


module.exports.forward = function (msg, then) {
    var result = true;
    try {
        var message = Buffer.from(msg, 'hex');
        serialPort.write(message, function (err) {
            if (err) {
                result = false;
                console.log('Error on write: ', err.message);
            }
        });
    } catch (e) {
        result = false;
        console.log(e);
    }
    then(result);
};

module.exports.exit = function (then) {
    serialPort.close(then);
};

module.exports.firmwareUpdate = function (firmware) {


    console.log('######### 1')
    if (io !== null) {
        io.emit('logiciel_progress', {progress: 20});
    }
    commands.reboot(function () {
         console.log('######### 2')
        if (io !== null) {
            io.emit('logiciel_progress', {progress: 40});
        }
        commands.eraseFlash(function () {
            console.log('######### 3')
            if (io !== null) {
                io.emit('logiciel_progress', {progress: 60});
            }
            commands.sendFirmware(firmware, function () {
                console.log('######### 4')
                if (io !== null) {
                    io.emit('logiciel_progress', {progress: 80});
                }
                isConnected = false;
                commands.getInitARM(function (message) {
                    console.log('######### 5')
                    isConnected = true;
                    tefInfo.parseInitARM(message);
                    io.emit('logiciel_progress', {progress: 100});
                });
            });
        });
    });
};

function sendMessageInitARM(message, keep) {
    var strLength = parseInt((message.length / 2) + 1, 10).toString(16);
    if (strLength.length % 2 === 1) {
        strLength = "0" + strLength;
    }
    var body = strLength + message;
    var start = "AA";
//    var checksum = "FF";//checksum.calc(body);//crc.crc8(message).toString(16);
    var fullMessage = start + body + checksum.calc(body);
    sendRawInitARM(fullMessage, keep);
}

function sendRawInitARM(message, keep) {

     var counter = 0;
     var choose = false;
     var msg = Buffer.from(message.toUpperCase(), 'hex');

     if( keep === true )
     {

        keepSending = setInterval(function () {
          counter++;
          console.log(counter);
          /*
          * Comunicazione non riuscita: vuoi utilizzare l'interfaccia come editor?
          */
          if(process.env.debug === "false" && counter == retry){
            io.emit("alert_editor","");
            clearInterval(keepSending);
            counter = 0;
          }

        serialPort.write(msg, function (err) {
            if (err) {
                return console.log('Error on write: ', err.message);
            }
            console.log( "ARM -> MSP");
            console.log(msg);
         });
       }, sending_interval);

    }
    else {
      console.log( "ARM -> MSP");
      console.log(msg);
      serialPort.write(msg, function (err) {
          if (err) {
              return console.log('Error on write: ', err.message);
          }
       });
    }

}

function sendRaw(message, keep) {
     var counter = 0;
     var msg = Buffer.from(message.toUpperCase(), 'hex');
     if( keep === true )
     {
        keepSending = setInterval(function () {
          counter++;
          if(process.env.debug === "false" && counter == retry){
            isConnected = false;
            io.emit("redirect_no_tef","");
            clearInterval(keepSending);
          }

        serialPort.write(msg, function (err) {
            if (err) {
                return console.log('Error on write: ', err.message);
            }
            console.log( "ARM -> MSP");
            console.log(msg);
         });
       }, sending_interval);

    }
    else {
      console.log( "ARM -> MSP");
      console.log(msg);
      serialPort.write(msg, function (err) {
          if (err) {
              return console.log('Error on write: ', err.message);
          }
       });
    }

}

function sendMessage(message, keep) {
    var strLength = parseInt((message.length / 2) + 1, 10).toString(16);
    if (strLength.length % 2 === 1) {
        strLength = "0" + strLength;
    }
    var body = strLength + message;
    var start = "AA";
//    var checksum = "FF";//checksum.calc(body);//crc.crc8(message).toString(16);
    var fullMessage = start + body + checksum.calc(body);
    sendRaw(fullMessage, keep);
}

module.exports.ackIlsRest = function () {
  sendMessage("30", false);
  console.log("ACK INVIATO");
}

//Invia all'MSP la richiesta di riprodurre il file audio N.... ed attende l'ACK
module.exports.PlayMSG = function (msg) {
  sendMessage("32" + msg, false);
  console.log("Richiesta facoltà di riprodurre il file audio n." + msg + ".");
}

//Invia all'MSP la richiesta di registrare il file audio N.... ed attende l'ACK
module.exports.RecMSG = function (msg) {
  sendMessage("33" + msg, false);
  console.log("Richiesta di registrare il file audio n." + msg + ".");
}

//Invia all'MSP il freeaudio
module.exports.FreeAudio = function (msg) {
  sendMessage("34", false);
  console.log("Richiedo all'MSP di liberare l'audio");
}
