/*
 *
 */

var board;
var type;
var versionFirmware;
var versionConfiguration;

module.exports.parseInitARM = function (message) {
    type = message.getTEFType();
    board = message.getBoard();
    versionFirmware = message.getVersionFirmware();
    versionConfiguration = message.getVersionConfiguration();
};

module.exports.getBoard = function () {
    return board;
};

module.exports.getType = function () {
    return type;
};

module.exports.getVersionFirmware = function () {
    return versionFirmware;
};

module.exports.getVersionConfiguration = function () {
    return versionConfiguration;
};

module.exports.getModelName = function () {
    var modelName = "";
    switch (board) {
        case 1:
            modelName = "BI.BC No Firmware";
            break;
        case 2:
            modelName = "BI.BL No Firmware";
            break;
        case 5:
            switch (type) {
                case 1:
                    modelName = "BI.BC.PRO1";
                    break;
                case 2:
                    modelName = "BI.BC.PRO2";
                    break;
                case 3:
                    modelName = "BI.BC.PRO3";
                    break;
                case 4:
                    modelName = "BI.BC.CLA";
                    break;
                case 5:
                    modelName = "BI.BC.M";
                    break;
                default:
                     modelName = "BI.BC No Config";
                break;
            }
            break;
        case 6:
        switch (type) {
                case 6:
                    modelName = "BI.BL";
                    break;
                case 7:
                    modelName = "HI";
                    break;
                case 8:
                    modelName = "HI2";
                    break;
                case 9:
                    modelName = "BI.RADIO";
                    break;
                default:
                     modelName = "BI.BL No Config";
                break;
            }
            break;
    }
    console.log("Scheda rilevata: " + board + " tipo: " + type + " Esito: " + modelName);
    return modelName;

};
