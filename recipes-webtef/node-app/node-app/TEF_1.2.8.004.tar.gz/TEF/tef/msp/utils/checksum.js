
module.exports.calc = function (message) {
    var buf = Buffer.from(message, 'hex');
    var sum = 0;
    for (var i = 0; i < buf.length; i++) {
        sum = sum + buf[i];
    }
    sum = sum.toString(16);
    var checksum;
    if (sum.length === 1) {
        checksum = `0${sum}`;
    } else {
        checksum = sum.substring(sum.length - 2);
    }
    return checksum;
};
