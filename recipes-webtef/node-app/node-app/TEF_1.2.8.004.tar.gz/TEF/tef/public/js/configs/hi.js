
$(function () {



    /*
     * Type de Ligne L1
     */

    function changeTypeLigneL1() {
        if ($("input[name='Type_Ligne_L1']").prop('checked') === false) {
            $("input[name='Module_Interface_Aerienne_L1']").bootstrapToggle("enable");
        } else {
            $("input[name='Module_Interface_Aerienne_L1']").bootstrapToggle("disable");
        }
    }

    $("input[name='Type_Ligne_L1']").change(changeTypeLigneL1);

    changeTypeLigneL1();


    /*
     * Type de Ligne L2
     */

    // function changeTypeLigneL2() {
    //     if ($("input[name='Type_Ligne_L2']").prop('checked') === false) {
    //         $("input[name='Module_Interface_Aerienne_L2']").bootstrapToggle("enable");
    //     } else {
    //         $("input[name='Module_Interface_Aerienne_L2']").bootstrapToggle("disable");
    //     }
    // }
    //
    // $("input[name='Type_Ligne_L2']").change(changeTypeLigneL2);
    //
    // changeTypeLigneL2();


    /*
     * Temporisations
     */

    function changeTempsAntiBavardTAB() {
        if ($("input[name='Temps_Anti_Bavard_TAB']").prop('checked') === false) {
            sliderTempsAntiBavardTABSec.slider("disable");
        } else {
            sliderTempsAntiBavardTABSec.slider("enable");
        }
    }

    $("input[name='Temps_Anti_Bavard_TAB']").change(changeTempsAntiBavardTAB);

    var sliderTempsAntiBavardTABSec = $("input[name='Temps_Anti_Bavard_TAB_sec']").slider({
        value: tef.Temps_Anti_Bavard_TAB_sec,
        ticks: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max],
        ticks_labels: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max + 'sec'],
        step: tefDef.Temps_Anti_Bavard_TAB_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeTempsAntiBavardTAB();


    $("input[name='Temps_Mise_A_Repos_No_Rep_L1_sec']").slider({
        value: tef.Temps_Mise_A_Repos_No_Rep_L1_sec,
        ticks: [tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.max],
        ticks_labels: [tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_No_Rep_L1_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    // $("input[name='Temps_Mise_A_Repos_No_Rep_L2_sec']").slider({
    //     value: tef.Temps_Mise_A_Repos_No_Rep_L2_sec,
    //     ticks: [tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.max],
    //     ticks_labels: [tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.max + 'sec'],
    //     step: tefDef.Temps_Mise_A_Repos_No_Rep_L2_sec.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });



    /*
     * Typologie Signalisation L1
     */



    function changeDuree5Tons() {
        if ($("input[name='Typologie_Signalisation_L1']").prop('checked') === false) {
            sliderDuree_Signalisation_En_Sortie_L1_msec.slider("disable");
            sliderDuree_5Ton_L1.slider("enable");
            $("label[for='Code_Identifiant_L1']").removeClass("text-muted");
            $("input[name='Code_Identifiant_L1']").removeAttr("disabled");

            $('#changeSignalisation_Retour_Appel_L1_div').hide();
            $('#Mode_Attente_L1_div').show();
            $('#Nombre_L1').hide();

        } else {
            sliderDuree_5Ton_L1.slider("disable");
            sliderDuree_Signalisation_En_Sortie_L1_msec.slider("enable");
            $("label[for='Code_Identifiant_L1']").addClass("text-muted");
            $("input[name='Code_Identifiant_L1']").attr("disabled", "disabled");

            $('#changeSignalisation_Retour_Appel_L1_div').show();
            $('#Mode_Attente_L1_div').hide();
           $('#Nombre_L1').show();
        }
    }

    $("input[name='Typologie_Signalisation_L1']").change(changeDuree5Tons);

    var sliderDuree_5Ton_L1 = $("input[name='Duree_5Ton_L1']").slider({
        value: tef.Duree_5Ton_L1,
        ticks: [tefDef.Duree_5Ton_L1.min, (((Number(tefDef.Duree_5Ton_L1.min)) + (Number(tefDef.Duree_5Ton_L1.max))) / 2), tefDef.Duree_5Ton_L1.max],
        ticks_labels: [tefDef.Duree_5Ton_L1.min, (((Number(tefDef.Duree_5Ton_L1.min)) + (Number(tefDef.Duree_5Ton_L1.max))) / 2), tefDef.Duree_5Ton_L1.max + 'sec'],
        step: tefDef.Duree_5Ton_L1.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });
    var sliderDuree_Signalisation_En_Sortie_L1_msec = $("input[name='Duree_Signalisation_En_Sortie_L1_msec']").slider({
        value: tef.Duree_Signalisation_En_Sortie_L1_msec,
        ticks: [tefDef.Duree_Signalisation_En_Sortie_L1_msec.min, (((Number(tefDef.Duree_Signalisation_En_Sortie_L1_msec.min)) + (Number(tefDef.Duree_Signalisation_En_Sortie_L1_msec.max))) / 2), tefDef.Duree_Signalisation_En_Sortie_L1_msec.max],
        ticks_labels: [tefDef.Duree_Signalisation_En_Sortie_L1_msec.min / 1000, (((Number(tefDef.Duree_Signalisation_En_Sortie_L1_msec.min)) + (Number(tefDef.Duree_Signalisation_En_Sortie_L1_msec.max))) / 2000), tefDef.Duree_Signalisation_En_Sortie_L1_msec.max / 1000 + 'sec'],
        step: tefDef.Duree_Signalisation_En_Sortie_L1_msec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v} sec`;
        }
    });

    changeDuree5Tons();


    /*
     * Typologie Signalisation L2
     */


    // $("input[name='Typologie_Signalisation_L2']").change(changeDuree5Tons_L2);
    //
    // var sliderDuree_5Ton_L2 = $("input[name='Duree_5Ton_L2']").slider({
    //     value: tef.Duree_5Ton_L2,
    //     ticks: [tefDef.Duree_5Ton_L2.min, (((Number(tefDef.Duree_5Ton_L2.min)) + (Number(tefDef.Duree_5Ton_L2.max))) / 2), tefDef.Duree_5Ton_L2.max],
    //     ticks_labels: [tefDef.Duree_5Ton_L2.min, (((Number(tefDef.Duree_5Ton_L2.min)) + (Number(tefDef.Duree_5Ton_L2.max))) / 2), tefDef.Duree_5Ton_L2.max + 'sec'],
    //     step: tefDef.Duree_5Ton_L2.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    //
    // var sliderDuree_Signalisation_En_Sortie_L2_msec = $("input[name='Duree_Signalisation_En_Sortie_L2_msec']").slider({
    //     value: tef.Duree_Signalisation_En_Sortie_L2_msec,
    //     ticks: [tefDef.Duree_Signalisation_En_Sortie_L2_msec.min, (((Number(tefDef.Duree_Signalisation_En_Sortie_L2_msec.min)) + (Number(tefDef.Duree_Signalisation_En_Sortie_L2_msec.max))) / 2), tefDef.Duree_Signalisation_En_Sortie_L2_msec.max],
    //     ticks_labels: [tefDef.Duree_Signalisation_En_Sortie_L2_msec.min, (((Number(tefDef.Duree_Signalisation_En_Sortie_L2_msec.min)) + (Number(tefDef.Duree_Signalisation_En_Sortie_L2_msec.max))) / 2), tefDef.Duree_Signalisation_En_Sortie_L2_msec.max + 'msec'],
    //     step: tefDef.Duree_Signalisation_En_Sortie_L2_msec.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    //
    // function changeDuree5Tons_L2() {
    //     if ($("input[name='Typologie_Signalisation_L2']").prop('checked') === false) {
    //         sliderDuree_Signalisation_En_Sortie_L2_msec.slider("disable");
    //         sliderDuree_5Ton_L2.slider("enable");
    //         $("label[for='Code_Identifiant_L2']").removeClass("text-muted");
    //         $("input[name='Code_Identifiant_L2']").removeAttr("disabled");
    //     } else {
    //         sliderDuree_5Ton_L2.slider("disable");
    //         sliderDuree_Signalisation_En_Sortie_L2_msec.slider("enable");
    //         $("label[for='Code_Identifiant_L2']").addClass("text-muted");
    //         $("input[name='Code_Identifiant_L2']").attr("disabled", "disabled");
    //     }
    // }
    // changeDuree5Tons_L2();


    /*
     * Mode d'attente L1
     */

    function changeModeAttenteL1() {
        if ($("input[name='Mode_Attente_L1']").prop('checked') === true) {
            sliderDureeAttenteAcquittementSecL1.slider("enable");
            $("label[for='Duree_Attente_Acquittement_L1_sec']").removeClass("text-muted");
            $("label[for='Emission_Message_Vocal_Mode_Attente_L1']").removeClass("text-muted");
            $("input[name='Emission_Message_Vocal_Mode_Attente_L1']").bootstrapToggle("enable");
            changeEmissionMessageVocalModeAttenteL1();
        } else {
            sliderDureeAttenteAcquittementSecL1.slider("disable");
            $("label[for='Duree_Attente_Acquittement_L1_sec']").addClass("text-muted");
            $("label[for='Emission_Message_Vocal_Mode_Attente_L1']").addClass("text-muted");
            $("input[name='Emission_Message_Vocal_Mode_Attente_L1']").bootstrapToggle("disable");
            $(".messageVocalModeAttenteL1").attr("disabled", "disabled");
        }
    }

    $("input[name='Mode_Attente_L1']").change(changeModeAttenteL1);

    var sliderDureeAttenteAcquittementSecL1 = $("input[name='Duree_Attente_Acquittement_L1_sec']").slider({
        value: tef.Duree_Attente_Acquittement_L1_sec,
        ticks: [tefDef.Duree_Attente_Acquittement_L1_sec.min,  Number(tefDef.Duree_Attente_Acquittement_L1_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L1_sec.pas)), Number(tefDef.Duree_Attente_Acquittement_L1_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L1_sec.pas) * 2), tefDef.Duree_Attente_Acquittement_L1_sec.max],
        ticks_labels: [tefDef.Duree_Attente_Acquittement_L1_sec.min,  Number(tefDef.Duree_Attente_Acquittement_L1_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L1_sec.pas)), Number(tefDef.Duree_Attente_Acquittement_L1_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L1_sec.pas) * 2), tefDef.Duree_Attente_Acquittement_L1_sec.max + 'sec'],
        step: tefDef.Duree_Attente_Acquittement_L1_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeModeAttenteL1();

    function changeEmissionMessageVocalModeAttenteL1() {
        if ($("input[name='Emission_Message_Vocal_Mode_Attente_L1']").prop('checked') === true) {
            $(".messageVocalModeAttenteL1").removeAttr("disabled");
        } else {
            $(".messageVocalModeAttenteL1").attr("disabled", "disabled");
        }
    }

    $("input[name='Emission_Message_Vocal_Mode_Attente_L1']").change(changeEmissionMessageVocalModeAttenteL1);

    changeEmissionMessageVocalModeAttenteL1();



    /*
     * Mode d'attente L2
     */

    // function changeModeAttenteL2() {
    //     if ($("input[name='Mode_Attente_L2']").prop('checked') === true) {
    //         sliderDureeAttenteAcquittementSecL2.slider("enable");
    //         $("label[for='Duree_Attente_Acquittement_L2_sec']").removeClass("text-muted");
    //         $("label[for='Emission_Message_Vocal_Mode_Attente_L2']").removeClass("text-muted");
    //         $("input[name='Emission_Message_Vocal_Mode_Attente_L2']").bootstrapToggle("enable");
    //         changeEmissionMessageVocalModeAttenteL2();
    //     } else {
    //         sliderDureeAttenteAcquittementSecL2.slider("disable");
    //         $("label[for='Duree_Attente_Acquittement_L2_sec']").addClass("text-muted");
    //         $("label[for='Emission_Message_Vocal_Mode_Attente_L2']").addClass("text-muted");
    //         $("input[name='Emission_Message_Vocal_Mode_Attente_L2']").bootstrapToggle("disable");
    //         $(".messageVocalModeAttenteL2").attr("disabled", "disabled");
    //     }
    // }
    //
    // $("input[name='Mode_Attente_L2']").change(changeModeAttenteL2);
    //
    // var sliderDureeAttenteAcquittementSecL2 = $("input[name='Duree_Attente_Acquittement_L2_sec']").slider({
    //     value: tef.Duree_Attente_Acquittement_L2_sec,
    //     ticks: [tefDef.Duree_Attente_Acquittement_L2_sec.min,  Number(tefDef.Duree_Attente_Acquittement_L2_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L2_sec.pas)), Number(tefDef.Duree_Attente_Acquittement_L2_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L2_sec.pas) * 2), tefDef.Duree_Attente_Acquittement_L2_sec.max],
    //     ticks_labels: [tefDef.Duree_Attente_Acquittement_L2_sec.min,  Number(tefDef.Duree_Attente_Acquittement_L2_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L2_sec.pas)), Number(tefDef.Duree_Attente_Acquittement_L2_sec.min) + (Number(tefDef.Duree_Attente_Acquittement_L2_sec.pas) * 2), tefDef.Duree_Attente_Acquittement_L2_sec.max + 'sec'],
    //     step: tefDef.Duree_Attente_Acquittement_L2_sec.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    //
    // changeModeAttenteL2();
    //
    // function changeEmissionMessageVocalModeAttenteL2() {
    //     if ($("input[name='Emission_Message_Vocal_Mode_Attente_L2']").prop('checked') === true) {
    //         $(".messageVocalModeAttenteL2").removeAttr("disabled");
    //     } else {
    //         $(".messageVocalModeAttenteL2").attr("disabled", "disabled");
    //     }
    // }
    //
    // $("input[name='Emission_Message_Vocal_Mode_Attente_L2']").change(changeEmissionMessageVocalModeAttenteL2);
    //
    // changeEmissionMessageVocalModeAttenteL2();




    /*
     * Détection de la signalisation d’occupation et de libération L1
     */

    function changeDetectionOccupationLiberationL1() {
        if ($("input[name='Detection_Occupation_Liberation_L1']").prop('checked') === true) {
            sliderDureeSignalisationDetecteeLibererCommunicationL1.slider("enable");
            $("label[for='Duree_Signalisation_Detectee_Liberer_Communication_L1_sec']").removeClass("text-muted");
            $("label[for='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").removeClass("text-muted");
            $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").bootstrapToggle("enable");
            changeEmissionMessageVocalDetectionOccupationLiberationL1();
        } else {
            sliderDureeSignalisationDetecteeLibererCommunicationL1.slider("disable");
            $("label[for='Duree_Signalisation_Detectee_Liberer_Communication_L1_sec']").addClass("text-muted");
            $("label[for='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").addClass("text-muted");
            $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").bootstrapToggle("disable");
            $(".messageVocalDetectionOccupationLiberationL1").attr("disabled", "disabled");
        }
    }

    $("input[name='Detection_Occupation_Liberation_L1']").change(changeDetectionOccupationLiberationL1);

    var sliderDureeSignalisationDetecteeLibererCommunicationL1 = $("input[name='Duree_Signalisation_Detectee_Liberer_Communication_L1_sec']").slider({
        value: tef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec,
        ticks: [tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min, Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas)), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 2),
          Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 3), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 4), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 5),
          Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 6), tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.max],

        ticks_labels: [tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min, Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas)), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 2),
          Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 3), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 4), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 5),
          Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas) * 6), tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.max + 'sec'],
        step: tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L1_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeDetectionOccupationLiberationL1();

    function changeEmissionMessageVocalDetectionOccupationLiberationL1() {
        if ($("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").prop('checked') === true) {
            $(".messageVocalDetectionOccupationLiberationL1").removeAttr("disabled");
        } else {
            $(".messageVocalDetectionOccupationLiberationL1").attr("disabled", "disabled");
        }
    }

    $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L1']").change(changeEmissionMessageVocalDetectionOccupationLiberationL1);

    changeEmissionMessageVocalDetectionOccupationLiberationL1();




    /*
     * Détection de la signalisation d’occupation et de libération L2
     */
    //
    // function changeDetectionOccupationLiberationL2() {
    //     if ($("input[name='Detection_Occupation_Liberation_L2']").prop('checked') === true) {
    //         sliderDureeSignalisationDetecteeLibererCommunicationL2.slider("enable");
    //         $("label[for='Duree_Signalisation_Detectee_Liberer_Communication_L2_sec']").removeClass("text-muted");
    //         $("label[for='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").removeClass("text-muted");
    //         $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").bootstrapToggle("enable");
    //         changeEmissionMessageVocalDetectionOccupationLiberationL2();
    //     } else {
    //         sliderDureeSignalisationDetecteeLibererCommunicationL2.slider("disable");
    //         $("label[for='Duree_Signalisation_Detectee_Liberer_Communication_L2_sec']").addClass("text-muted");
    //         $("label[for='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").addClass("text-muted");
    //         $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").bootstrapToggle("disable");
    //         $(".messageVocalDetectionOccupationLiberationL2").attr("disabled", "disabled");
    //     }
    // }
    //
    // $("input[name='Detection_Occupation_Liberation_L2']").change(changeDetectionOccupationLiberationL2);
    //
    // var sliderDureeSignalisationDetecteeLibererCommunicationL2 = $("input[name='Duree_Signalisation_Detectee_Liberer_Communication_L2_sec']").slider({
    //     value: tef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec,
    //     ticks: [tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min, Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas)), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 2),
    //       Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 3), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 4), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 5),
    //       Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 5), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 6), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 7), tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.max],
    //     ticks_labels: [tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min, Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas)), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 2),
    //       Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 3), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 4), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 5),
    //       Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 5), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 6), Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.min) + (Number(tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas) * 7), tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.max + 'sec'],
    //     step: tefDef.Duree_Signalisation_Detectee_Liberer_Communication_L2_sec.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    //
    // changeDetectionOccupationLiberationL2();
    //
    // function changeEmissionMessageVocalDetectionOccupationLiberationL2() {
    //     if ($("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").prop('checked') === true) {
    //         $(".messageVocalDetectionOccupationLiberationL2").removeAttr("disabled");
    //     } else {
    //         $(".messageVocalDetectionOccupationLiberationL2").attr("disabled", "disabled");
    //     }
    // }
    //
    // $("input[name='Emission_Message_Vocal_Detection_Occupation_Liberation_L2']").change(changeEmissionMessageVocalDetectionOccupationLiberationL2);
    //
    // changeEmissionMessageVocalDetectionOccupationLiberationL2();




    /*
     * Modalité de Réponse L1
     */

    function changeModaliteDeReponseL1() {
        switch ($("select[name='Modalite_Reponse_L1']").val()) {
            case 'decrochage_manuel':
                $("label[for='Nombre_Trains_Sonnerie_L1']").addClass("text-muted");
                sliderNombreTrainsSonnerieL1.slider("disable");
                break;
            case 'decrochage_automatique':
                $("label[for='Nombre_Trains_Sonnerie_L1']").removeClass("text-muted");
                sliderNombreTrainsSonnerieL1.slider("enable");
                break;
            case 'ecoute_discrete':
                $("label[for='Nombre_Trains_Sonnerie_L1']").addClass("text-muted");
                sliderNombreTrainsSonnerieL1.slider("disable");
                break;
        }
    }

    var sliderNombreTrainsSonnerieL1 = $("input[name='Nombre_Trains_Sonnerie_L1']").slider({
        value: tef.Nombre_Trains_Sonnerie_L1,
        ticks: [tefDef.Nombre_Trains_Sonnerie_L1.min,  Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas)), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 6), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 8), tefDef.Nombre_Trains_Sonnerie_L1.max],
        ticks_labels: [tefDef.Nombre_Trains_Sonnerie_L1.min,  Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas)), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 6), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie_L1.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L1.pas) * 8), tefDef.Nombre_Trains_Sonnerie_L1.max],
        step: tefDef.Nombre_Trains_Sonnerie_L1.pas,
        tooltip: 'always',
        tooltip_position: 'bottom'
    });

    $("select[name='Modalite_Reponse_L1']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Modalite_Reponse_L1']").change(changeModaliteDeReponseL1);

    changeModaliteDeReponseL1();





    /*
     * Modalité de Réponse L2
     */

    // function changeModaliteDeReponseL2() {
    //     switch ($("select[name='Modalite_Reponse_L2']").val()) {
    //         case 'decrochage_manuel':
    //             $("label[for='Nombre_Trains_Sonnerie_L2']").addClass("text-muted");
    //             sliderNombreTrainsSonnerieL2.slider("disable");
    //             break;
    //         case 'decrochage_automatique':
    //             $("label[for='Nombre_Trains_Sonnerie_L2']").removeClass("text-muted");
    //             sliderNombreTrainsSonnerieL2.slider("enable");
    //             break;
    //         case 'ecoute_discrete':
    //             $("label[for='Nombre_Trains_Sonnerie_L2']").addClass("text-muted");
    //             sliderNombreTrainsSonnerieL2.slider("disable");
    //             break;
    //     }
    // }
    //
    // var sliderNombreTrainsSonnerieL2 = $("input[name='Nombre_Trains_Sonnerie_L2']").slider({
    //     value: tef.Nombre_Trains_Sonnerie_L2,
    //     ticks: [tefDef.Nombre_Trains_Sonnerie_L2.min,  Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas)), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 3),
    //       Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 6), tefDef.Nombre_Trains_Sonnerie_L2.max],
    //
    //     ticks_labels: [tefDef.Nombre_Trains_Sonnerie_L2.min,  Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas)), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 3),
    //       Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie_L2.min) + (Number(tefDef.Nombre_Trains_Sonnerie_L2.pas) * 6), tefDef.Nombre_Trains_Sonnerie_L2.max],
    //     step: tefDef.Nombre_Trains_Sonnerie_L2.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom'
    // });
    //
    // $("select[name='Modalite_Reponse_L2']").select2({
    //     minimumResultsForSearch: Infinity
    // });
    //
    // $("select[name='Modalite_Reponse_L2']").change(changeModaliteDeReponseL2);
    //
    // changeModaliteDeReponseL2();



    /*
     * Paramètres pour les Sonneries
     */
    function changeSonnerie() {
        switch ($("select[name='Sonnerie']").val()) {
            case 'aucune_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").addClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("disable");
                $("label[for='Duree_Extention_Sonnerie_msec']").addClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("disable");
                break;
            case 'emission_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").removeClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("enable");
                $("label[for='Duree_Extention_Sonnerie_msec']").addClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("disable");
                break;
            case 'pilotage_extension_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").addClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("disable");
                $("label[for='Duree_Extention_Sonnerie_msec']").removeClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("enable");
                break;
            case 'emission_sonnerie_pilotage_extension_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").removeClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("enable");
                $("label[for='Duree_Extention_Sonnerie_msec']").removeClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("enable");
                break;
        }
    }

    var sliderDureeSonnerieInterieureMSec = $("input[name='Duree_Sonnerie_Interieure_msec']").slider({
        value: tef.Duree_Sonnerie_Interieure_msec,
        ticks: [tefDef.Duree_Sonnerie_Interieure_msec.min, (((Number(tefDef.Duree_Sonnerie_Interieure_msec.min)) + (Number(tefDef.Duree_Sonnerie_Interieure_msec.max))) / 2), tefDef.Duree_Sonnerie_Interieure_msec.max],
        ticks_labels: [tefDef.Duree_Sonnerie_Interieure_msec.min + 'sec', ((((Number(tefDef.Duree_Sonnerie_Interieure_msec.min)) + (Number(tefDef.Duree_Sonnerie_Interieure_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Sonnerie_Interieure_msec.max / 1000 + 'sec'],
        step: 200,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v.toFixed(1)} sec`;
        }
    });

    var sliderDureeExtentionSonnerieMSec = $("input[name='Duree_Extention_Sonnerie_msec']").slider({
        value: tef.Duree_Extention_Sonnerie_msec,
        ticks: [tefDef.Duree_Extention_Sonnerie_msec.min, (((Number(tefDef.Duree_Extention_Sonnerie_msec.min)) + (Number(tefDef.Duree_Extention_Sonnerie_msec.max))) / 2), tefDef.Duree_Extention_Sonnerie_msec.max],
        ticks_labels: [tefDef.Duree_Extention_Sonnerie_msec.min + 'sec', ((((Number(tefDef.Duree_Extention_Sonnerie_msec.min)) + (Number(tefDef.Duree_Extention_Sonnerie_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Extention_Sonnerie_msec.max / 1000 + 'sec'],
        step: 200,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v.toFixed(1)} sec`;
        }
    });


    $("select[name='Sonnerie']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Sonnerie']").change(changeSonnerie);

    changeSonnerie();




    /*
     * Signalisation de Retour d'Appel - L1
     */

     function changeSignalisation_Retour_Appel_L1() {

             if ($("input[name='Signalisation_Retour_Appel_L1']").prop('checked') === true) {
                 sliderDuree_Signalisation_Retour_Appel_L1_msec.slider("enable");
                 sliderNiveau_Signalisation_Retour_Appel_L1_dB.slider("enable");
                 $("label[for='Duree_Signalisation_Retour_Appel_L1_msec']").removeClass("text-muted");
                 $("label[for='Niveau_Signalisation_Retour_Appel_L1_dB']").removeClass("text-muted");
             } else {
                 sliderDuree_Signalisation_Retour_Appel_L1_msec.slider("disable");
                 sliderNiveau_Signalisation_Retour_Appel_L1_dB.slider("disable");
                 $("label[for='Duree_Signalisation_Retour_Appel_L1_msec']").addClass("text-muted");
                 $("label[for='Niveau_Signalisation_Retour_Appel_L1_dB']").addClass("text-muted");
             }
         }

     $("input[name='Signalisation_Retour_Appel_L1']").change(changeSignalisation_Retour_Appel_L1);

     var sliderDuree_Signalisation_Retour_Appel_L1_msec = $("input[name='Duree_Signalisation_Retour_Appel_L1_msec']").slider({
         value: tef.Duree_Signalisation_Retour_Appel_L1_msec,
         ticks: [tefDef.Duree_Signalisation_Retour_Appel_L1_msec.min, (((Number(tefDef.Duree_Signalisation_Retour_Appel_L1_msec.min)) + (Number(tefDef.Duree_Signalisation_Retour_Appel_L1_msec.max))) / 2), tefDef.Duree_Signalisation_Retour_Appel_L1_msec.max],
         ticks_labels: [tefDef.Duree_Signalisation_Retour_Appel_L1_msec.min / 1000 + 'sec', ((((Number(tefDef.Duree_Signalisation_Retour_Appel_L1_msec.min)) + (Number(tefDef.Duree_Signalisation_Retour_Appel_L1_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Signalisation_Retour_Appel_L1_msec.max / 1000 + 'sec'],
         step: 200,
         tooltip: 'always',
         tooltip_position: 'bottom',
         formatter: function (v) {
             v = v / 1000;
             return `${v.toFixed(1)} sec`;
         }
     });
    var sliderNiveau_Signalisation_Retour_Appel_L1_dB = $("input[name='Niveau_Signalisation_Retour_Appel_L1_dB']").slider({
             value: tef.Niveau_Signalisation_Retour_Appel_L1_dB,
             min: tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.min,
             max: tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.max,
             ticks: [tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.min, tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.max],
             ticks_labels: [tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.min + 'dB', tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.max + 'dB'],
             step: tefDef.Niveau_Signalisation_Retour_Appel_L1_dB.pas,
             tooltip: 'always',
             tooltip_position: 'bottom',
             formatter: function (v) {
                 return `${v} dB`;
             }
         });

changeSignalisation_Retour_Appel_L1();



/*
 * Signalisation de Retour d'Appel - L2
 */

//  function changeSignalisation_Retour_Appel_L2() {
//      if ($("input[name='Signalisation_Retour_Appel_L2']").prop('checked') === true) {
//          sliderDuree_Signalisation_Retour_Appel_L2_msec.slider("enable");
//          sliderNiveau_Signalisation_Retour_Appel_L2_dB.slider("enable");
//          $("label[for='Duree_Signalisation_Retour_Appel_L2_msec']").removeClass("text-muted");
//          $("label[for='Niveau_Signalisation_Retour_Appel_L2_dB']").removeClass("text-muted");
//      } else {
//          sliderDuree_Signalisation_Retour_Appel_L2_msec.slider("disable");
//          sliderNiveau_Signalisation_Retour_Appel_L2_dB.slider("disable");
//          $("label[for='Duree_Signalisation_Retour_Appel_L2_msec']").addClass("text-muted");
//          $("label[for='Niveau_Signalisation_Retour_Appel_L2_dB']").addClass("text-muted");
//      }
//  }
//
//  $("input[name='Signalisation_Retour_Appel_L2']").change(changeSignalisation_Retour_Appel_L2);
//
//  var sliderDuree_Signalisation_Retour_Appel_L2_msec = $("input[name='Duree_Signalisation_Retour_Appel_L2_msec']").slider({
//      value: tef.Duree_Signalisation_Retour_Appel_L2_msec,
//      ticks: [tefDef.Duree_Signalisation_Retour_Appel_L2_msec.min, (((Number(tefDef.Duree_Signalisation_Retour_Appel_L2_msec.min)) + (Number(tefDef.Duree_Signalisation_Retour_Appel_L2_msec.max))) / 2), tefDef.Duree_Signalisation_Retour_Appel_L2_msec.max],
//      ticks_labels: [tefDef.Duree_Signalisation_Retour_Appel_L2_msec.min / 1000 + 'sec', ((((Number(tefDef.Duree_Signalisation_Retour_Appel_L2_msec.min)) + (Number(tefDef.Duree_Signalisation_Retour_Appel_L2_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Signalisation_Retour_Appel_L2_msec.max / 1000 + 'sec'],
//      step: 200,
//      tooltip: 'always',
//      tooltip_position: 'bottom',
//      formatter: function (v) {
//          v = v / 1000;
//          return `${v.toFixed(1)} sec`;
//      }
//  });
// var sliderNiveau_Signalisation_Retour_Appel_L2_dB = $("input[name='Niveau_Signalisation_Retour_Appel_L2_dB']").slider({
//          value: tef.Niveau_Signalisation_Retour_Appel_L2_dB,
//          min: tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.min,
//          max: tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.max,
//          ticks: [tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.min, tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.max],
//          ticks_labels: [tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.min + 'dB', tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.max + 'dB'],
//          step: tefDef.Niveau_Signalisation_Retour_Appel_L2_dB.pas,
//          tooltip: 'always',
//          tooltip_position: 'bottom',
//          formatter: function (v) {
//              return `${v} dB`;
//          }
//      });
//
// changeSignalisation_Retour_Appel_L2();



    /*
     * Niveau d'Emission de la Phonie ver la Ligne Analogique L1
     */

    $("input[name='Niveau_Emission_Ligne_Analogique_L1_dB']").slider({
        value: tef.Niveau_Emission_Ligne_Analogique_L1_dB,
        min: tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.min,
        max: tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.max,
        ticks: [tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.min, tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.max],
        ticks_labels: [tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.min + 'dB', tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.max + 'dB'],
        step: tefDef.Niveau_Emission_Ligne_Analogique_L1_dB.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} dB`;
        }
    });



    /*
     * Niveau d'Emission de la Phonie ver la Ligne Analogique L2
     */

    // $("input[name='Niveau_Emission_Ligne_Analogique_L2_dB']").slider({
    //     value: tef.Niveau_Emission_Ligne_Analogique_L2_dB,
    //     min: tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.min,
    //     max: tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.max,
    //     ticks: [tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.min, tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.max],
    //     ticks_labels: [tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.min + 'dB', tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.max + 'dB'],
    //     step: tefDef.Niveau_Emission_Ligne_Analogique_L2_dB.pas,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} dB`;
    //     }
    // });




    /*
     * Extintion Automatique de la Connexion Wi-Fi
     */
    function changeExtintionAutomatiqueWiFi() {
        if ($("input[name='Extintion_Automatique_WiFi']").prop('checked') === true) {
            sliderExtintionAutomatiqueWiFiMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueWiFiMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueWiFiMin = $("input[name='Extintion_Automatique_WiFi_min']").slider({
        value: tef.Extintion_Automatique_WiFi_min,
        ticks: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max + "min"],
        step: tefDef.Extintion_Automatique_WiFi_min.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_WiFi']").change(changeExtintionAutomatiqueWiFi);

    changeExtintionAutomatiqueWiFi();



    /*
     * Extintion Automatique de la Connexion Ethernet
     */
    function changeExtintionAutomatiqueEth() {
        if ($("input[name='Extintion_Automatique_Eth']").prop('checked') === true) {
            sliderExtintionAutomatiqueEthMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueEthMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueEthMin = $("input[name='Extintion_Automatique_Eth_min']").slider({
        value: tef.Extintion_Automatique_Eth_min,
        ticks: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max + "min"],
        step: tefDef.Extintion_Automatique_Eth_min.step,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_Eth']").change(changeExtintionAutomatiqueEth);

    changeExtintionAutomatiqueEth();




    //Su registrazione disabilito tutto il resto per 10 secondi - AUDIO 01
        $("#btnRec").on('click',function(){
          $("#btnPlay").prop('disabled', true);
          $("#btnSave").prop('disabled', true);
          $("#btnDownload").prop('disabled', true);
          $("#btnRec").prop('disabled', true);
          $("#pickfiles").prop('disabled', true);
          $("#btnPlaytmp").prop('disabled', true);

          var timeleft = 10;
          var downloadTimer = setInterval(function(){
          timeleft--;
          document.getElementById("countdowntimer").textContent = "Enregistrement en cours.  Rester " + timeleft + " sec.";
          if(timeleft <= 0){
              $("#btnPlay").prop('disabled', false);
              $("#btnSave").prop('disabled', false);
              $("#btnDownload").prop('disabled', false);
              $("#btnRec").prop('disabled', false);
              $("#pickfiles").prop('disabled', false);
              $("#btnPlaytmp").prop('disabled', false);
              document.getElementById("btnPlayTag").textContent = "Lire l'audio juste enregistré";
              document.getElementById("countdowntimer").textContent = "Enregistrement à partir du microphone ";
              clearInterval(downloadTimer);
            }
          },1000);
        });


    //Su play audio definitivo disabilito tutto il resto per 10 secondi
    $("#btnPlay").on('click',function(){
      $("#btnPlay").prop('disabled', true);
      $("#btnSave").prop('disabled', true);
      $("#btnDownload").prop('disabled', true);
      $("#btnRec").prop('disabled', true);
      $("#pickfiles").prop('disabled', true);
      $("#btnPlaytmp").prop('disabled', true);


      var timeleft = 10;
      var downloadTimer = setInterval(function(){
      timeleft--;
      document.getElementById("btnPlayTag").textContent = "Lecture audio en cours.  Rester " + timeleft + " sec.";
      if(timeleft <= 0){
          $("#btnPlay").prop('disabled', false);
          $("#btnSave").prop('disabled', false);
          $("#btnDownload").prop('disabled', false);
          $("#btnRec").prop('disabled', false);
          $("#pickfiles").prop('disabled', false);
          $("#btnPlaytmp").prop('disabled', false);
          document.getElementById("btnPlayTag").textContent = "Lire l'audio actuellement utilisé";
          clearInterval(downloadTimer);
        }
      },1000);
    });

    //Su play audio temp disabilito tutto il resto per 10 secondi
    $("#btnPlaytmp").on('click',function(){
      $("#btnPlay").prop('disabled', true);
      $("#btnSave").prop('disabled', true);
      $("#btnDownload").prop('disabled', true);
      $("#btnRec").prop('disabled', true);
      $("#pickfiles").prop('disabled', true);
      $("#btnPlaytmp").prop('disabled', true);


      var timeleft = 10;
      var downloadTimer = setInterval(function(){
      timeleft--;
      document.getElementById("btnPlaytmpTag").textContent = "Lecture audio en cours.  Rester " + timeleft + " sec.";
      if(timeleft <= 0){
          $("#btnPlay").prop('disabled', false);
          $("#btnSave").prop('disabled', false);
          $("#btnDownload").prop('disabled', false);
          $("#btnRec").prop('disabled', false);
          $("#pickfiles").prop('disabled', false);
          $("#btnPlaytmp").prop('disabled', false);
          document.getElementById("btnPlaytmpTag").textContent = "Lire l'audio juste enregistré";
          clearInterval(downloadTimer);
        }
      },1000);
    });

    if(document.getElementById("btnPlaytmpTag").textContent == "Lire l'audio juste enregistré"){
      $("#btnSave").prop('disabled', false);
    } else {
      $("#btnSave").prop('disabled', true);
    }





    // //Su registrazione disabilito tutto il resto per 10 secondi - Audio 02
    //     $("#btnRec2").on('click',function(){
    //       $("#btnPlay2").prop('disabled', true);
    //       $("#btnSave2").prop('disabled', true);
    //       $("#btnDownload2").prop('disabled', true);
    //       $("#btnRec2").prop('disabled', true);
    //       $("#pickfiles2").prop('disabled', true);
    //       $("#btnPlaytmp2").prop('disabled', true);
    //
    //       var timeleft2 = 10;
    //       var downloadTimer2 = setInterval(function(){
    //       timeleft2--;
    //       document.getElementById("countdowntimer2").textContent = "Enregistrement en cours.  Rester " + timeleft2 + " sec.";
    //       if(timeleft2 <= 0){
    //           $("#btnPlay2").prop('disabled', false);
    //           $("#btnSave2").prop('disabled', false);
    //           $("#btnDownload2").prop('disabled', false);
    //           $("#btnRec2").prop('disabled', false);
    //           $("#pickfiles2").prop('disabled', false);
    //           $("#btnPlaytmp2").prop('disabled', false);
    //           document.getElementById("btnPlayTag2").textContent = "Lire l'audio juste enregistré";
    //           document.getElementById("countdowntimer2").textContent = "Enregistrement à partir du microphone ";
    //           clearInterval(downloadTimer2);
    //         }
    //       },1000);
    //     });
    //
    //
    // //Su play audio definitivo disabilito tutto il resto per 10 secondi
    // $("#btnPlay2").on('click',function(){
    //   $("#btnPlay2").prop('disabled', true);
    //   $("#btnSave2").prop('disabled', true);
    //   $("#btnDownload2").prop('disabled', true);
    //   $("#btnRec2").prop('disabled', true);
    //   $("#pickfiles2").prop('disabled', true);
    //   $("#btnPlaytmp2").prop('disabled', true);
    //
    //
    //   var timeleft2 = 10;
    //   var downloadTimer2 = setInterval(function(){
    //   timeleft2--;
    //   document.getElementById("btnPlayTag2").textContent = "Lecture audio en cours.  Rester " + timeleft2 + " sec.";
    //   if(timeleft2 <= 0){
    //       $("#btnPlay2").prop('disabled', false);
    //       $("#btnSave2").prop('disabled', false);
    //       $("#btnDownload2").prop('disabled', false);
    //       $("#btnRec2").prop('disabled', false);
    //       $("#pickfiles2").prop('disabled', false);
    //       $("#btnPlaytmp2").prop('disabled', false);
    //       document.getElementById("btnPlayTag2").textContent = "Lire l'audio actuellement utilisé";
    //       clearInterval(downloadTimer2);
    //     }
    //   },1000);
    // });
    //
    // //Su play audio temp disabilito tutto il resto per 10 secondi
    // $("#btnPlaytmp2").on('click',function(){
    //   $("#btnPlay2").prop('disabled', true);
    //   $("#btnSave2").prop('disabled', true);
    //   $("#btnDownload2").prop('disabled', true);
    //   $("#btnRec2").prop('disabled', true);
    //   $("#pickfiles2").prop('disabled', true);
    //   $("#btnPlaytmp2").prop('disabled', true);
    //
    //
    //   var timeleft2 = 10;
    //   var downloadTimer2 = setInterval(function(){
    //   timeleft2--;
    //   document.getElementById("btnPlaytmpTag2").textContent = "Lecture audio en cours.  Rester " + timeleft2 + " sec.";
    //   if(timeleft2 <= 0){
    //       $("#btnPlay2").prop('disabled', false);
    //       $("#btnSave2").prop('disabled', false);
    //       $("#btnDownload2").prop('disabled', false);
    //       $("#btnRec2").prop('disabled', false);
    //       $("#pickfiles2").prop('disabled', false);
    //       $("#btnPlaytmp2").prop('disabled', false);
    //       document.getElementById("btnPlaytmpTag2").textContent = "Lire l'audio juste enregistré";
    //       clearInterval(downloadTimer2);
    //     }
    //   },1000);
    // });
    //
    // if(document.getElementById("btnPlaytmpTag2").textContent == "Lire l'audio juste enregistré"){
    //   $("#btnSave2").prop('disabled', false);
    // } else {
    //   $("#btnSave2").prop('disabled', true);
    // }






    //Su registrazione disabilito tutto il resto per 10 secondi - Audio 3
        $("#btnRec3").on('click',function(){
          $("#btnPlay3").prop('disabled', true);
          $("#btnSave3").prop('disabled', true);
          $("#btnDownload3").prop('disabled', true);
          $("#btnRec3").prop('disabled', true);
          $("#pickfiles3").prop('disabled', true);
          $("#btnPlaytmp3").prop('disabled', true);

          var timeleft3 = 10;
          var downloadTimer3 = setInterval(function(){
          timeleft3--;
          document.getElementById("countdowntimer3").textContent = "Enregistrement en cours.  Rester " + timeleft3 + " sec.";
          if(timeleft3 <= 0){
              $("#btnPlay3").prop('disabled', false);
              $("#btnSave3").prop('disabled', false);
              $("#btnDownload3").prop('disabled', false);
              $("#btnRec3").prop('disabled', false);
              $("#pickfiles3").prop('disabled', false);
              $("#btnPlaytmp3").prop('disabled', false);
              document.getElementById("btnPlayTag3").textContent = "Lire l'audio juste enregistré";
              document.getElementById("countdowntimer3").textContent = "Enregistrement à partir du microphone ";
              clearInterval(downloadTimer3);
            }
          },1000);
        });


    //Su play audio definitivo disabilito tutto il resto per 10 secondi
    $("#btnPlay3").on('click',function(){
      $("#btnPlay3").prop('disabled', true);
      $("#btnSave3").prop('disabled', true);
      $("#btnDownload3").prop('disabled', true);
      $("#btnRec3").prop('disabled', true);
      $("#pickfiles3").prop('disabled', true);
      $("#btnPlaytmp3").prop('disabled', true);


      var timeleft3 = 10;
      var downloadTimer3 = setInterval(function(){
      timeleft3--;
      document.getElementById("btnPlayTag3").textContent = "Lecture audio en cours.  Rester " + timeleft3 + " sec.";
      if(timeleft3 <= 0){
          $("#btnPlay3").prop('disabled', false);
          $("#btnSave3").prop('disabled', false);
          $("#btnDownload3").prop('disabled', false);
          $("#btnRec3").prop('disabled', false);
          $("#pickfiles3").prop('disabled', false);
          $("#btnPlaytmp3").prop('disabled', false);
          document.getElementById("btnPlayTag3").textContent = "Lire l'audio actuellement utilisé";
          clearInterval(downloadTimer3);
        }
      },1000);
    });

    //Su play audio temp disabilito tutto il resto per 10 secondi
    $("#btnPlaytmp3").on('click',function(){
      $("#btnPlay3").prop('disabled', true);
      $("#btnSave3").prop('disabled', true);
      $("#btnDownload3").prop('disabled', true);
      $("#btnRec3").prop('disabled', true);
      $("#pickfiles3").prop('disabled', true);
      $("#btnPlaytmp3").prop('disabled', true);


      var timeleft3 = 10;
      var downloadTimer3 = setInterval(function(){
      timeleft3--;
      document.getElementById("btnPlaytmpTag3").textContent = "Lecture audio en cours.  Rester " + timeleft3 + " sec.";
      if(timeleft3 <= 0){
          $("#btnPlay3").prop('disabled', false);
          $("#btnSave3").prop('disabled', false);
          $("#btnDownload3").prop('disabled', false);
          $("#btnRec3").prop('disabled', false);
          $("#pickfiles3").prop('disabled', false);
          $("#btnPlaytmp3").prop('disabled', false);
          document.getElementById("btnPlaytmpTag3").textContent = "Lire l'audio juste enregistré";
          clearInterval(downloadTimer3);
        }
      },1000);
    });

    if(document.getElementById("btnPlaytmpTag3").textContent == "Lire l'audio juste enregistré"){
      $("#btnSave3").prop('disabled', false);
    } else {
      $("#btnSave3").prop('disabled', true);
    }




    //Su registrazione disabilito tutto il resto per 10 secondi - Audio 4
    //     $("#btnRec4").on('click',function(){
    //       $("#btnPlay4").prop('disabled', true);
    //       $("#btnSave4").prop('disabled', true);
    //       $("#btnDownload4").prop('disabled', true);
    //       $("#btnRec4").prop('disabled', true);
    //       $("#pickfiles4").prop('disabled', true);
    //       $("#btnPlaytmp4").prop('disabled', true);
    //
    //       var timeleft4 = 10;
    //       var downloadTimer4 = setInterval(function(){
    //       timeleft4--;
    //       document.getElementById("countdowntimer4").textContent = "Enregistrement en cours.  Rester " + timeleft4 + " sec.";
    //       if(timeleft4 <= 0){
    //           $("#btnPlay4").prop('disabled', false);
    //           $("#btnSave4").prop('disabled', false);
    //           $("#btnDownload4").prop('disabled', false);
    //           $("#btnRec4").prop('disabled', false);
    //           $("#pickfiles4").prop('disabled', false);
    //           $("#btnPlaytmp4").prop('disabled', false);
    //           document.getElementById("btnPlayTag4").textContent = "Lire l'audio juste enregistré";
    //           document.getElementById("countdowntimer4").textContent = "Enregistrement à partir du microphone ";
    //           clearInterval(downloadTimer4);
    //         }
    //       },1000);
    //     });
    //
    //
    // //Su play audio definitivo disabilito tutto il resto per 10 secondi
    // $("#btnPlay4").on('click',function(){
    //   $("#btnPlay4").prop('disabled', true);
    //   $("#btnSave4").prop('disabled', true);
    //   $("#btnDownload4").prop('disabled', true);
    //   $("#btnRec4").prop('disabled', true);
    //   $("#pickfiles4").prop('disabled', true);
    //   $("#btnPlaytmp4").prop('disabled', true);
    //
    //
    //   var timeleft4 = 10;
    //   var downloadTimer4 = setInterval(function(){
    //   timeleft4--;
    //   document.getElementById("btnPlayTag4").textContent = "Lecture audio en cours.  Rester " + timeleft4 + " sec.";
    //   if(timeleft4 <= 0){
    //       $("#btnPlay4").prop('disabled', false);
    //       $("#btnSave4").prop('disabled', false);
    //       $("#btnDownload4").prop('disabled', false);
    //       $("#btnRec4").prop('disabled', false);
    //       $("#pickfiles4").prop('disabled', false);
    //       $("#btnPlaytmp4").prop('disabled', false);
    //       document.getElementById("btnPlayTag4").textContent = "Lire l'audio actuellement utilisé";
    //       clearInterval(downloadTimer4);
    //     }
    //   },1000);
    // });
    //
    // //Su play audio temp disabilito tutto il resto per 10 secondi
    // $("#btnPlaytmp4").on('click',function(){
    //   $("#btnPlay4").prop('disabled', true);
    //   $("#btnSave4").prop('disabled', true);
    //   $("#btnDownload4").prop('disabled', true);
    //   $("#btnRec4").prop('disabled', true);
    //   $("#pickfiles4").prop('disabled', true);
    //   $("#btnPlaytmp4").prop('disabled', true);
    //
    //
    //   var timeleft4 = 10;
    //   var downloadTimer4 = setInterval(function(){
    //   timeleft4--;
    //   document.getElementById("btnPlaytmpTag4").textContent = "Lecture audio en cours.  Rester " + timeleft4 + " sec.";
    //   if(timeleft4 <= 0){
    //       $("#btnPlay4").prop('disabled', false);
    //       $("#btnSave4").prop('disabled', false);
    //       $("#btnDownload4").prop('disabled', false);
    //       $("#btnRec4").prop('disabled', false);
    //       $("#pickfiles4").prop('disabled', false);
    //       $("#btnPlaytmp4").prop('disabled', false);
    //       document.getElementById("btnPlaytmpTag4").textContent = "Lire l'audio juste enregistré";
    //       clearInterval(downloadTimer4);
    //     }
    //   },1000);
    // });
    //
    // if(document.getElementById("btnPlaytmpTag4").textContent == "Lire l'audio juste enregistré"){
    //   $("#btnSave4").prop('disabled', false);
    // } else {
    //   $("#btnSave4").prop('disabled', true);
    // }



});
