
$(function () {

    /*
     * Temporisations
     */

    function changeTempsAntiBavardTAB() {
        if ($("input[name='Temps_Anti_Bavard_TAB']").prop('checked') === false) {
            sliderTempsAntiBavardTABSec.slider("disable");
        } else {
            sliderTempsAntiBavardTABSec.slider("enable");
        }
    }

    $("input[name='Temps_Anti_Bavard_TAB']").change(changeTempsAntiBavardTAB);

    var sliderTempsAntiBavardTABSec = $("input[name='Temps_Anti_Bavard_TAB_sec']").slider({
        value: tef.Temps_Anti_Bavard_TAB_sec,
        ticks: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max],
        ticks_labels: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max + 'sec'],
        step: tefDef.Temps_Anti_Bavard_TAB_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeTempsAntiBavardTAB();


    $("input[name='Temps_Mise_A_Repos_No_Rep_sec']").slider({
        value: tef.Temps_Mise_A_Repos_No_Rep_sec,
        ticks: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max],
        ticks_labels: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_No_Rep_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });


    /*
     * Activation Tonalité Invitation à Transmettre
     */

    function changeActivationTonaliteInvitationTransmettre() {
        if ($("input[name='Activation_Tonalite_Invitation_Transmettre']").prop('checked') === false) {
            sliderTemporisationAttenteTonaliteInvitationTransmettreMsec.slider("disable");
            $("label[for='Temporisation_Attente_Tonalite_Invitation_Transmettre_msec']").addClass("text-muted");
        } else {
            sliderTemporisationAttenteTonaliteInvitationTransmettreMsec.slider("enable");
            $("label[for='Temporisation_Attente_Tonalite_Invitation_Transmettre_msec']").removeClass("text-muted");
        }
    }

    $("input[name='Activation_Tonalite_Invitation_Transmettre']").change(changeActivationTonaliteInvitationTransmettre);

    var sliderTemporisationAttenteTonaliteInvitationTransmettreMsec = $("input[name='Temporisation_Attente_Tonalite_Invitation_Transmettre_msec']").slider({
        value: tef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec,
        ticks: [tefDef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.min, 2000, tefDef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.max],
        ticks_labels: [(tefDef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.min / 1000), 2, (tefDef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.max / 1000) + 'sec'],

        step: tefDef.Temporisation_Attente_Tonalite_Invitation_Transmettre_msec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v.toFixed(1)} sec`;
        }
    });

    changeActivationTonaliteInvitationTransmettre();

    /*
     * Typologie de BI.BC.PRO
     */

    $("select[name='Typologie_BIBCPRO']").select2({
        minimumResultsForSearch: Infinity
    });

    /*
     * Numerotation
     */


    /*
     * Modalité de communication
     */
     /*
      * Typologie de BI.BC.PRO
      */
     function changeTypologieBIBCPRO() {
         switch ($("select[name='Typologie_BIBCPRO']").val()) {
             case 'BI.BC.PRO1':
                 $("label[for='Numerotation_1_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_1_Num_1']").removeAttr("disabled");
                 $("label[for='Numerotation_2_Num_1']").addClass("text-muted");
                 $("input[name='Numerotation_2_Num_1']").attr("disabled", "disabled");
                 $("label[for='Numerotation_3_Num_1']").addClass("text-muted");
                 $("input[name='Numerotation_3_Num_1']").attr("disabled", "disabled");
                 break;
             case 'BI.BC.PRO2':
                 $("label[for='Numerotation_1_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_1_Num_1']").removeAttr("disabled");
                 $("label[for='Numerotation_2_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_2_Num_1']").removeAttr("disabled");
                 $("label[for='Numerotation_3_Num_1']").addClass("text-muted");
                 $("input[name='Numerotation_3_Num_1']").attr("disabled", "disabled");
             break;
             case 'BI.BC.PRO3':
                 $("label[for='Numerotation_1_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_1_Num_1']").removeAttr("disabled");
                 $("label[for='Numerotation_2_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_2_Num_1']").removeAttr("disabled");
                 $("label[for='Numerotation_3_Num_1']").removeClass("text-muted");
                 $("input[name='Numerotation_3_Num_1']").removeAttr("disabled");
             break;
         }
     }

     $("select[name='Typologie_BIBCPRO']").change(changeTypologieBIBCPRO);

     changeTypologieBIBCPRO();

    // var sliderNumerotation1Num1TempsAttente = $("input[name='Numerotation_1_Num_1_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_1_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num2TempsAttente = $("input[name='Numerotation_1_Num_2_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_2_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num3TempsAttente = $("input[name='Numerotation_1_Num_3_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_3_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num4TempsAttente = $("input[name='Numerotation_1_Num_4_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_4_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num5TempsAttente = $("input[name='Numerotation_1_Num_5_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_5_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num6TempsAttente = $("input[name='Numerotation_1_Num_6_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_6_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num7TempsAttente = $("input[name='Numerotation_1_Num_7_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_7_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation1Num8TempsAttente = $("input[name='Numerotation_1_Num_8_Temps_Attente']").slider({
    //     value: tef.Numerotation_1_Num_8_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num1TempsAttente = $("input[name='Numerotation_2_Num_1_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_1_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num2TempsAttente = $("input[name='Numerotation_2_Num_2_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_2_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num3TempsAttente = $("input[name='Numerotation_2_Num_3_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_3_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num4TempsAttente = $("input[name='Numerotation_2_Num_4_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_4_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num5TempsAttente = $("input[name='Numerotation_2_Num_5_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_5_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num6TempsAttente = $("input[name='Numerotation_2_Num_6_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_6_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num7TempsAttente = $("input[name='Numerotation_2_Num_7_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_7_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation2Num8TempsAttente = $("input[name='Numerotation_2_Num_8_Temps_Attente']").slider({
    //     value: tef.Numerotation_2_Num_8_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num1TempsAttente = $("input[name='Numerotation_3_Num_1_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_1_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num2TempsAttente = $("input[name='Numerotation_3_Num_2_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_2_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num3TempsAttente = $("input[name='Numerotation_3_Num_3_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_3_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num4TempsAttente = $("input[name='Numerotation_3_Num_4_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_4_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num5TempsAttente = $("input[name='Numerotation_3_Num_5_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_5_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num6TempsAttente = $("input[name='Numerotation_3_Num_6_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_6_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num7TempsAttente = $("input[name='Numerotation_3_Num_7_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_7_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });
    // var sliderNumerotation3Num8TempsAttente = $("input[name='Numerotation_3_Num_8_Temps_Attente']").slider({
    //     value: tef.Numerotation_3_Num_8_Temps_Attente,
    //     ticks: [10, 40, 70, 100, 120],
    //     ticks_labels: [10, 40, 70, 100, '120sec'],
    //     step: 1,
    //     tooltip: 'always',
    //     tooltip_position: 'bottom',
    //     formatter: function (v) {
    //         return `${v} sec`;
    //     }
    // });

    /*
     * Détection de la signalisation d’occupation et de libération
     */

    function changeDetectionOccupationLiberation() {
        if ($("input[name='Detection_Occupation_Liberation']").prop('checked') === true) {
            sliderTempsMiseAReposSec.slider("enable");
            $("label[for='Temps_Mise_A_Repos_sec']").removeClass("text-muted");
        } else {
            sliderTempsMiseAReposSec.slider("disable");
            $("label[for='Temps_Mise_A_Repos_sec']").addClass("text-muted");
        }
    }

    $("input[name='Detection_Occupation_Liberation']").change(changeDetectionOccupationLiberation);

    var sliderTempsMiseAReposSec = $("input[name='Temps_Mise_A_Repos_sec']").slider({
        value: tef.Temps_Mise_A_Repos_sec,
        // ticks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        // ticks_labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, '10sec'],
        ticks: [tefDef.Temps_Mise_A_Repos_sec.min, Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas)),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 2),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 3),
           Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 4),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 5),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 6), tefDef.Temps_Mise_A_Repos_sec.max],

        ticks_labels: [tefDef.Temps_Mise_A_Repos_sec.min, Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas)),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 2),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 3),
           Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 4),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 5),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 6), tefDef.Temps_Mise_A_Repos_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeDetectionOccupationLiberation();




    /*
     * Modalité de Réponse
     */

    function changeModaliteDeReponse() {
        switch ($("select[name='Modalite_Reponse']").val()) {
            case 'decrochage_manuel':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
            case 'decrochage_automatique':
                $("label[for='Nombre_Trains_Sonnerie']").removeClass("text-muted");
                sliderNombreTrainsSonnerie.slider("enable");
                break;
            case 'ecoute_discrete':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
        }
    }

    var sliderNombreTrainsSonnerie = $("input[name='Nombre_Trains_Sonnerie']").slider({
        value: tef.Nombre_Trains_Sonnerie,
        ticks: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],

        ticks_labels: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],
        step: tefDef.Nombre_Trains_Sonnerie.pas,
        tooltip: 'always',
        tooltip_position: 'bottom'
    });

    $("select[name='Modalite_Reponse']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Modalite_Reponse']").change(changeModaliteDeReponse);

    changeModaliteDeReponse();





    /*
     * Module d'Interface Aérienne
     */




    /*
     * Niveau d'Emission de la Phonie ver la Ligne Analogique


    $("input[name='Niveau_Emission_Ligne_Analogique_dB']").slider({
        value: tef.Niveau_Emission_Ligne_Analogique_dB,
        min: tefDef.Niveau_Emission_Ligne_Analogique_dB.min,
        max: tefDef.Niveau_Emission_Ligne_Analogique_dB.max,
        ticks: [tefDef.Niveau_Emission_Ligne_Analogique_dB.min, tefDef.Niveau_Emission_Ligne_Analogique_dB.max],
        ticks_labels: [tefDef.Niveau_Emission_Ligne_Analogique_dB.min + 'dB', tefDef.Niveau_Emission_Ligne_Analogique_dB.max + 'dB'],
        step: tefDef.Niveau_Emission_Ligne_Analogique_dB.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} dB`;
        }
    });
 */



    /*
     * Durée de la Signalisation Associée au Bouton R
     */

    $("input[name='Duree_Signalisation_Associee_Bouton_R_msec']").slider({
        value: tef.Duree_Signalisation_Associee_Bouton_R_msec,
        min: tefDef.Duree_Signalisation_Associee_Bouton_R_msec.min,
        max: tefDef.Duree_Signalisation_Associee_Bouton_R_msec.max,
        ticks: [tefDef.Duree_Signalisation_Associee_Bouton_R_msec.min, (((Number(tefDef.Duree_Signalisation_Associee_Bouton_R_msec.min)) + (Number(tefDef.Duree_Signalisation_Associee_Bouton_R_msec.max))) / 2), tefDef.Duree_Signalisation_Associee_Bouton_R_msec.max],
        ticks_labels: [tefDef.Duree_Signalisation_Associee_Bouton_R_msec.min, (((Number(tefDef.Duree_Signalisation_Associee_Bouton_R_msec.min)) + (Number(tefDef.Duree_Signalisation_Associee_Bouton_R_msec.max))) / 2), tefDef.Duree_Signalisation_Associee_Bouton_R_msec.max + 'msec'],
        step: tefDef.Duree_Signalisation_Associee_Bouton_R_msec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} msec`;
        }
    });




    /*
     * DTMF
     */

    $("input[name='Duree_Mark_msec']").slider({
        value: tef.Duree_Mark_msec,
        min: tefDef.Duree_Mark_msec.min,
        max: tefDef.Duree_Mark_msec.max,
        ticks: [tefDef.Duree_Mark_msec.min, (((Number(tefDef.Duree_Mark_msec.min)) + (Number(tefDef.Duree_Mark_msec.max))) / 2), tefDef.Duree_Mark_msec.max],
        ticks_labels: [tefDef.Duree_Mark_msec.min, (((Number(tefDef.Duree_Mark_msec.min)) + (Number(tefDef.Duree_Mark_msec.max))) / 2), tefDef.Duree_Mark_msec.max + 'msec'],
        step: tefDef.Duree_Mark_msec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} msec`;
        }
    });

    $("input[name='Duree_Space_msec']").slider({
        value: tef.Duree_Space_msec,
        min: tefDef.Duree_Space_msec.min,
        max: tefDef.Duree_Space_msec.max,
        ticks: [tefDef.Duree_Space_msec.min, (((Number(tefDef.Duree_Space_msec.min)) + (Number(tefDef.Duree_Space_msec.max))) / 2), tefDef.Duree_Space_msec.max],
        ticks_labels: [tefDef.Duree_Space_msec.min, (((Number(tefDef.Duree_Space_msec.min)) + (Number(tefDef.Duree_Space_msec.max))) / 2), tefDef.Duree_Space_msec.max + 'msec'],
        step: tefDef.Duree_Space_msec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} msec`;
        }
    });

    $("input[name='Echelle']").slider({
        value: tef.Echelle,
        min: tefDef.Echelle.min,
        max: tefDef.Echelle.max,
        ticks: [tefDef.Echelle.min, tefDef.Echelle.max],
        ticks_labels: ['2.2', '3.2db'],
        step: tefDef.Echelle.pas,
    });

    $("input[name='Niveau_Emission_DTMF_dB']").slider({
        value: tef.Niveau_Emission_DTMF_dB,
        min: tefDef.Niveau_Emission_DTMF_dB.min,
        max: tefDef.Niveau_Emission_DTMF_dB.max,
        ticks: [tefDef.Niveau_Emission_DTMF_dB.min,-14,-12,-10,-8,-6,tefDef.Niveau_Emission_DTMF_dB.max],
        ticks_labels: [tefDef.Niveau_Emission_DTMF_dB.min, '-14', '-12', '-10','-8','-6', tefDef.Niveau_Emission_DTMF_dB.max],
        step: tefDef.Niveau_Emission_DTMF_dB.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} dB`;
        }
    });




    /*
     * Extintion Automatique de la Connexion Wi-Fi
     */
    function changeExtintionAutomatiqueWiFi() {
        if ($("input[name='Extintion_Automatique_WiFi']").prop('checked') === true) {
            sliderExtintionAutomatiqueWiFiMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueWiFiMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueWiFiMin = $("input[name='Extintion_Automatique_WiFi_min']").slider({
        value: tef.Extintion_Automatique_WiFi_min,
        ticks: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max + "min"],
        step: tefDef.Extintion_Automatique_WiFi_min.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_WiFi']").change(changeExtintionAutomatiqueWiFi);

    changeExtintionAutomatiqueWiFi();



    /*
     * Extintion Automatique de la Connexion Ethernet
     */
    function changeExtintionAutomatiqueEth() {
        if ($("input[name='Extintion_Automatique_Eth']").prop('checked') === true) {
            sliderExtintionAutomatiqueEthMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueEthMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueEthMin = $("input[name='Extintion_Automatique_Eth_min']").slider({
        value: tef.Extintion_Automatique_Eth_min,
        ticks: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max + "min"],
        step: tefDef.Extintion_Automatique_Eth_min.step,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_Eth']").change(changeExtintionAutomatiqueEth);

    changeExtintionAutomatiqueEth();



});
