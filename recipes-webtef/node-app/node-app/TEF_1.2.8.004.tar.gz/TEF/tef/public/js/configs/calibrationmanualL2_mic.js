
$(function () {

/*
     * Niveau de sortie  tef.Niveau_de_sortie
*/


    $("input[name='Niveau_de_sortie']").slider({
        value: tef.Niveau_de_sortie,
        min: -33,
        max: -7,
        ticks: [-33, -7],
        ticks_labels: ['-33dB', '-7dB'],
        step: 1,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} dB`;
        }
    });

    var originalValSortie;

    $("input[name='Niveau_de_sortie']").slider().on('slideStart', function(ev){
        originalValSortie = $("input[name='Niveau_de_sortie']").data('slider').getValue();
    });

    $("input[name='Niveau_de_sortie']").slider().on('slideStop', function(ev){
          var newVal = $("input[name='Niveau_de_sortie']").data('slider').getValue();
          if(originalValSortie != null && originalValSortie != newVal) {
            window.location.href = "/aggiornamicrofonoL2?value="+newVal+"#transmission";
          }
    });







    //  $("input[name='Niveau_entrant']").slider({
    //      value: tef.Niveau_entrant,
    //      min: -20,
    //      max: -10,
    //      ticks: [-20, -10],
    //      ticks_labels: ['-20dB', '-10dB'],
    //      step: 1,
    //      tooltip: 'always',
    //      tooltip_position: 'bottom',
    //      formatter: function (v2) {
    //          return `${v2} dB`;
    //      }
    //  });
    //
    // var originalValEntrant;
    //
    // $("input[name='Niveau_entrant']").slider().on('slideStart', function(ev){
    //     originalValEntrant = $("input[name='Niveau_entrant']").data('slider').getValue();
    // });
    //
    // $("input[name='Niveau_entrant']").slider().on('slideStop', function(ev){
    //       var newVal2 = $("input[name='Niveau_entrant']").data('slider').getValue();
    //       if(originalValEntrant != null && originalValEntrant != newVal2) {
    //         window.location.href = "/aggiornaaudio?value="+newVal2;
    //       }
    // });



  $("#button_transmission").on('click',function(){
    $("#button_reception").addClass("disabled");
    $("#btn1_reception").addClass("disabled");
    $("#btn2_reception").addClass("disabled");
    $("#button_transmission").removeClass("disabled");
    $("#btn1_transmission").removeClass("disabled");
    $("#btn2_transmission").removeClass("disabled");
  });

  $("#button_reception").on('click',function(){
    $("#button_transmission").addClass("disabled");
    $("#btn1_transmission").addClass("disabled");
    $("#btn2_transmission").addClass("disabled");
    $("#button_reception").removeClass("disabled");
    $("#btn1_reception").removeClass("disabled");
    $("#btn2_reception").removeClass("disabled");
  });

});
