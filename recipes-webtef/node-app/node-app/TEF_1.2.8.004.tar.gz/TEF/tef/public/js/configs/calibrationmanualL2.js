
$(function () {


  //   /*
  //    * Niveau de sortie  tef.Niveau_de_sortie
  //    */
  //    $("input[name='Niveau_entrant']").slider({
  //        value: tef.Niveau_entrant,
  //        min: -20,
  //        max: -10,
  //        ticks: [-20, -10],
  //        ticks_labels: ['-20dB', '-10dB'],
  //        step: 1,
  //        tooltip: 'always',
  //        tooltip_position: 'bottom',
  //        formatter: function (v) {
  //            return `${v} dB`;
  //        }
  //    });
  //
  //
  //   $("input[name='Niveau_de_sortie']").slider({
  //     //  value: tef.Niveau_de_sortie,
  //       value: -12,
  //       min: -23,
  //       max: -8,
  //       ticks: [-23, -8],
  //       ticks_labels: ['-23dB', '-8dB'],
  //       step: 1,
  //       tooltip: 'always',
  //       tooltip_position: 'bottom',
  //       formatter: function (v) {
  //           return `${v} dB`;
  //       }
  //   });
  //
  //   var originalVal;
  //
  //   $("input[name='Niveau_de_sortie']").slider().on('slideStart', function(ev){
  //       originalVal = $("input[name='Niveau_de_sortie']").data('slider').getValue();
  //   });
  //   $("input[name='Niveau_de_sortie']").slider().on('slideStop', function(ev){
  //         var newVal = $("input[name='Niveau_de_sortie']").data('slider').getValue();
  //         if(originalVal != null && originalVal != newVal) {
  //           //alert('Value Changed! oldvalue ' + originalVal + " new value " + newVal );
  //           var tosent= "/aggiornamicrofono?value="+newVal;
  //           console.log("to Sent " + tosent );
  //           window.location.href = "/aggiornamicrofono?value="+newVal;
  //           console.log("to Sent afther ??");
  //           // alert('Value Changed! oldvalue ' + originalVal + " new value " + newVal );
  //         }
  //   });
  //
  //
  //
  //
  //   $("input[name='Niveau_entrant']").slider().on('slideStart', function(ev){
  //       originalVal = $("input[name='Niveau_entrant']").data('slider').getValue();
  //   });
  //   $("input[name='Niveau_entrant']").slider().on('slideStop', function(ev){
  //         var newVal = $("input[name='Niveau_entrant']").data('slider').getValue();
  //         if(originalVal != null && originalVal != newVal) {
  //           //alert('Value Changed! oldvalue ' + originalVal + " new value " + newVal );
  //           var tosent= "/aggiornaaltoparlante?value="+newVal;
  //           console.log("to Sent " + tosent );
  //           window.location.href = "/aggiornaaltoparlante?value="+newVal;
  //           console.log("to Sent afther ??");
  //           // alert('Value Changed! oldvalue ' + originalVal + " new value " + newVal );
  //         }
  //   });
  //
  //
  // $("#button_transmission").on('click',function(){
  //   $("#button_reception").addClass("disabled");
  //   $("#btn1_reception").addClass("disabled");
  //   $("#btn2_reception").addClass("disabled");
  //   $("#button_transmission").removeClass("disabled");
  //   $("#btn1_transmission").removeClass("disabled");
  //   $("#btn2_transmission").removeClass("disabled");
  // });
  //
  // $("#button_reception").on('click',function(){
  //   $("#button_transmission").addClass("disabled");
  //   $("#btn1_transmission").addClass("disabled");
  //   $("#btn2_transmission").addClass("disabled");
  //   $("#button_reception").removeClass("disabled");
  //   $("#btn1_reception").removeClass("disabled");
  //   $("#btn2_reception").removeClass("disabled");
  // });

});
