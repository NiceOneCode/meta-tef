
$(function () {

    /*
     * Temporisations
     */

    function changeTempsAntiBavardTAB() {
        if ($("input[name='Temps_Anti_Bavard_TAB']").prop('checked') === false) {
            sliderTempsAntiBavardTABSec.slider("disable");
        } else {
            sliderTempsAntiBavardTABSec.slider("enable");
        }
    }

    $("input[name='Temps_Anti_Bavard_TAB']").change(changeTempsAntiBavardTAB);

    var sliderTempsAntiBavardTABSec = $("input[name='Temps_Anti_Bavard_TAB_sec']").slider({
        value: tef.Temps_Anti_Bavard_TAB_sec,
        ticks: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max],
        ticks_labels: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max + 'sec'],
        step: tefDef.Temps_Anti_Bavard_TAB_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeTempsAntiBavardTAB();


    $("input[name='Temps_Mise_A_Repos_No_Rep_sec']").slider({
        value: tef.Temps_Mise_A_Repos_No_Rep_sec,
        ticks: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max],
        ticks_labels: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_No_Rep_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });



    /*
     * Modalité de communication
     */



    /*
     * Détection de la signalisation d’occupation et de libération
     */

    function changeDetectionOccupationLiberation() {
        if ($("input[name='Detection_Occupation_Liberation']").prop('checked') === true) {
            sliderTempsMiseAReposSec.slider("enable");
            $("label[for='Temps_Mise_A_Repos_sec']").removeClass("text-muted");
        } else {
            sliderTempsMiseAReposSec.slider("disable");
            $("label[for='Temps_Mise_A_Repos_sec']").addClass("text-muted");
        }
    }

    $("input[name='Detection_Occupation_Liberation']").change(changeDetectionOccupationLiberation);

    var sliderTempsMiseAReposSec = $("input[name='Temps_Mise_A_Repos_sec']").slider({
        value: tef.Temps_Mise_A_Repos_sec,
        // ticks: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        // ticks_labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, '10sec'],
        ticks: [tefDef.Temps_Mise_A_Repos_sec.min, Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas)),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 2),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 3),
           Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 4),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 5),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 6), tefDef.Temps_Mise_A_Repos_sec.max],

        ticks_labels: [tefDef.Temps_Mise_A_Repos_sec.min, Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas)),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 2),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 3),
           Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 4),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 5),  Number(tefDef.Temps_Mise_A_Repos_sec.min) + (Number(tefDef.Temps_Mise_A_Repos_sec.pas) * 6), tefDef.Temps_Mise_A_Repos_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeDetectionOccupationLiberation();




    /*
     * Modalité de Réponse
     */

    function changeModaliteDeReponse() {
        switch ($("select[name='Modalite_Reponse']").val()) {
            case 'decrochage_manuel':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
            case 'decrochage_automatique':
                $("label[for='Nombre_Trains_Sonnerie']").removeClass("text-muted");
                sliderNombreTrainsSonnerie.slider("enable");
                break;
            case 'ecoute_discrete':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
        }
    }

    var sliderNombreTrainsSonnerie = $("input[name='Nombre_Trains_Sonnerie']").slider({
        value: tef.Nombre_Trains_Sonnerie,
        ticks: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],

        ticks_labels: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],
        step: tefDef.Nombre_Trains_Sonnerie.pas,
        tooltip: 'always',
        tooltip_position: 'bottom'
    });

    $("select[name='Modalite_Reponse']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Modalite_Reponse']").change(changeModaliteDeReponse);

    changeModaliteDeReponse();




    /*
     * Niveau d'Emission de la Phonie ver la Ligne Analogique


    $("input[name='Niveau_Emission_Ligne_Analogique_dB']").slider({
        value: tef.Niveau_Emission_Ligne_Analogique_dB,
        min: tefDef.Niveau_Emission_Ligne_Analogique_dB.min,
        max: tefDef.Niveau_Emission_Ligne_Analogique_dB.max,
        ticks: [tefDef.Niveau_Emission_Ligne_Analogique_dB.min, tefDef.Niveau_Emission_Ligne_Analogique_dB.max],
        ticks_labels: [tefDef.Niveau_Emission_Ligne_Analogique_dB.min + 'dB', tefDef.Niveau_Emission_Ligne_Analogique_dB.max + 'dB'],
        step: tefDef.Niveau_Emission_Ligne_Analogique_dB.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} dB`;
        }
    });

 */


    /*
     * Extintion Automatique de la Connexion Wi-Fi
     */
    function changeExtintionAutomatiqueWiFi() {
        if ($("input[name='Extintion_Automatique_WiFi']").prop('checked') === true) {
            sliderExtintionAutomatiqueWiFiMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueWiFiMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueWiFiMin = $("input[name='Extintion_Automatique_WiFi_min']").slider({
        value: tef.Extintion_Automatique_WiFi_min,
        ticks: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max + "min"],
        step: tefDef.Extintion_Automatique_WiFi_min.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_WiFi']").change(changeExtintionAutomatiqueWiFi);

    changeExtintionAutomatiqueWiFi();



    /*
     * Extintion Automatique de la Connexion Ethernet
     */
    function changeExtintionAutomatiqueEth() {
        if ($("input[name='Extintion_Automatique_Eth']").prop('checked') === true) {
            sliderExtintionAutomatiqueEthMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueEthMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueEthMin = $("input[name='Extintion_Automatique_Eth_min']").slider({
        value: tef.Extintion_Automatique_Eth_min,
        ticks: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max + "min"],
        step: tefDef.Extintion_Automatique_Eth_min.step,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_Eth']").change(changeExtintionAutomatiqueEth);

    changeExtintionAutomatiqueEth();



});
