
$(function () {

    /*
     * Temporisations
     */

    function changeTempsAntiBavardTAB() {
        if ($("input[name='Temps_Anti_Bavard_TAB']").prop('checked') === false) {
            sliderTempsAntiBavardTABSec.slider("disable");
        } else {
            sliderTempsAntiBavardTABSec.slider("enable");
        }
    }

    $("input[name='Temps_Anti_Bavard_TAB']").change(changeTempsAntiBavardTAB);

    var sliderTempsAntiBavardTABSec = $("input[name='Temps_Anti_Bavard_TAB_sec']").slider({
        value: tef.Temps_Anti_Bavard_TAB_sec,
        ticks: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max],
        ticks_labels: [tefDef.Temps_Anti_Bavard_TAB_sec.min, (((Number(tefDef.Temps_Anti_Bavard_TAB_sec.min)) + (Number(tefDef.Temps_Anti_Bavard_TAB_sec.max))) / 2), tefDef.Temps_Anti_Bavard_TAB_sec.max + 'sec'],
        step: tefDef.Temps_Anti_Bavard_TAB_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });

    changeTempsAntiBavardTAB();


    $("input[name='Temps_Attente_Message_Connection_sec']").slider({
        value: tef.Temps_Attente_Message_Connection_sec,
        ticks: [tefDef.Temps_Attente_Message_Connection_sec.min, (((Number(tefDef.Temps_Attente_Message_Connection_sec.min)) + (Number(tefDef.Temps_Attente_Message_Connection_sec.max))) / 2), tefDef.Temps_Attente_Message_Connection_sec.max],
        ticks_labels: [tefDef.Temps_Attente_Message_Connection_sec.min, (((Number(tefDef.Temps_Attente_Message_Connection_sec.min)) + (Number(tefDef.Temps_Attente_Message_Connection_sec.max))) / 2), tefDef.Temps_Attente_Message_Connection_sec.max + 'sec'],
        step: tefDef.Temps_Attente_Message_Connection_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });


    $("input[name='Temps_Mise_A_Repos_No_Rep_sec']").slider({
        value: tef.Temps_Mise_A_Repos_No_Rep_sec,
        ticks: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max],
        ticks_labels: [tefDef.Temps_Mise_A_Repos_No_Rep_sec.min, (((Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.min)) + (Number(tefDef.Temps_Mise_A_Repos_No_Rep_sec.max))) / 2), tefDef.Temps_Mise_A_Repos_No_Rep_sec.max + 'sec'],
        step: tefDef.Temps_Mise_A_Repos_No_Rep_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });



    /*
     * Modalité de communication
     */



    /*
     * Nombre et Type des Cartes SIM
     */

    function changeNombreTypeCartesSIM() {
        switch ($("select[name='Nombre_Type_Cartes_SIM']").val()) {
            case '1_SIM_GSM-R':
                $("label[for='Reseau_Principal']").addClass("text-muted");
                $("input[name='Reseau_Principal']").attr("disabled", "disabled");
                $("label[for='Reseau_Secours']").addClass("text-muted");
                $("input[name='Reseau_Secours']").attr("disabled", "disabled");
                break;
            case 'DUAL-SIM':
                $("label[for='Reseau_Principal']").removeClass("text-muted");
                $("input[name='Reseau_Principal']").removeAttr("disabled");
                $("label[for='Reseau_Secours']").removeClass("text-muted");
                $("input[name='Reseau_Secours']").removeAttr("disabled");
                break;
        }
    }

    $("select[name='Nombre_Type_Cartes_SIM']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Nombre_Type_Cartes_SIM']").change(changeNombreTypeCartesSIM);

    changeNombreTypeCartesSIM();


    /*
     * Cascade d'Appels
     */
    var sliderTempsAttente = $("input[name='Temps_Attente_sec']").slider({
        value: tef.Temps_Attente_sec,
        ticks: [tefDef.Temps_Attente_sec.min, 40, 70, 100, tefDef.Temps_Attente_sec.max],
        ticks_labels: [tefDef.Temps_Attente_sec.min, '40', '70', '100', tefDef.Temps_Attente_sec.max + 'sec'],
        step: tefDef.Temps_Attente_sec.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} sec`;
        }
    });


    /*
     * Temps de Commutation dans la Sélection du Réseau Radio
     */
    var sliderTempsCommutationRadio = $("input[name='Temps_Commutation_Radio_min']").slider({
        value: tef.Temps_Commutation_Radio_min,
        ticks: [tefDef.Temps_Commutation_Radio_min.min, (((Number(tefDef.Temps_Commutation_Radio_min.min)) + (Number(tefDef.Temps_Commutation_Radio_min.max))) / 2), tefDef.Temps_Commutation_Radio_min.max],
        ticks_labels: [tefDef.Temps_Commutation_Radio_min.min, (((Number(tefDef.Temps_Commutation_Radio_min.min)) + (Number(tefDef.Temps_Commutation_Radio_min.max))) / 2), tefDef.Temps_Commutation_Radio_min.max + 'min'],
        step: tefDef.Temps_Commutation_Radio_min.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });



    function changeAttenteConnexion() {
        if ($("input[name='Attente_de_Connexion']").prop('checked') === true) {
            $(".messageAttenteConnexion").removeAttr("disabled");
        } else {
            $(".messageAttenteConnexion").attr("disabled", "disabled");
        }
    }

    $("input[name='Attente_de_Connexion']").change(changeAttenteConnexion);

    changeAttenteConnexion();



    function changePasConfirmeConnexion() {
        if ($("input[name='Pas_Confirme_de_Connexion']").prop('checked') === true) {
            $(".messagePasConfirmeConnexion").removeAttr("disabled");
        } else {
            $(".messagePasConfirmeConnexion").attr("disabled", "disabled");
        }
    }

    $("input[name='Pas_Confirme_de_Connexion']").change(changePasConfirmeConnexion);

    changePasConfirmeConnexion();



    function changeRaccroche() {
        if ($("input[name='Raccroche']").prop('checked') === true) {
            $(".messageRaccroche").removeAttr("disabled");
        } else {
            $(".messageRaccroche").attr("disabled", "disabled");
        }
    }

    $("input[name='Raccroche']").change(changeRaccroche);

    changeRaccroche();



    $("select[name='Contact_Sortie_1_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactSortie1() {
        if ($("input[name='Contact_Sortie_1']").prop('checked') === true) {
            $("input[name='Contact_Sortie_1_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Sortie_1_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Sortie_1_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Sortie_1_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Sortie_1_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Sortie_1_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Sortie_1']").change(changeContactSortie1);

    changeContactSortie1();



    $("select[name='Contact_Sortie_2_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactSortie2() {
        if ($("input[name='Contact_Sortie_2']").prop('checked') === true) {
            $("input[name='Contact_Sortie_2_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Sortie_2_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Sortie_2_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Sortie_2_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Sortie_2_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Sortie_2_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Sortie_2']").change(changeContactSortie2);

    changeContactSortie2();



    $("select[name='Contact_Sortie_3_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactSortie3() {
        if ($("input[name='Contact_Sortie_3']").prop('checked') === true) {
            $("input[name='Contact_Sortie_3_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Sortie_3_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Sortie_3_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Sortie_3_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Sortie_3_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Sortie_3_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Sortie_3']").change(changeContactSortie3);

    changeContactSortie3();



    $("select[name='Contact_Sortie_4_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactSortie4() {
        if ($("input[name='Contact_Sortie_4']").prop('checked') === true) {
            $("input[name='Contact_Sortie_4_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Sortie_4_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Sortie_4_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Sortie_4_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Sortie_4_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Sortie_4_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Sortie_4']").change(changeContactSortie4);

    changeContactSortie4();



    $("select[name='Contact_Entree_1_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactEntree1() {
        if ($("input[name='Contact_Entree_1']").prop('checked') === true) {
            $("input[name='Contact_Entree_1_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Entree_1_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Entree_1_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Entree_1_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Entree_1_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Entree_1_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Entree_1']").change(changeContactEntree1);

    changeContactEntree1();



    $("select[name='Contact_Entree_2_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactEntree2() {
        if ($("input[name='Contact_Entree_2']").prop('checked') === true) {
            $("input[name='Contact_Entree_2_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Entree_2_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Entree_2_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Entree_2_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Entree_2_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Entree_2_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Entree_2']").change(changeContactEntree2);

    changeContactEntree2();



    $("select[name='Contact_Entree_3_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactEntree3() {
        if ($("input[name='Contact_Entree_3']").prop('checked') === true) {
            $("input[name='Contact_Entree_3_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Entree_3_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Entree_3_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Entree_3_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Entree_3_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Entree_3_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Entree_3']").change(changeContactEntree3);

    changeContactEntree3();



    $("select[name='Contact_Entree_4_Etat']").select2({
        minimumResultsForSearch: Infinity
    });

    function changeContactEntree4() {
        if ($("input[name='Contact_Entree_4']").prop('checked') === true) {
            $("input[name='Contact_Entree_4_Denomination']").removeAttr("disabled");
            $("input[name='Contact_Entree_4_Numero_SMS']").removeAttr("disabled");
            $("select[name='Contact_Entree_4_Etat']").removeAttr("disabled");
        } else {
            $("input[name='Contact_Entree_4_Denomination']").attr("disabled", "disabled");
            $("input[name='Contact_Entree_4_Numero_SMS']").attr("disabled", "disabled");
            $("select[name='Contact_Entree_4_Etat']").attr("disabled", "disabled");
        }
    }

    $("input[name='Contact_Entree_4']").change(changeContactEntree4);

    changeContactEntree4();




    /*
     * Modalité de Réponse
     */

    function changeModaliteDeReponse() {
        switch ($("select[name='Modalite_Reponse']").val()) {
            case 'decrochage_manuel':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
            case 'decrochage_automatique':
                $("label[for='Nombre_Trains_Sonnerie']").removeClass("text-muted");
                sliderNombreTrainsSonnerie.slider("enable");
                break;
            case 'ecoute_discrete':
                $("label[for='Nombre_Trains_Sonnerie']").addClass("text-muted");
                sliderNombreTrainsSonnerie.slider("disable");
                break;
        }
    }

    var sliderNombreTrainsSonnerie = $("input[name='Nombre_Trains_Sonnerie']").slider({
        value: tef.Nombre_Trains_Sonnerie,
        ticks: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],

        ticks_labels: [tefDef.Nombre_Trains_Sonnerie.min,  Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas)), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 2), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 3),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 4), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 5), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 6),
          Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 7), Number(tefDef.Nombre_Trains_Sonnerie.min) + (Number(tefDef.Nombre_Trains_Sonnerie.pas) * 8), tefDef.Nombre_Trains_Sonnerie.max],
        step: tefDef.Nombre_Trains_Sonnerie.pas,
        tooltip: 'always',
        tooltip_position: 'bottom'
    });

    $("select[name='Modalite_Reponse']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Modalite_Reponse']").change(changeModaliteDeReponse);

    changeModaliteDeReponse();




    /*
     * Paramètres pour les Sonneries
     */
    function changeSonnerie() {
        switch ($("select[name='Sonnerie']").val()) {
            case 'aucune_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").addClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("disable");
                $("label[for='Duree_Extention_Sonnerie_msec']").addClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("disable");
                break;
            case 'emission_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").removeClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("enable");
                $("label[for='Duree_Extention_Sonnerie_msec']").addClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("disable");
                break;
            case 'pilotage_extension_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").addClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("disable");
                $("label[for='Duree_Extention_Sonnerie_msec']").removeClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("enable");
                break;
            case 'emission_sonnerie_pilotage_extension_sonnerie':
                $("label[for='Duree_Sonnerie_Interieure_msec']").removeClass("text-muted");
                sliderDureeSonnerieInterieureMSec.slider("enable");
                $("label[for='Duree_Extention_Sonnerie_msec']").removeClass("text-muted");
                sliderDureeExtentionSonnerieMSec.slider("enable");
                break;
        }
    }

    var sliderDureeSonnerieInterieureMSec = $("input[name='Duree_Sonnerie_Interieure_msec']").slider({
        value: tef.Duree_Sonnerie_Interieure_msec,
        ticks: [tefDef.Duree_Sonnerie_Interieure_msec.min, (((Number(tefDef.Duree_Sonnerie_Interieure_msec.min)) + (Number(tefDef.Duree_Sonnerie_Interieure_msec.max))) / 2), tefDef.Duree_Sonnerie_Interieure_msec.max],
        ticks_labels: [tefDef.Duree_Sonnerie_Interieure_msec.min + 'sec', ((((Number(tefDef.Duree_Sonnerie_Interieure_msec.min)) + (Number(tefDef.Duree_Sonnerie_Interieure_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Sonnerie_Interieure_msec.max + 'sec'],
        step: 200,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v.toFixed(1)} sec`;
        }
    });
    var sliderDureeExtentionSonnerieMSec = $("input[name='Duree_Extention_Sonnerie_msec']").slider({
        value: tef.Duree_Extention_Sonnerie_msec,
        ticks: [tefDef.Duree_Extention_Sonnerie_msec.min, (((Number(tefDef.Duree_Extention_Sonnerie_msec.min)) + (Number(tefDef.Duree_Extention_Sonnerie_msec.max))) / 2), tefDef.Duree_Extention_Sonnerie_msec.max],
        ticks_labels: [tefDef.Duree_Extention_Sonnerie_msec.min + 'sec',  ((((Number(tefDef.Duree_Extention_Sonnerie_msec.min)) + (Number(tefDef.Duree_Extention_Sonnerie_msec.max))) / 2) / 1000) + 'sec', tefDef.Duree_Extention_Sonnerie_msec.max + 'sec'],
        step: 200,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            v = v / 1000;
            return `${v.toFixed(1)} sec`;
        }
    });

    $("select[name='Sonnerie']").select2({
        minimumResultsForSearch: Infinity
    });

    $("select[name='Sonnerie']").change(changeSonnerie);

    changeSonnerie();



    /*
     * Extintion Automatique de la Connexion Wi-Fi
     */
    function changeExtintionAutomatiqueWiFi() {
        if ($("input[name='Extintion_Automatique_WiFi']").prop('checked') === true) {
            sliderExtintionAutomatiqueWiFiMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueWiFiMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueWiFiMin = $("input[name='Extintion_Automatique_WiFi_min']").slider({
        value: tef.Extintion_Automatique_WiFi_min,
        ticks: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_WiFi_min.min, Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas)), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 2), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 4), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 5), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 7), Number(tefDef.Extintion_Automatique_WiFi_min.min) + (Number(tefDef.Extintion_Automatique_WiFi_min.pas) * 8), tefDef.Extintion_Automatique_WiFi_min.max + "min"],
        step: tefDef.Extintion_Automatique_WiFi_min.pas,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_WiFi']").change(changeExtintionAutomatiqueWiFi);

    changeExtintionAutomatiqueWiFi();



    /*
     * Extintion Automatique de la Connexion Ethernet
     */
    function changeExtintionAutomatiqueEth() {
        if ($("input[name='Extintion_Automatique_Eth']").prop('checked') === true) {
            sliderExtintionAutomatiqueEthMin.slider("enable");
        } else {
            sliderExtintionAutomatiqueEthMin.slider("disable");
        }
    }

    var sliderExtintionAutomatiqueEthMin = $("input[name='Extintion_Automatique_Eth_min']").slider({
        value: tef.Extintion_Automatique_Eth_min,
        ticks: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max],

        ticks_labels: [tefDef.Extintion_Automatique_Eth_min.min, Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas)), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 2), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 3),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 4), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 5), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 6),
          Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 7), Number(tefDef.Extintion_Automatique_Eth_min.min) + (Number(tefDef.Extintion_Automatique_Eth_min.pas) * 8), tefDef.Extintion_Automatique_Eth_min.max + "min"],
        step: tefDef.Extintion_Automatique_Eth_min.step,
        tooltip: 'always',
        tooltip_position: 'bottom',
        formatter: function (v) {
            return `${v} min`;
        }
    });

    $("input[name='Extintion_Automatique_Eth']").change(changeExtintionAutomatiqueEth);

    changeExtintionAutomatiqueEth();



});
