/**
 *
 * @type {Module ini|Module ini}
 */

var ini = require('ini');
var fs = require('fs');
var sys = require('util');
const breadcrumbs = require("./breadcrumbs.js");
var multer = require('multer');
var upload = multer().single('uploaded_configuration');
var tefInfo = require('../msp/tefInfo');
var manreg = require('../models/manreg');
var kernel;
var exec = require('child_process').exec;
var kickedUser = false;
const spawnSync = require('child_process').spawnSync;
var local_armsettings_file    =  '/home/root/TEF/tef/database/local_settings.ini';
var default_armsetting_file   =  '/home/root/TEF/tef/database/default/armSettingsDefault.ini';
var SendFunction = require('../msp/index.js');
var mime = require('mime');
var fromFileIni = false;
var FileAudio01 = 0;
var FileAudio02 = 0;
var FileAudio03 = 0;
var FileAudio04 = 0;


//Controllo presenza file audio bibl
  if(fs.existsSync("/dmg/audio_msg/01.wav")){
    FileAudio01 = 1;
  }
  if(fs.existsSync("/dmg/audio_msg/02.wav")){
    FileAudio02 = 1;
  }
  if(fs.existsSync("/dmg/audio_msg/03.wav")){
    FileAudio03 = 1;
  }
  if(fs.existsSync("/dmg/audio_msg/04.wav")){
    FileAudio04 = 1;
  }



function puts(error, stdout, stderr) { sys.puts(stdout) }

function ResetTimer(){
  if(fs.existsSync("/dev/dmg/wd_alive")){
    fs.writeFileSync("/dev/dmg/wd_alive", "0");
    exec("sync",puts);
    console.log("ALIVE");
  } else {
    console.log("WD_ALIVE non trovato!");
  }
}

function StopTimer(){
  if(fs.existsSync("/dev/dmg/wd_stop")){
    fs.writeFileSync("/dev/dmg/wd_stop", "0");
    exec("sync",puts);
    console.log("STOP TIMER");
  } else {
    console.log("wd_stop non trovato!");
  }
}


module.exports = function (app, passport, msp) {

    var version = fs.readFileSync(__dirname + '/../version', 'utf-8');
    console.log("Application version: " + version);


    app.get('/', isLoggedIn, function (req, res) {
      //console.log(msp.isConnected());
      ResetTimer();
      if(req.query.getIndex != 1 && !msp.isConnected()){
        msp.retryInitARM(function(){
          if (msp.isConnected() === false && req.query.getIndex != 1) {
                //console.log(msp.isConnected());
                res.redirect('no_tef');
            } else {
                res.render('pages/index', {
                    username: req.user.username,
                    breadcrumbs: [breadcrumbs.home],
                    version: version, mspConnected: msp.isConnected(),
                    tefInfo: msp.getTEFInfo(),
                    kernelVersion: GetKernelVersion()
               });
            }
        });

      }
      else {
        res.render('pages/index', {
          username: req.user.username,
          breadcrumbs: [breadcrumbs.home],
          version: version, mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: GetKernelVersion()
        });
      }
    });

    app.get('/getinitarm_continue', function (req, res) {
      if(req.query.getIndex == 1){
        res.render('pages/configuration', {
          username: "Editor",
          breadcrumbs: [],
          version: version,
          mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: ""
        });
      }
      else{
        res.render('pages/getinitarm_continue',{
          username: req.user.username,
          breadcrumbs: [breadcrumbs.home],
          version: version,
          mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: GetKernelVersion()
        })
      }

    });

    app.get('/no_tef', isLoggedIn, function (req, res, next) {
        ResetTimer();
        if (msp.isConnected()) {
            res.redirect('/');
        }
        next();
    }, function (req, res) {
        res.render('pages/no_tef', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home],
        version: version,
        mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        kernelVersion: GetKernelVersion()
      });
    });

    app.get('/no_tef_start', function (req, res, next) {
        ResetTimer();
        if (msp.isConnected()) {
            res.redirect('/');
        }
        next();
    }, function (req, res) {
        res.render('pages/no_tef', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home],
        version: version,
        mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        kernelVersion: GetKernelVersion()
      });
    });

    app.get('/serial_debug', isLoggedIn, function (req, res) {
        res.render('pages/serial_debug', {
          username: req.user.username,
          breadcrumbs: [breadcrumbs.home],
          version: version,
          mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: GetKernelVersion()
        });
    });

    app.get('/login', function (req, res) {
      ResetTimer();
      res.render('pages/login', {
          errorMessage: req.flash('errorMessage'),
          message: req.flash('message'),
          version: version
        });
    });

    app.get('/forcelogout', function (req, res) {
      console.log("Forced logout requested by user.");
      ResetTimer();
      if(fs.existsSync("/tmp/session_id")){
        fs.unlinkSync("/tmp/session_id");
      }
      req.session.destroy();
      req.logout();
      res.redirect('/login');
    });

    app.post('/login',
      passport.authenticate('local', {
        successRedirect: '/',
        failureRedirect: '/login',
        failureFlash: true
      })
    );

    app.get('/logout', function (req, res) {
        console.log("Logout called.");
        ResetTimer();
        if(fs.existsSync("/tmp/session_id")){
          fs.unlinkSync("/tmp/session_id");
        }
        req.session.destroy();
        req.logout();
        res.redirect('/login');
    });

    app.get('/typologie', isLoggedIn, function (req, res) {
        ResetTimer();
        res.render('pages/configuration', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration],
            version: version,
            mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion()
        });
    });


    //#########################################################################
    //Load WiFi password change page
    app.get('/wifimdp', isLoggedIn, function (req, res) {
        ResetTimer();
        //Read from LocalSettings INI file
        var armLocalDefault = null;
        if ( fs.existsSync(local_armsettings_file))
        {
          try
          {
              armLocalDefault = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
          }
          catch(e)
          {
              armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
          }

        }
        else
        {
          armLocalDefault = ini.parse(fs.readFileSync(default_armsetting_file, 'utf-8'));
        }
        var Mot_De_Passe_Value = armLocalDefault.Settings.Mot_De_Passe;
        var Nom_Identifiant_Value = armLocalDefault.Settings.Nom_Identifiant;
        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>" + armLocalDefault.Settings.Mot_De_Passe);
        res.render('pages/wifimdp', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.Mot_De_Passe],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion(),
            Mot_De_Passe: Mot_De_Passe_Value,
            Nom_Identifiant: Nom_Identifiant_Value
        });
    });


    app.post('/updwifipwd', isLoggedIn, function (req, res) {
      ResetTimer();
      var local_Settings_save = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
      local_Settings_save.Settings.Mot_De_Passe = req.body.Mot_De_Passe;
      fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings_save.Settings, { section: 'Settings' }));
      exec("sync",puts);
      setTimeout(function() {
        exec("reboot", puts);
      }, 500);

        res.render('pages/index', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion()
        });
        });


    app.get('/configuration', isLoggedIn, function (req, res) {
        ResetTimer();
        switch (msp.getTEFInfo().getModelName()) {
            case  "BI.BC.M":
                var bibcm = require('../models/bibcm');
                msp.commands.getConfigurationbcm(function (config) {
                    bibcm.init(config.getTEFData());
                    res.render('pages/configs/bibcm', {
                        username: req.user.username,
                        breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                        version: version,
                        mspConnected: msp.isConnected(),
                        tefInfo: msp.getTEFInfo(),
                        bibcm: bibcm,
                        kernelVersion: GetKernelVersion()
                    });
                });
                break;
                case  "BI.BC.CLA":
                    var bibccla = require('../models/bibccla');
                    msp.commands.getConfigurationbccla(function (configb) {
                        bibccla.init(configb.getTEFData());
                        res.render('pages/configs/bibccla', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            bibccla: bibccla,
                            kernelVersion: GetKernelVersion()
                        });
                    });
                break;
                case  "BI.BL":
                    var bibl = require('../models/bibl');
                    msp.commands.getConfigurationbibl(function (configb) {
                        bibl.init(configb.getTEFData());
                        res.render('pages/configs/bibl', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            bibl: bibl,
                            fileaudio01: FileAudio01,
                            kernelVersion: GetKernelVersion()
                        });
                    });
                break;
                case  "BI.BC.PRO1":
                case  "BI.BC.PRO2":
                case  "BI.BC.PRO3":
                   var bibcpro = require('../models/bibcpro');
                   msp.commands.getConfigurationbcpro(function (configc) {
                      bibcpro.init(configc.getTEFData());
                      msp.commands.getPhoneBook(function (phoneb) {
                            bibcpro.setPhoneB(phoneb.getTEFData());
                            res.render('pages/configs/bibcpro', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                bibcpro: bibcpro,
                                kernelVersion: GetKernelVersion()
                              });
                            });
                          });
                 break;
                 case  "HI":
                     var hi = require('../models/hi');
                     msp.commands.getConfigurationhi(function (configb) {
                         hi.init(configb.getTEFData());
                         res.render('pages/configs/hi', {
                             username: req.user.username,
                             breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                             version: version, mspConnected: msp.isConnected(),
                             tefInfo: msp.getTEFInfo(),
                             hi: hi,
                             fileaudio01: FileAudio01,
                             kernelVersion: GetKernelVersion()
                         });
                     });
                 break;
                 case  "HI2":
                     var hi2 = require('../models/hi2');
                     msp.commands.getConfigurationhi2(function (configb) {
                         hi2.init(configb.getTEFData());
                         res.render('pages/configs/hi2', {
                             username: req.user.username,
                             breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                             version: version, mspConnected: msp.isConnected(),
                             tefInfo: msp.getTEFInfo(),
                             hi2: hi2,
                             fileaudio01: FileAudio01,
                             kernelVersion: GetKernelVersion()
                         });
                     });
                 break;
            default:
                res.render('pages/configuration', {
                    username: req.user.username,
                    breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration],
                    version: version, mspConnected: msp.isConnected(),
                    tefInfo: msp.getTEFInfo(),
                    kernelVersion: GetKernelVersion()
                });
        }
    });


        app.get('/visualisation', isLoggedIn, function (req, res) {
          ResetTimer();
            switch (msp.getTEFInfo().getModelName()) {
                case "BI.BC.M":
                    var bibcm = require('../models/bibcm');
                    msp.commands.getConfigurationbcm(function (config) {
                        bibcm.init(config.getTEFData());
                        res.render('pages/vis/bibcm', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_bibcm],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            bibcm: bibcm,
                            kernelVersion: GetKernelVersion()
                        });
                    });
                    break;
                    case  "BI.BC.CLA":
                        var bibccla = require('../models/bibccla');
                        msp.commands.getConfigurationbccla(function (configb) {
                            bibccla.init(configb.getTEFData());
                            res.render('pages/vis/bibccla', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_bibccla],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                bibccla: bibccla,
                                kernelVersion: GetKernelVersion()
                            });
                        });
                    break;
                    case  "BI.BL":
                        var bibl = require('../models/bibl');
                        msp.commands.getConfigurationbibl(function (configb) {
                            bibl.init(configb.getTEFData());
                            res.render('pages/vis/bibl', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_bibl],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                bibl: bibl,
                                kernelVersion: GetKernelVersion()
                            });
                        });
                    break;
                    case  "HI":
                        var hi = require('../models/hi');
                        msp.commands.getConfigurationhi(function (configb) {
                            hi.init(configb.getTEFData());
                            res.render('pages/vis/hi', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_hi],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                hi: hi,
                                kernelVersion: GetKernelVersion()
                            });
                        });
                    break;
                    case  "HI2":
                        var hi2 = require('../models/hi2');
                        msp.commands.getConfigurationhi2(function (configb) {
                            hi2.init(configb.getTEFData());
                            res.render('pages/vis/hi2', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_hi2],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                hi2: hi2,
                                kernelVersion: GetKernelVersion()
                            });
                        });
                    break;
                    case  "BI.BC.PRO1":
                    case  "BI.BC.PRO2":
                    case  "BI.BC.PRO3":
                       var bibcpro = require('../models/bibcpro');
                       msp.commands.getConfigurationbcpro(function (config) {
                        bibcpro.init(config.getTEFData());
                        msp.commands.getPhoneBook(function (phoneb) {
                              bibcpro.setPhoneB(phoneb.getTEFData());
                              console.log(JSON.stringify(bibcpro.getDataDefault(), null, 4))
                        res.render('pages/vis/bibcpro', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation, breadcrumbs.config_bibcpro],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            bibcpro: bibcpro,
                            kernelVersion: GetKernelVersion()
                            });
                        });
                    });
                    break;
                default:
                    res.render('pages/visualization', {
                        username: req.user.username,
                        breadcrumbs: [breadcrumbs.home, breadcrumbs.visualisation],
                        version: version, mspConnected: msp.isConnected(),
                        tefInfo: msp.getTEFInfo(),
                        kernelVersion: GetKernelVersion()
                    });
            }

    });


    app.get('/chargement', isLoggedIn, function (req, res) {
      ResetTimer();
      console.log("Importazione file INI. GET");
        res.render('pages/chargement', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.chargement],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion()
        });
    });

    var configFromFile = null;
    app.post('/chargement', isLoggedIn, function (req, res) {
        ResetTimer();
        upload(req, res, function (err) {
            var out = {};
            if (err) {
                out.result = false;
                out.reason = 'ErrorOccured';
                res.end(JSON.stringify(out));
                console.log("Importazione file INI. ErrorOccured");
                return;
            }
            configFromFile = ini.parse(req.file.buffer.toString());
            if (typeof configFromFile.Configuration === 'undefined') {
                configFromFile = null;
                out.result = false;
                out.reason = 'MissingConfigurationSection';
                res.end(JSON.stringify(out));
                console.log("Importazione file INI. MissingConfigurationSection");
                return;
            }
            if (typeof configFromFile.Configuration.Typologie_TEF === 'undefined') {
                configFromFile = null;
                out.result = false;
                out.reason = 'MissingTypologie_TEF';
                res.end(JSON.stringify(out));
                console.log("Importazione file INI. MissingTypologie_TEF");
                return;
            }
            console.log("Importazione file INI. Tipo TEF: " + configFromFile.Configuration.Typologie_TEF);
            switch (configFromFile.Configuration.Typologie_TEF) {
                case 'bibl':
                    out.result = true;
                    out.href = '/configs/bibl';
                    fromFileIni = true;
                    console.log("Importazione file INI. Tipo > BIBL");
                    res.end(JSON.stringify(out));
                    break;
                case 'bibcpro':
                    out.result = true;
                    out.href = '/configs/bibcpro';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                case 'bibccla':
                    out.result = true;
                    out.href = '/configs/bibccla';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                case 'bibcm':
                    out.result = true;
                    out.href = '/configs/bibcm';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                case 'hi':
                    out.result = true;
                    out.href = '/configs/hi';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                case 'hi2':
                    out.result = true;
                    out.href = '/configs/hi2';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                case 'radio':
                    out.result = true;
                    out.href = '/configs/radio';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    break;
                default:
                    out.result = false;
                    out.reason = 'UnknownTypologie_TEF';
                    fromFileIni = true;
                    res.end(JSON.stringify(out));
                    return;
            }
        });
    });

    app.get('/telechargement', isLoggedIn, function (req, res) {
      ResetTimer();
      var TimeoutAttivo = fs.readFileSync("/dev/dmg/wd_start");
      if (TimeoutAttivo != " is Disable\n"){
          fs.writeFileSync("/dev/dmg/wd_start", "60 60 1");
          exec("sync",puts);
      }
        res.render('pages/telechargement', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.telechargement],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion()
        });
    });

    var configFromFile = null;
    app.post('/telechargement', isLoggedIn, function (req, res) {
        console.log("Upload firmware");
        StopTimer();
        upload(req, res, function (err) {
            console.log("Upload firmware");
            var out = {};
            if (err) {
                out.result = false;
                out.reason = 'ErrorOccured';
                res.end(JSON.stringify(out));
                return;
            }
            console.log(req.file.buffer);
            if (req.file.buffer[0] !== 0x53 || req.file.buffer[1] !== 0x30) {
                out.result = false;
                out.reason = 'WrongBegin';
                res.end(JSON.stringify(out));
                return;
            }
            out.result = true;
            res.end(JSON.stringify(out));
            msp.firmwareUpdate(req.file.buffer.toString("hex"));
        });
    });

    app.get('/error_file_s19', isLoggedIn, function (req, res) {
       ResetTimer();
        res.render('pages/error_file_s19', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.telechargement],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            kernelVersion: GetKernelVersion()
        });
    });







//******************************************************************************************************************************************************************
//   BI.BL
//******************************************************************************************************************************************************************

app.get('/configs/bibl', isLoggedIn, function (req, res) {
  ResetTimer();
    var bibl = require('../models/bibl');
    console.log("From file ini:" + fromFileIni);
    if( msp.getTEFInfo().getModelName() ===  "BI.BL" && fromFileIni == false)
    {
      console.log('/configs/bibl Page load BI.BL with Configuration from TEF');
      msp.commands.getConfigurationbibl(function (config) {
      bibl.init(config.getTEFData())
      res.render('pages/configs/bibl', {
                 username: req.user.username,
                 breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
                 version: version, mspConnected: msp.isConnected(),
                 tefInfo: msp.getTEFInfo(),
                 bibl: bibl,
                 kernelVersion: GetKernelVersion()
           });
         });
    }
    else {
      if (configFromFile === null) {
              console.log('/configs/bibl  Page load BI.BL with Default Configuration');
              bibl.init(false);
      }
      else
      {
        bibl.init(configFromFile.Configuration);
        bibl.validate();
        configFromFile = null;
          console.log('/configs/bibl  Page load BI.BL with INI file data');
      }
      fromFileIni == false;
      res.render('pages/configs/bibl', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        bibl: bibl,
        kernelVersion: GetKernelVersion()
    });
  }
});

app.get('/configs/biblD', isLoggedIn, function (req, res) {
  ResetTimer();
    var bibl = require('../models/bibl');
      console.log('/configs/biblD Reload Default Configuration File BI.BL');
      if (configFromFile === null) {
        bibl.init(false);
      }
      else
      {
        bibl.init(configFromFile.Configuration);
        bibl.validate();
        configFromFile = null;
      }
      res.render('pages/configs/bibl', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        bibl: bibl,
        kernelVersion: GetKernelVersion()
    });
});

app.post('/configs/bibl', isLoggedIn, function (req, res) {
  ResetTimer();
    var bibl = require('../models/bibl');
    console.log('/configs/bibl Send Configuration File BI.BL to TEF');
    bibl.init(req.body);
    console.log("###################################################" + req.body.Nom_Identifiant);
    bibl.normalize();
    if (bibl.validate()) {
        msp.commands.setConfigurationbibl(bibl.getData(), function () {
              msp.commands.getInitARM(function (message) {
                tefInfo.parseInitARM(message);
                msp.commands.getConfigurationbibl(function (config) {
                bibl.init(config.getTEFData());
                res.render('pages/configs/bibl', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: tefInfo,
                bibl: bibl,
                kernelVersion: GetKernelVersion()
              });
          });
        });
      });
    } else {
        res.render('pages/configs/bibl', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            bibl: bibl,
            kernelVersion: GetKernelVersion()
        });
    }
});

app.post('/configs/biblD', isLoggedIn, function (req, res) {
  ResetTimer();
    var bibl = require('../models/bibl');
    console.log('/configs/biblD Export Configuration File BI.BL to File');
    bibl.init(req.body);
    bibl.normalize();
    if (bibl.validate()) {
        var tefData = bibl.export();
        var nomeTEF = req.body.Nom_Identifiant;
        res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
        res.setHeader('Content-type', 'text/plain');
        res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
    } else {

        res.render('pages/configs/bibl', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibl],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            bibl: bibl,
            kernelVersion: GetKernelVersion()
        });
    }
});

app.post('/configs/biblV', isLoggedIn, function (req, res) {
    ResetTimer();
    var bibl = require('../models/bibl');
        var tefData = bibl.export();
        var nomeTEF = req.body.Nom_Identifiant;
        res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
        res.setHeader('Content-type', 'text/plain');
        res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
    });






//******************************************************************************************************************************************************************
//   BI.BC.PRO
//******************************************************************************************************************************************************************

     app.get('/configs/bibcpro', isLoggedIn, function (req, res) {
       ResetTimer();
         var bibcpro = require('../models/bibcpro');
         if( msp.getTEFInfo().getModelName().indexOf("BI.BC.PRO") > -1 && fromFileIni == false)
         {
           console.log('/configs/bibcpro Page load BC.PRO with Configuration from TEF');
           msp.commands.getConfigurationbcpro(function (config) {
              bibcpro.init(config.getTEFData());
              msp.commands.getPhoneBook(function (phoneb) {
                    bibcpro.setPhoneB(phoneb.getTEFData());
                    res.render('pages/configs/bibcpro', {
                        username: req.user.username,
                        breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
                        version: version, mspConnected: msp.isConnected(),
                        tefInfo: msp.getTEFInfo(),
                        bibcpro: bibcpro,
                        kernelVersion: GetKernelVersion()
                      });
                    });
                  });
         }
         else {
           console.log('/configs/bibcpro  Page load BC.PRO with Default Configuration');
           if (configFromFile === null) {
                   bibcpro.init(false);
           }
           else
           {
             bibcpro.init(configFromFile.Configuration);
             bibcpro.validate();
             configFromFile = null;
           }
           fromFileIni == false;
           res.render('pages/configs/bibcpro', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             bibcpro: bibcpro,
             kernelVersion: GetKernelVersion()
         });
       }
     });

     app.get('/configs/bibcproD', isLoggedIn, function (req, res) {
       ResetTimer();
         var bibcpro = require('../models/bibcpro');
           console.log('/configs/bibcproD Reload Default Configuration File BC.PRO');
           if (configFromFile === null) {
             bibcpro.init(false);
           }
           else
           {
             bibcpro.init(configFromFile.Configuration);
             bibcpro.validate();
             configFromFile = null;
           }
           res.render('pages/configs/bibcpro', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             bibcpro: bibcpro,
             kernelVersion: GetKernelVersion()
         });
     });

     app.post('/configs/bibcpro', isLoggedIn, function (req, res) {
       ResetTimer();
         var bibcpro = require('../models/bibcpro');

         bibcpro.init(req.body);
         bibcpro.normalize();
         if (bibcpro.validate())
         {
           console.log('/configs/bibcpro Send Configuration File BC.PRO to TEF');
             msp.commands.setConfigurationbcpro(bibcpro.getData(), function ()
             {
                 msp.commands.setPhoneBook(bibcpro.getData(),function()
                 {
                   msp.commands.getInitARM(function (message)
                   {
                        tefInfo.parseInitARM(message);
                        msp.commands.getConfigurationbcpro(function (config) {
                           bibcpro.init(config.getTEFData());
                           msp.commands.getPhoneBook(function (phoneb) {
                                 bibcpro.setPhoneB(phoneb.getTEFData());
                                 res.render('pages/configs/bibcpro', {
                                     username: req.user.username,
                                     breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
                                     version: version,
                                     mspConnected: msp.isConnected(),
                                     tefInfo: msp.getTEFInfo(),
                                     bibcpro: bibcpro,
                                     kernelVersion: GetKernelVersion()
                                   });
                                 });
                          });
                    });
                });
           });

         } else {
           console.log('/configs/bibcpro Send Configuration File BC.PRO Vialidate Fails');
             res.render('pages/configs/bibcpro', {
                 username: req.user.username,
                 breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
                 version: version, mspConnected: msp.isConnected(),
                 tefInfo: msp.getTEFInfo(),
                 bibcpro: bibcpro,
                 kernelVersion: GetKernelVersion()
             });
         }
     });

     app.post('/configs/bibcproD', isLoggedIn, function (req, res) {
       ResetTimer();
         var bibcpro = require('../models/bibcpro');
         console.log('/configs/bibcproD Export Configuration File BC.PRO to File');
         bibcpro.init(req.body);
         bibcpro.normalize();
         if (bibcpro.validate()) {
             var tefData = bibcpro.export();
             var nomeTEF = req.body.Nom_Identifiant;
            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
             res.setHeader('Content-type', 'text/plain');
             res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
         } else {

             res.render('pages/configs/bibcpro', {
                 username: req.user.username,
                 breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcpro],
                 version: version, mspConnected: msp.isConnected(),
                 tefInfo: msp.getTEFInfo(),
                 bibcpro: bibcpro,
                 kernelVersion: GetKernelVersion()
             });
         }
     });

     app.post('/configs/bibcproV', isLoggedIn, function (req, res) {
       ResetTimer();
         var bibcpro = require('../models/bibcpro');
             var tefData = bibcpro.export();
             var nomeTEF = req.body.Nom_Identifiant;
             res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
             res.setHeader('Content-type', 'text/plain');
             res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
         });

//******************************************************************************************************************************************************************
//  BI.BC.CLA
//******************************************************************************************************************************************************************


    app.get('/configs/bibccla', isLoggedIn, function (req, res) {
      ResetTimer();
        var bibccla = require('../models/bibccla');
        if( msp.getTEFInfo().getModelName() ===  "BI.BC.CLA" && fromFileIni == false)
        {
          console.log('/configs/bibccla Page load BC.CLA with Configuration from TEF');
          msp.commands.getConfigurationbccla(function (config) {
          bibccla.init(config.getTEFData())
          res.render('pages/configs/bibccla', {
                     username: req.user.username,
                     breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
                     version: version, mspConnected: msp.isConnected(),
                     tefInfo: msp.getTEFInfo(),
                     bibccla: bibccla,
                     kernelVersion: GetKernelVersion()
               });
             });
        }
        else {
          console.log('/configs/bibccla  Page load BC.CLA with Default Configuration');
          if (configFromFile === null) {
                  bibccla.init(false);
          }
          else
          {
            bibccla.init(configFromFile.Configuration);
            bibccla.validate();
            configFromFile = null;
          }
          fromFileIni == false;
          res.render('pages/configs/bibccla', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            bibccla: bibccla,
            kernelVersion: GetKernelVersion()
        });
      }
    });

    app.get('/configs/bibcclaD', isLoggedIn, function (req, res) {
      ResetTimer();
        var bibccla = require('../models/bibccla');
          console.log('/configs/bibcclaD Reload Default Configuration File BC.CLA');
          if (configFromFile === null) {
            bibccla.init(false);
          }
          else
          {
            bibccla.init(configFromFile.Configuration);
            bibccla.validate();
            configFromFile = null;
          }
          res.render('pages/configs/bibccla', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            bibccla: bibccla,
            kernelVersion: GetKernelVersion()
        });
    });

    app.post('/configs/bibccla', isLoggedIn, function (req, res) {
      ResetTimer();
        var bibccla = require('../models/bibccla');
        console.log('/configs/bibccla Send Configuration File BC.CLA to TEF');
        bibccla.init(req.body);
        console.log("###################################################" + req.body.Nom_Identifiant);
        bibccla.normalize();
        if (bibccla.validate()) {
            msp.commands.setConfigurationbccla(bibccla.getData(), function () {
                  msp.commands.getInitARM(function (message) {
                    tefInfo.parseInitARM(message);
                    msp.commands.getConfigurationbccla(function (config) {
                    bibccla.init(config.getTEFData());
                    res.render('pages/configs/bibccla', {
                    username: req.user.username,
                    breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
                    version: version, mspConnected: msp.isConnected(),
                    tefInfo: tefInfo,
                    bibccla: bibccla,
                    kernelVersion: GetKernelVersion()
                  });
              });
            });
          });
        } else {
            res.render('pages/configs/bibccla', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                bibccla: bibccla,
                kernelVersion: GetKernelVersion()
            });
        }
    });

    app.post('/configs/bibcclaD', isLoggedIn, function (req, res) {
      ResetTimer();
        var bibccla = require('../models/bibccla');
        console.log('/configs/bibcclaD Export Configuration File BC.CLA to File');
        bibccla.init(req.body);
        bibccla.normalize();
        if (bibccla.validate()) {
            var tefData = bibccla.export();
            var nomeTEF = req.body.Nom_Identifiant;
            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
            res.setHeader('Content-type', 'text/plain');
            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
        } else {

            res.render('pages/configs/bibccla', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibccla],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                bibccla: bibccla,
                kernelVersion: GetKernelVersion()
            });
        }
    });

   app.post('/configs/bibcclaV', isLoggedIn, function (req, res) {
        ResetTimer();
        var bibccla = require('../models/bibccla');
            var tefData = bibccla.export();
            var nomeTEF = req.body.Nom_Identifiant;
            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
            res.setHeader('Content-type', 'text/plain');
            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
        });

//******************************************************************************************************************************************************************
// BI.BC.M
//******************************************************************************************************************************************************************


    app.get('/configs/bibcm', isLoggedIn, function (req, res) {
        ResetTimer();
        var bibcm = require('../models/bibcm');
             if( msp.getTEFInfo().getModelName() ===  "BI.BC.M" && fromFileIni == false)
             {
               console.log('/configs/bibcm Page load BC.M with Configuration from TEF');
               msp.commands.getConfigurationbcm(function (config) {
               bibcm.init(config.getTEFData())
               res.render('pages/configs/bibcm', {
                          username: req.user.username,
                          breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                          version: version, mspConnected: msp.isConnected(),
                          tefInfo: msp.getTEFInfo(),
                          bibcm: bibcm,
                          kernelVersion: GetKernelVersion()
                    });
                  });
             }
             else {
               console.log('/configs/bibcm  Page load BC.M with Default Configuration');
               if (configFromFile === null) {
                       bibcm.init(false);
               }
               else
               {
                 bibcm.init(configFromFile.Configuration);
                 bibcm.validate();
                 configFromFile = null;
               }
               fromFileIni == false;
               res.render('pages/configs/bibcm', {
                 username: req.user.username,
                 breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                 version: version, mspConnected: msp.isConnected(),
                 tefInfo: msp.getTEFInfo(),
                 bibcm: bibcm,
                 kernelVersion: GetKernelVersion()
             });
           }
         });

         app.get('/configs/bibcmD', isLoggedIn, function (req, res) {
           ResetTimer();
             var bibcm = require('../models/bibcm');
               console.log('/configs/bibcmD Reload Default Configuration File BC.M');
               if (configFromFile === null) {
                 bibcm.init(false);
               }
               else
               {
                 bibcm.init(configFromFile.Configuration);
                 bibcm.validate();
                 configFromFile = null;
               }
               res.render('pages/configs/bibcm', {
                 username: req.user.username,
                 breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                 version: version, mspConnected: msp.isConnected(),
                 tefInfo: msp.getTEFInfo(),
                 bibcm: bibcm,
                 kernelVersion: GetKernelVersion()
             });
         });

         app.post('/configs/bibcm', isLoggedIn, function (req, res) {
             ResetTimer();
             var bibcm = require('../models/bibcm');
             bibcm.init(req.body);
             bibcm.normalize();
             if (bibcm.validate()) {
               console.log('/configs/bibcm Send Configuration File BC.M to TEF');
                 msp.commands.setConfigurationbcm(bibcm.getData(), function () {
                    msp.commands.getInitARM(function (message) {
                       tefInfo.parseInitARM(message);
                        msp.commands.getConfigurationbcm(function (config) {
                        bibcm.init(config.getTEFData());
                        res.render('pages/configs/bibcm', {
                         username: req.user.username,
                         breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                         version: version, mspConnected: msp.isConnected(),
                         tefInfo: tefInfo,
                         bibcm: bibcm,
                         kernelVersion: GetKernelVersion()
                     });
                   });
                   });
                 });
             } else {
               console.log('/configs/bibcm Non Valid Configuration File BC.M to TEF');
                 res.render('pages/configs/bibcm', {
                     username: req.user.username,
                     breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                     version: version, mspConnected: msp.isConnected(),
                     tefInfo: msp.getTEFInfo(),
                     bibcm: bibcm,
                     kernelVersion: GetKernelVersion()
                 });
             }
         });

         app.post('/configs/bibcmD', isLoggedIn, function (req, res) {
             ResetTimer();
             var bibcm = require('../models/bibcm');
             console.log('/configs/bibcmD Export Configuration File BC.M to File');
             bibcm.init(req.body);
             bibcm.normalize();
             if (bibcm.validate()) {
                 var tefData = bibcm.export();
                 var nomeTEF = req.body.Nom_Identifiant;
                 res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
                 res.setHeader('Content-type', 'text/plain');
                 res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
             } else {

                 res.render('pages/configs/bibcm', {
                     username: req.user.username,
                     breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_bibcm],
                     version: version, mspConnected: msp.isConnected(),
                     tefInfo: msp.getTEFInfo(),
                     bibcm: bibcm,
                     kernelVersion: GetKernelVersion()
                 });
             }
         });



   app.post('/configs/bibcmV', isLoggedIn, function (req, res) {
        ResetTimer();
        var bibcm = require('../models/bibcm');
            var tefData = bibcm.export();
            var nomeTEF = req.body.Nom_Identifiant;
            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
            res.setHeader('Content-type', 'text/plain');
            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
        });


//******************************************************************************************************************************************************************
//   HI
//******************************************************************************************************************************************************************

        app.get('/configs/hi', isLoggedIn, function (req, res) {
          ResetTimer();
            var hi = require('../models/hi');
            console.log("From file ini:" + fromFileIni);
            if( msp.getTEFInfo().getModelName() ===  "HI" && fromFileIni == false)
            {
              console.log('/configs/hi Page load HI with Configuration from TEF');
              msp.commands.getConfigurationhi(function (config) {
              hi.init(config.getTEFData())
              res.render('pages/configs/hi', {
                         username: req.user.username,
                         breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                         version: version, mspConnected: msp.isConnected(),
                         tefInfo: msp.getTEFInfo(),
                         hi: hi,
                         kernelVersion: GetKernelVersion()
                   });
                 });
            }
            else {
              if (configFromFile === null) {
                      console.log('/configs/hi  Page load HI with Default Configuration');
                      hi.init(false);
              }
              else
              {
                hi.init(configFromFile.Configuration);
                hi.validate();
                configFromFile = null;
                  console.log('/configs/hi  Page load HI with INI file data');
              }
              fromFileIni == false;
              res.render('pages/configs/hi', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                hi: hi,
                kernelVersion: GetKernelVersion()
            });
          }
        });

        app.get('/configs/hiD', isLoggedIn, function (req, res) {
          ResetTimer();
            var hi = require('../models/hi');
              console.log('/configs/hiD Reload Default Configuration File HI');
              if (configFromFile === null) {
                hi.init(false);
              }
              else
              {
                hi.init(configFromFile.Configuration);
                hi.validate();
                configFromFile = null;
              }
              res.render('pages/configs/hi', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                hi: hi,
                kernelVersion: GetKernelVersion()
            });
        });

        app.post('/configs/hi', isLoggedIn, function (req, res) {
          ResetTimer();
            var hi = require('../models/hi');
            console.log('/configs/hi Send Configuration File HI to TEF');
            hi.init(req.body);
            console.log("###################################################" + req.body.Nom_Identifiant);
            hi.normalize();
            if (hi.validate()) {
                msp.commands.setConfigurationhi(hi.getData(), function () {
                      msp.commands.getInitARM(function (message) {
                        tefInfo.parseInitARM(message);
                        msp.commands.getConfigurationhi(function (config) {
                        hi.init(config.getTEFData());
                        res.render('pages/configs/hi', {
                        username: req.user.username,
                        breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                        version: version, mspConnected: msp.isConnected(),
                        tefInfo: tefInfo,
                        hi: hi,
                        kernelVersion: GetKernelVersion()
                      });
                  });
                });
              });
            } else {
                res.render('pages/configs/hi', {
                    username: req.user.username,
                    breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                    version: version, mspConnected: msp.isConnected(),
                    tefInfo: msp.getTEFInfo(),
                    hi: hi,
                    kernelVersion: GetKernelVersion()
                });
            }
        });

        app.post('/configs/hiD', isLoggedIn, function (req, res) {
          ResetTimer();
            var hi = require('../models/hi');
            console.log('/configs/hiD Export Configuration File HI to File');
            hi.init(req.body);
            hi.normalize();
            if (hi.validate()) {
                var tefData = hi.export();
                var nomeTEF = req.body.Nom_Identifiant;
                res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
                res.setHeader('Content-type', 'text/plain');
                res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
            } else {

                res.render('pages/configs/hi', {
                    username: req.user.username,
                    breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi],
                    version: version, mspConnected: msp.isConnected(),
                    tefInfo: msp.getTEFInfo(),
                    hi: hi,
                    kernelVersion: GetKernelVersion()
                });
            }
        });

        app.post('/configs/hiV', isLoggedIn, function (req, res) {
            ResetTimer();
            var hi = require('../models/hi');
                var tefData = hi.export();
                var nomeTEF = req.body.Nom_Identifiant;
                res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
                res.setHeader('Content-type', 'text/plain');
                res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
            });


//******************************************************************************************************************************************************************
//   HI2
//******************************************************************************************************************************************************************

                    app.get('/configs/hi2', isLoggedIn, function (req, res) {
                      ResetTimer();
                        var hi2 = require('../models/hi2');
                        console.log("From file ini:" + fromFileIni);
                        if( msp.getTEFInfo().getModelName() ===  "HI2" && fromFileIni == false)
                        {
                          console.log('/configs/hi2 Page load HI2 with Configuration from TEF');
                          msp.commands.getConfigurationhi2(function (config) {
                          hi2.init(config.getTEFData())
                          res.render('pages/configs/hi2', {
                                     username: req.user.username,
                                     breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                                     version: version, mspConnected: msp.isConnected(),
                                     tefInfo: msp.getTEFInfo(),
                                     hi2: hi2,
                                     kernelVersion: GetKernelVersion()
                               });
                             });
                        }
                        else {
                          if (configFromFile === null) {
                                  console.log('/configs/hi2  Page load HI2 with Default Configuration');
                                  hi2.init(false);
                          }
                          else
                          {
                            hi2.init(configFromFile.Configuration);
                            hi2.validate();
                            configFromFile = null;
                              console.log('/configs/hi2  Page load HI2 with INI file data');
                          }
                          fromFileIni == false;
                          res.render('pages/configs/hi2', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            hi2: hi2,
                            kernelVersion: GetKernelVersion()
                        });
                      }
                    });

                    app.get('/configs/hi2D', isLoggedIn, function (req, res) {
                      ResetTimer();
                        var hi2 = require('../models/hi2');
                          console.log('/configs/hi2D Reload Default Configuration File HI2');
                          if (configFromFile === null) {
                            hi2.init(false);
                          }
                          else
                          {
                            hi2.init(configFromFile.Configuration);
                            hi2.validate();
                            configFromFile = null;
                          }
                          res.render('pages/configs/hi2', {
                            username: req.user.username,
                            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                            version: version, mspConnected: msp.isConnected(),
                            tefInfo: msp.getTEFInfo(),
                            hi2: hi2,
                            kernelVersion: GetKernelVersion()
                        });
                    });

                    app.post('/configs/hi2', isLoggedIn, function (req, res) {
                      console.log('/configs/hi2 Send Configuration File HI2 to TEF');
                      ResetTimer();
                        var hi2 = require('../models/hi2');

                        hi2.init(req.body);
                        console.log("###################################################" + req.body.Nom_Identifiant);
                        hi2.normalize();
                        if (hi2.validate()) {
                            msp.commands.setConfigurationhi2(hi2.getData(), function () {
                                  msp.commands.getInitARM(function (message) {
                                    tefInfo.parseInitARM(message);
                                    msp.commands.getConfigurationhi2(function (config) {
                                    hi2.init(config.getTEFData());
                                    res.render('pages/configs/hi2', {
                                    username: req.user.username,
                                    breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                                    version: version, mspConnected: msp.isConnected(),
                                    tefInfo: tefInfo,
                                    hi2: hi2,
                                    kernelVersion: GetKernelVersion()
                                  });
                              });
                            });
                          });
                        } else {
                            res.render('pages/configs/hi2', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                hi2: hi2,
                                kernelVersion: GetKernelVersion()
                            });
                        }
                    });

                    app.post('/configs/hi2D', isLoggedIn, function (req, res) {
                      ResetTimer();
                        var hi2 = require('../models/hi2');
                        console.log('/configs/hi2D Export Configuration File HI2 to File');
                        hi2.init(req.body);
                        hi2.normalize();
                        if (hi2.validate()) {
                            var tefData = hi2.export();
                            var nomeTEF = req.body.Nom_Identifiant;
                            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
                            res.setHeader('Content-type', 'text/plain');
                            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
                        } else {

                            res.render('pages/configs/hi2', {
                                username: req.user.username,
                                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_hi2],
                                version: version, mspConnected: msp.isConnected(),
                                tefInfo: msp.getTEFInfo(),
                                hi2: hi2,
                                kernelVersion: GetKernelVersion()
                            });
                        }
                    });

                    app.post('/configs/hi2V', isLoggedIn, function (req, res) {
                        ResetTimer();
                        var hi2 = require('../models/hi2');
                            var tefData = hi2.export();
                            var nomeTEF = req.body.Nom_Identifiant;
                            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
                            res.setHeader('Content-type', 'text/plain');
                            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
                        });



//******************************************************************************************************************************************************************
//RADIO
//******************************************************************************************************************************************************************


    app.get('/configs/radio', isLoggedIn, function (req, res) {
      ResetTimer();
        var radio = require('../models/radio');
        if (configFromFile === null) {
            radio.init(false);
        } else {
            radio.init(configFromFile.Configuration);
            radio.validate();
            configFromFile = null;
        }
        res.render('pages/configs/radio', {
            username: req.user.username,
            breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_radio],
            version: version, mspConnected: msp.isConnected(),
            tefInfo: msp.getTEFInfo(),
            radio: radio,
            kernelVersion: GetKernelVersion()
        });
    });

    app.post('/configs/radio', isLoggedIn, function (req, res) {
      ResetTimer();
        var radio = require('../models/radio');
        radio.init(req.body);
        radio.normalize();
        if (radio.validate()) {
            var tefData = radio.export();
            var nomeTEF = req.body.Nom_Identifiant;
            res.setHeader('Content-disposition', 'attachment; filename=' + nomeTEF + '.ini');
            res.setHeader('Content-type', 'text/plain');
            res.end(ini.stringify(tefData, {section: 'Configuration', whitespace: true}));
        } else {
            res.render('pages/configs/radio', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.configuration, breadcrumbs.config_radio],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                radio: radio,
                kernelVersion: GetKernelVersion()
            });
        }
    });

//******************************************************************************************************************************************************************
//INIZIO SEZIONE REGOLAZIONE MANUALE GUADAGNO - L1
//******************************************************************************************************************************************************************

//Carico pagina regolazione manuale
app.get('/manreg', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log('/models/manreg Page load Manual Calibration from TEF');

    var ManregMode = req.query.m;
    switch (ManregMode){
      case "1":
        ManregMode = "transmission";
        res.render('pages/manreg', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        manreg: manreg,
        mode: ManregMode,
        kernelVersion: GetKernelVersion()
        });
        break;
      case "2":
        ManregMode = "reception";
        res.render('pages/manreg', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        manreg: manreg,
        mode: ManregMode,
        kernelVersion: GetKernelVersion()
        });
        break;
      default:
      ManregMode = "nothing";
      msp.commands.getManualSetting(function (config) {
               manreg.init(config.getTEFmanreg())
               res.render('pages/manreg', {
               username: req.user.username,
               breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
               version: version, mspConnected: msp.isConnected(),
               tefInfo: msp.getTEFInfo(),
               manreg: manreg,
               mode: ManregMode,
               kernelVersion: GetKernelVersion()
               });
          });
    }
    console.log("ManregMode:" + ManregMode);
  });

// REGOLAZIONE MANUALE - Richiesta di spegnimento altoparlante - Prova microfono in trasmissione
app.get('/spegnialtoparlante', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " spegnialtoparlante !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicON();
    msp.commands.setManualSetting(manreg.getData(), function (config) {
      res.render('pages/manreg', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             manreg: manreg,
             mode: 'transmission',
             kernelVersion: GetKernelVersion()
             });
        });

});

// REGOLAZIONE MANUALE - Richiesta di salvataggio del valore guadagno microfono - Riattivo il normale funzionamento
app.get('/registraaccendialtoparlante', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " registraaccendialtoparlante !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    var local_Settings_save = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
    local_Settings_save.Settings.Niveau_de_sortie = req.query.val;
    fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings_save.Settings, { section: 'Settings' }));
    msp.commands.setManualSetting(manreg.getData(), function (config) {
      msp.commands.saveManualSetting(function (config) {
        res.render('pages/manreg', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: '',
                kernelVersion: GetKernelVersion()
        });
      });
    });
});

// REGOLAZIONE MANUALE - Richiesta di accensione altoparlante SENZA salvataggio guadagno microfono - Riattivo il normale funzionamento
app.get('/accendialtoparlante', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " accendialtoparlante !!!!!!!!!!!!!");
  manreg.setAudioOFF();
  manreg.setMicOFF();
  msp.commands.setManualSetting(manreg.getData(), function (config) {
    msp.commands.getManualSetting(function(config){
      manreg.init(config.getTEFmanreg());
      res.render('pages/manreg', {
              username: req.user.username,
              breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
              version: version, mspConnected: msp.isConnected(),
              tefInfo: msp.getTEFInfo(),
              manreg: manreg,
              mode: '',
              kernelVersion: GetKernelVersion()
      });
    })
  });
});

// REGOLAZIONE MANUALE - Richiesta di spegnimento microfono - Prova altoparlante in ricezione
app.get('/spegnimicrofono', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " spegnimicrofono !!!!!!!!!!!!!");
  manreg.setMicOFF();
  manreg.setAudioON();
  msp.commands.setManualSetting(manreg.getData(), function (config) {
    res.render('pages/manreg', {
           username: req.user.username,
           breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
           version: version, mspConnected: msp.isConnected(),
           tefInfo: msp.getTEFInfo(),
           manreg: manreg,
           mode: 'reception',
           kernelVersion: GetKernelVersion()
    });
   });
 });


// REGOLAZIONE MANUALE - Richiesta di salvataggio del valore guadagno altoparlante - Riattivo il normale funzionamento
app.get('/registraaccendimicrofono', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " registraaccendimicrofono !!!!!!!!!!!!!");
  manreg.setAudioOFF();
  manreg.setMicOFF();
  var local_Settings_save = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  local_Settings_save.Settings.Niveau_entrant = req.query.val;
  fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings_save.Settings, { section: 'Settings' }));
  exec("sync",puts);
  msp.commands.setManualSetting(manreg.getData(), function (config) {
    msp.commands.saveManualSetting(function (config) {
      res.render('pages/manreg', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             manreg: manreg,
             mode: '',
             kernelVersion: GetKernelVersion()
        });
    });
  });
});


// REGOLAZIONE MANUALE - Richiesta di accensione microfono SENZA salvataggio guadagno altoparlante - Riattivo il normale funzionamento
app.get('/accendimicrofono', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " accendimicrofono !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    msp.commands.setManualSetting(manreg.getData(), function (config) {
      msp.commands.getManualSetting(function(config){
        manreg.init(config.getTEFmanreg());
        res.render('pages/manreg', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: '',
                kernelVersion: GetKernelVersion()
        });
      })
   });
});

//Uscita generica dalla pagina regolazione manuale - Riattivo il normale funzionamento SENZA salvare e torno in HomePage
app.get('/uscitadacalibrazionemanuale', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " uscitadacalibrazionemanuale !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    msp.commands.getManualSetting(function(config){
      manreg.init(config.getTEFmanreg());
      res.render('pages/index', {
          username: req.user.username,
          breadcrumbs: [breadcrumbs.home],
          version: version, mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: GetKernelVersion()
      });
    })
});

//Set dalla slider del nuovo valore guadagno microfono - MSP mantiene solo in RAM
app.get('/aggiornamicrofono', isLoggedIn, function (req, res) {
   ResetTimer();
     var invalue = req.query.value;
     console.log( " aggiornamicrofono !!!!!!!!!!!!!  " + invalue.toString());
     manreg.setMicLevel(invalue);
     msp.commands.setManualSetting(manreg.getData(), function (config) {
       res.render('pages/manreg', {
              username: req.user.username,
              breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
              version: version, mspConnected: msp.isConnected(),
              tefInfo: msp.getTEFInfo(),
              manreg: manreg,
              mode: 'transmission',
              kernelVersion: GetKernelVersion()
        });
     });
});

//Set dalla slider del nuovo valore guadagno altoparlante - MSP mantiene solo in RAM
  app.get('/aggiornaaudio', isLoggedIn, function (req, res) {
  ResetTimer();
       var invalue = req.query.value;
       console.log( "aggiornaaudio !!!!!!!!!!!!!   " + invalue.toString());
       manreg.setAudioLevel(invalue);
       msp.commands.setManualSetting(manreg.getData(), function (config) {
         res.render('pages/manreg', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: 'reception',
                kernelVersion: GetKernelVersion()

         });
      });
});


//Importazione parametro guadagno trasmissione da file INI
app.post('/importtransmission', isLoggedIn, function (req, res) {
    ResetTimer();
    upload(req, res, function (err) {
        var out = {};
        if (err) {
            out.result = false;
            out.reason = 'ErrorOccured';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI. ErrorOccured");
            return;
        }
        configFromFile = ini.parse(req.file.buffer.toString());
        if (typeof configFromFile.Configuration === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingConfigurationSection';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI. MissingConfigurationSection");
            return;
        }
        if (typeof configFromFile.Configuration.Typologie_TEF === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingTypologie_TEF';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI. MissingTypologie_TEF");
            return;
        }
        var Val_Niveau_de_sortie =  configFromFile.Configuration.Niveau_de_sortie;
        console.log("Importazione guadagno trasmissione da file INI. Valore Niveau_de_sortie letto: " + Val_Niveau_de_sortie);

        // REGOLAZIONE MANUALE - Richiesta di spegnimento altoparlante - Prova microfono in trasmissione
            manreg.setAudioOFF();
            console.log( ">SPEAKER OFF");
            manreg.setMicON();
            console.log( ">MIC ON");
            manreg.setMicLevel(Val_Niveau_de_sortie);
            console.log( ">MIC LEVEL: " + Val_Niveau_de_sortie);
            manreg.Niveau_de_sortie = Val_Niveau_de_sortie;
            msp.commands.setManualSetting(manreg.getData(), function (config) {

              out.result = true;
              out.href = 'pages/manreg&m=1';
              res.end(JSON.stringify(out));
                });
    });
});



//Importazione parametro guadagno ricezione da file INI
app.post('/importreception', isLoggedIn, function (req, res) {
    ResetTimer();
    upload(req, res, function (err) {
        var out = {};
        if (err) {
            out.result = false;
            out.reason = 'ErrorOccured';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI. ErrorOccured" + err + req + JSON.stringify(out));
            return;
        }
        configFromFile = ini.parse(req.file.buffer.toString());
        if (typeof configFromFile.Configuration === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingConfigurationSection';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI. MissingConfigurationSection");
            return;
        }
        if (typeof configFromFile.Configuration.Typologie_TEF === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingTypologie_TEF';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI. MissingTypologie_TEF");
            return;
        }
        var Val_Niveau_entrant =  configFromFile.Configuration.Niveau_entrant;
        console.log("Importazione guadagno ricezione da file INI. Valore Niveau_entrant letto: " + Val_Niveau_entrant);

        // REGOLAZIONE MANUALE - Richiesta di spegnimento microfono - Prova altoparlante in ricezione
            manreg.setMicOFF();
            console.log( ">MIC OFF");
            manreg.setAudioON();
            console.log( ">SPEAKER ON");
            manreg.setAudioLevel(Val_Niveau_entrant);
            console.log( ">SPEKER LEVEL: " + Val_Niveau_entrant);
            manreg.Niveau_entrant = Val_Niveau_entrant;
            msp.commands.setManualSetting(manreg.getData(), function (config) {
              out.result = true;
              out.href = 'pages/manreg';
              res.end(JSON.stringify(out));
                });
    });
});


//******************************************************************************************************************************************************************
//FINE SEZIONE REGOLAZIONE MANUALE GUADAGNO - L1
//******************************************************************************************************************************************************************


//******************************************************************************************************************************************************************
//INIZIO SEZIONE REGOLAZIONE MANUALE GUADAGNO - L2
//******************************************************************************************************************************************************************

//Carico pagina regolazione manuale
app.get('/manregL2', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log('/models/manregL2 Page load Manual Calibration from TEF');

    var ManregMode = req.query.m;
    switch (ManregMode){
      case "1":
        ManregMode = "transmission";
        res.render('pages/manregL2', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        manreg: manreg,
        mode: ManregMode,
        kernelVersion: GetKernelVersion()
        });
        break;
      case "2":
        ManregMode = "reception";
        res.render('pages/manregL2', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        manreg: manreg,
        mode: ManregMode,
        kernelVersion: GetKernelVersion()
        });
        break;
      default:
      ManregMode = "nothing";
      msp.commands.getManualSettingL2(function (config) {
               manreg.init(config.getTEFmanreg())
               res.render('pages/manregL2', {
               username: req.user.username,
               breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
               version: version, mspConnected: msp.isConnected(),
               tefInfo: msp.getTEFInfo(),
               manreg: manreg,
               mode: ManregMode,
               kernelVersion: GetKernelVersion()
               });
          });
    }
    console.log("ManregMode:" + ManregMode);
  });

// REGOLAZIONE MANUALE - Richiesta di spegnimento altoparlante - Prova microfono in trasmissione
app.get('/spegnialtoparlanteL2', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " spegnialtoparlante L2 !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicON();
    msp.commands.setManualSettingL2(manreg.getData(), function (config) {
      res.render('pages/manregL2', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             manreg: manreg,
             mode: 'transmission',
             kernelVersion: GetKernelVersion()
             });
        });

});

// REGOLAZIONE MANUALE - Richiesta di salvataggio del valore guadagno microfono - Riattivo il normale funzionamento
app.get('/registraaccendialtoparlanteL2', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " registraaccendialtoparlante L2 !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    var local_Settings_save = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
    local_Settings_save.Settings.Niveau_de_sortieL2 = req.query.val;
    fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings_save.Settings, { section: 'Settings' }));
    msp.commands.setManualSettingL2(manreg.getData(), function (config) {
      msp.commands.saveManualSettingL2(function (config) {
        res.render('pages/manregL2', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: '',
                kernelVersion: GetKernelVersion()
        });
      });
    });
});

// REGOLAZIONE MANUALE - Richiesta di accensione altoparlante SENZA salvataggio guadagno microfono - Riattivo il normale funzionamento
app.get('/accendialtoparlanteL2', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " accendialtoparlante L2 !!!!!!!!!!!!!");
  manreg.setAudioOFF();
  manreg.setMicOFF();
  msp.commands.setManualSettingL2(manreg.getData(), function (config) {
    msp.commands.getManualSettingL2(function(config){
      manreg.init(config.getTEFmanreg());
      res.render('pages/manregL2', {
              username: req.user.username,
              breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
              version: version, mspConnected: msp.isConnected(),
              tefInfo: msp.getTEFInfo(),
              manreg: manreg,
              mode: '',
              kernelVersion: GetKernelVersion()
      });
    })
  });
});

// REGOLAZIONE MANUALE - Richiesta di spegnimento microfono - Prova altoparlante in ricezione
app.get('/spegnimicrofonoL2', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " spegnimicrofono L2 !!!!!!!!!!!!!");
  manreg.setMicOFF();
  manreg.setAudioON();
  msp.commands.setManualSettingL2(manreg.getData(), function (config) {
    res.render('pages/manregL2', {
           username: req.user.username,
           breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
           version: version, mspConnected: msp.isConnected(),
           tefInfo: msp.getTEFInfo(),
           manreg: manreg,
           mode: 'reception',
           kernelVersion: GetKernelVersion()
    });
   });
 });


// REGOLAZIONE MANUALE - Richiesta di salvataggio del valore guadagno altoparlante - Riattivo il normale funzionamento
app.get('/registraaccendimicrofonoL2', isLoggedIn, function (req, res) {
  ResetTimer();
  console.log( " registraaccendimicrofono L2 !!!!!!!!!!!!!");
  manreg.setAudioOFF();
  manreg.setMicOFF();
  var local_Settings_save = ini.parse(fs.readFileSync(local_armsettings_file, 'utf-8'));
  local_Settings_save.Settings.Niveau_entrantL2 = req.query.val;
  fs.writeFileSync(local_armsettings_file, ini.stringify(local_Settings_save.Settings, { section: 'Settings' }));
  exec("sync",puts);
  msp.commands.setManualSettingL2(manreg.getData(), function (config) {
    msp.commands.saveManualSettingL2(function (config) {
      res.render('pages/manregL2', {
             username: req.user.username,
             breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
             version: version, mspConnected: msp.isConnected(),
             tefInfo: msp.getTEFInfo(),
             manreg: manreg,
             mode: '',
             kernelVersion: GetKernelVersion()
        });
    });
  });
});


// REGOLAZIONE MANUALE - Richiesta di accensione microfono SENZA salvataggio guadagno altoparlante - Riattivo il normale funzionamento
app.get('/accendimicrofonoL2', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " accendimicrofono L2 !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    msp.commands.setManualSettingL2(manreg.getData(), function (config) {
      msp.commands.getManualSettingL2(function(config){
        manreg.init(config.getTEFmanreg());
        res.render('pages/manregL2', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: '',
                kernelVersion: GetKernelVersion()
        });
      })
   });
});

//Uscita generica dalla pagina regolazione manuale - Riattivo il normale funzionamento SENZA salvare e torno in HomePage
app.get('/uscitadacalibrazionemanualeL2', isLoggedIn, function (req, res) {
  ResetTimer();
    console.log( " uscitadacalibrazionemanuale L2 !!!!!!!!!!!!!");
    manreg.setAudioOFF();
    manreg.setMicOFF();
    msp.commands.getManualSettingL2(function(config){
      manreg.init(config.getTEFmanreg());
      res.render('pages/index', {
          username: req.user.username,
          breadcrumbs: [breadcrumbs.home],
          version: version, mspConnected: msp.isConnected(),
          tefInfo: msp.getTEFInfo(),
          kernelVersion: GetKernelVersion()
      });
    })
});

//Set dalla slider del nuovo valore guadagno microfono - MSP mantiene solo in RAM
app.get('/aggiornamicrofonoL2', isLoggedIn, function (req, res) {
   ResetTimer();
     var invalue = req.query.value;
     console.log( " aggiornamicrofono L2 !!!!!!!!!!!!!  " + invalue.toString());
     manreg.setMicLevel(invalue);
     msp.commands.setManualSettingL2(manreg.getData(), function (config) {
       res.render('pages/manregL2', {
              username: req.user.username,
              breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
              version: version, mspConnected: msp.isConnected(),
              tefInfo: msp.getTEFInfo(),
              manreg: manreg,
              mode: 'transmission',
              kernelVersion: GetKernelVersion()
        });
     });
});

//Set dalla slider del nuovo valore guadagno altoparlante - MSP mantiene solo in RAM
  app.get('/aggiornaaudioL2', isLoggedIn, function (req, res) {
  ResetTimer();
       var invalue = req.query.value;
       console.log( "aggiornaaudio L2 !!!!!!!!!!!!!   " + invalue.toString());
       manreg.setAudioLevel(invalue);
       msp.commands.setManualSettingL2(manreg.getData(), function (config) {
         res.render('pages/manregL2', {
                username: req.user.username,
                breadcrumbs: [breadcrumbs.home, breadcrumbs.Règlage_Manuel],
                version: version, mspConnected: msp.isConnected(),
                tefInfo: msp.getTEFInfo(),
                manreg: manreg,
                mode: 'reception',
                kernelVersion: GetKernelVersion()

         });
      });
});


//Importazione parametro guadagno trasmissione da file INI
app.post('/importtransmissionL2', isLoggedIn, function (req, res) {
    ResetTimer();
    upload(req, res, function (err) {
        var out = {};
        if (err) {
            out.result = false;
            out.reason = 'ErrorOccured';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI L2. ErrorOccured");
            return;
        }
        configFromFile = ini.parse(req.file.buffer.toString());
        if (typeof configFromFile.Configuration === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingConfigurationSection';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI L2. MissingConfigurationSection");
            return;
        }
        if (typeof configFromFile.Configuration.Typologie_TEF === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingTypologie_TEF';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno trasmissione da file INI L2. MissingTypologie_TEF");
            return;
        }
        var Val_Niveau_de_sortie =  configFromFile.Configuration.Niveau_de_sortie;
        console.log("Importazione guadagno trasmissione da file INI L2. Valore Niveau_de_sortie letto: " + Val_Niveau_de_sortieL2);

        // REGOLAZIONE MANUALE - Richiesta di spegnimento altoparlante - Prova microfono in trasmissione
            manreg.setAudioOFF();
            console.log( ">SPEAKER OFF");
            manreg.setMicON();
            console.log( ">MIC ON");
            manreg.setMicLevel(Val_Niveau_de_sortie);
            console.log( ">MIC LEVEL: " + Val_Niveau_de_sortieL2);
            manreg.Niveau_de_sortie = Val_Niveau_de_sortieL2;
            msp.commands.setManualSettingL2(manreg.getData(), function (config) {

              out.result = true;
              out.href = 'pages/manregL2&m=1';
              res.end(JSON.stringify(out));
                });
    });
});



//Importazione parametro guadagno ricezione da file INI
app.post('/importreceptionL2', isLoggedIn, function (req, res) {
    ResetTimer();
    upload(req, res, function (err) {
        var out = {};
        if (err) {
            out.result = false;
            out.reason = 'ErrorOccured';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI L2. ErrorOccured" + err + req + JSON.stringify(out));
            return;
        }
        configFromFile = ini.parse(req.file.buffer.toString());
        if (typeof configFromFile.Configuration === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingConfigurationSection';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI L2. MissingConfigurationSection");
            return;
        }
        if (typeof configFromFile.Configuration.Typologie_TEF === 'undefined') {
            configFromFile = null;
            out.result = false;
            out.reason = 'MissingTypologie_TEF';
            res.end(JSON.stringify(out));
            console.log("Importazione guadagno ricezione da file INI L2. MissingTypologie_TEF");
            return;
        }
        var Val_Niveau_entrant =  configFromFile.Configuration.Niveau_entrant;
        console.log("Importazione guadagno ricezione da file INI L2. Valore Niveau_entrant letto: " + Val_Niveau_entrantL2);

        // REGOLAZIONE MANUALE - Richiesta di spegnimento microfono - Prova altoparlante in ricezione
            manreg.setMicOFF();
            console.log( ">MIC OFF");
            manreg.setAudioON();
            console.log( ">SPEAKER ON");
            manreg.setAudioLevel(Val_Niveau_entrant);
            console.log( ">SPEKER LEVEL: " + Val_Niveau_entrantL2);
            manreg.Niveau_entrant = Val_Niveau_entrantL2;
            msp.commands.setManualSettingL2(manreg.getData(), function (config) {
              out.result = true;
              out.href = 'pages/manregL2';
              res.end(JSON.stringify(out));
                });
    });
});


//******************************************************************************************************************************************************************
//FINE SEZIONE REGOLAZIONE MANUALE GUADAGNO - L2
//******************************************************************************************************************************************************************







//******************************************************************************************************************************************************************
//Get LAN interface countdown from driver
app.get('/getcountdown', function(req, res){

  //Check for file existance: no file = use default value
  if (fs.existsSync("/dev/dmg/wd_countdown")) {
      var countdown = fs.readFileSync("/dev/dmg/wd_countdown");
      console.log("Countdown: " + countdown);
  }
  else{
    countdown = 0;
    console.log("File /dev/dmg/wd_countdown non trovato! Invio 3600 sec.");
  }

  //Check value: if 0 use default
  if (countdown > 0){
    res.send(countdown);
  }
  else {
    //Default value in case of missing file/value in seconds
    res.send("3600");   //_CABLED_
  }
});


//******************************************************************************************************************************************************************
//GET della pagina di upload aggiornamento applicazione
app.get('/tef_update', isLoggedIn, function (req, res) {
  ResetTimer();
  var TimeoutAttivo = fs.readFileSync("/dev/dmg/wd_start");
  if (TimeoutAttivo != " is Disable\n"){
      fs.writeFileSync("/dev/dmg/wd_start", "60 60 1");
      exec("sync",puts);
  }
    res.render('pages/tef_update', {
        username: req.user.username,
        breadcrumbs: [breadcrumbs.home, breadcrumbs.tef_update],
        version: version, mspConnected: msp.isConnected(),
        tefInfo: msp.getTEFInfo(),
        kernelVersion: GetKernelVersion()
    });
});



//******************************************************************************************************************************************************************
//INIZIO SEZIONE PER LA GESTIONE DEI FILE AUDIO .WAV
//******************************************************************************************************************************************************************

    //******************************************************************************
    //GET per il PLAY del file audio
    app.get('/play', isLoggedIn, function (req, res) {
      var out = {};
      ResetTimer();
      var MSGToPlay = req.query.msg;
      console.log("L'utente chiede di riprodurre il file audio: " + MSGToPlay);
      SendFunction.PlayMSG(MSGToPlay);
      out.result = true;
      res.end(JSON.stringify(out));
    });

    //******************************************************************************
    //GET per il PLAY del file audio temporaneo (aggiungo 4 per discriminarlo nel parser)
    app.get('/playtmp', isLoggedIn, function (req, res) {
      var out = {};
      ResetTimer();
      var MSGToPlay = "0" + (parseInt(req.query.msg) + 4);
      console.log("L'utente chiede di riprodurre il file audio: " + MSGToPlay);
      SendFunction.PlayMSG(MSGToPlay);
      out.result = true;
      res.end(JSON.stringify(out));
    });

    //******************************************************************************
    //GET per il REC del file audio
    app.get('/rec', isLoggedIn, function (req, res) {
      var out = {};
      ResetTimer();
      var MSGToRec = req.query.msg;
      console.log("L'utente chiede di registrare il file audio: " + MSGToRec);
      SendFunction.RecMSG(MSGToRec);
      out.result = true;
      res.end(JSON.stringify(out));
    });


    //******************************************************************************
    //GET per il SAVE del file audio
    app.get('/save', isLoggedIn, function (req, res) {
      var out = {};
      ResetTimer();
      var MSGToSave = req.query.msg;
      console.log("L'utente chiede di salvare il file audio: " + MSGToSave);
      if (fs.existsSync("/tmp/tmp_" + MSGToSave + ".wav")) {

        if (fs.existsSync("/dmg/audio_msg/" + MSGToSave + ".wav")) {
            fs.unlinkSync("/dmg/audio_msg/" + MSGToSave + ".wav");
            exec("mv /tmp/tmp_" + MSGToSave + ".wav" + " /dmg/audio_msg/" + MSGToSave + ".wav", puts);
            console.log("File audio vecchio trovato, eliminato e salvato il temporaneo.");
          } else {
            exec("mv /tmp/tmp_" + MSGToSave + ".wav" + " /dmg/audio_msg/" + MSGToSave + ".wav", puts);
            console.log("File audio vecchio NON trovato, salvo il temporaneo.");
          }
      }
      else{
          console.log("File audio temporaneo da salvare NON trovato.");
      }
      out.result = true;
      res.end(JSON.stringify(out));
    });



    //******************************************************************************
    //GET per il DOWNLOAD del file audio dall'ARM sul browser
    app.get('/download_msg', isLoggedIn, function (req, res) {
      ResetTimer();
      var MSGToDownload = req.query.msg + ".wav";
      console.log("Donwload di:" + "/dmg/audio_msg/" + MSGToDownload);
      res.download("/dmg/audio_msg/" + MSGToDownload, MSGToDownload);
    });

    //******************************************************************************
    //POST per l'UPLOAD del file audio 01 dal browser sull'ARM
    app.post('/upload_msg01', function(req, res){
          upload(req, res, function (err) {
            var out = {};
            if (err) {
                console.log("Write file on disk ERROR...");
                out.result = false;
                out.reason = 'ErrorOccured';
                return;
            }
            const fs = require('fs');
            let writeStream = fs.createWriteStream('/dmg/audio_msg/01.wav');
            writeStream.write(req.file.buffer);
            // the finish event is emitted when all data has been flushed from the stream
            writeStream.on('finish', () => {
                 exec("sync",puts);
                 console.log("File audio 01 scritto...");
            });
            // close the stream
            writeStream.end();

            ResetTimer();
            out.result = true;
            res.end(JSON.stringify(out));
      });
    });

    //******************************************************************************
    //POST per l'UPLOAD del file audio 02 dal browser sull'ARM
    app.post('/upload_msg02', function(req, res){
          upload(req, res, function (err) {
            var out = {};
            if (err) {
                console.log("Write file on disk ERROR...");
                out.result = false;
                out.reason = 'ErrorOccured';
                return;
            }
            const fs = require('fs');
            let writeStream = fs.createWriteStream('/dmg/audio_msg/02.wav');
            writeStream.write(req.file.buffer);
            // the finish event is emitted when all data has been flushed from the stream
            writeStream.on('finish', () => {
                 exec("sync",puts);
                 console.log("File audio 02 scritto...");
            });
            // close the stream
            writeStream.end();
            ResetTimer();
            out.result = true;
            res.end(JSON.stringify(out));
      });
    });

    //******************************************************************************
    //POST per l'UPLOAD del file audio 03 dal browser sull'ARM
    app.post('/upload_msg03', function(req, res){
          upload(req, res, function (err) {
            var out = {};
            if (err) {
                console.log("Write file on disk ERROR...");
                out.result = false;
                out.reason = 'ErrorOccured';
                return;
            }
            const fs = require('fs');
            let writeStream = fs.createWriteStream('/dmg/audio_msg/03.wav');
            writeStream.write(req.file.buffer);
            // the finish event is emitted when all data has been flushed from the stream
            writeStream.on('finish', () => {
                 exec("sync",puts);
                 console.log("File audio 03 scritto...");
            });
            // close the stream
            writeStream.end();
            ResetTimer();
            out.result = true;
            res.end(JSON.stringify(out));
      });
    });

    //******************************************************************************
    //POST per l'UPLOAD del file audio 04 dal browser sull'ARM
    app.post('/upload_msg04', function(req, res){
          var out = {};
          upload(req, res, function (err) {
            if (err) {
                console.log("Write file on disk ERROR...");
                out.result = false;
                out.reason = 'ErrorOccured';
                return;
            }
            const fs = require('fs');
            let writeStream = fs.createWriteStream('/dmg/audio_msg/04.wav');
            writeStream.write(req.file.buffer);
            // the finish event is emitted when all data has been flushed from the stream
            writeStream.on('finish', () => {
                 exec("sync",puts);
                 console.log("File audio 04 scritto...");
            });
            // close the stream
            writeStream.end();
            ResetTimer();
            out.result = true;
            res.end(JSON.stringify(out));
      });
    });

//******************************************************************************************************************************************************************
//FINE SEZIONE PER LA GESTIONE DEI FILE AUDIO .WAV
//******************************************************************************************************************************************************************



//Post contenente il file "aggiornamento applicazione"
app.post('/tef_update', function(req, res){
      upload(req, res, function (err) {

        var out={};

        if (err) {
            console.log("Write file on disk ERROR...");
            ResetTimer();
            out.result = false;
            out.reason = 'ErrorOccured';
            return;
        }

        StopTimer();
        console.log("Start writing file on disk..." + req.file.buffer.length);
        const fs = require('fs');

        let writeStream = fs.createWriteStream('/dmg/update/update.ipk');
        writeStream.write(req.file.buffer);

        // the finish event is emitted when all data has been flushed from the stream
        writeStream.on('finish', () => {
            console.log('wrote all data to file');
             exec("sync",puts);
              setTimeout(function() {
                  exec("reboot", puts);
              }, 6000);
        });

        // close the stream
        writeStream.end();

        out.result = true;
        res.end(JSON.stringify(out));


  });
});

};
/*********************** Finisce  il blocco function **********************/


//********************** Funzioni Generali *******************************/
function GetKernelVersion (){
  var kernel = fs.readFileSync("/dev/dmg/kernel")
  return kernel;
}


// route middleware to make sure
function isLoggedIn(req, res, next) {
    // if user is authenticated in the session, carry on
    if (req.isAuthenticated()) {
      if(fs.existsSync("/tmp/session_id") && fs.readFileSync("/tmp/session_id") == req.sessionID){
        return next();
      }
      else {
        kickedUser = true;
        console.log("KickedUser - Exist /tmp/session_id:" + fs.existsSync("/tmp/session_id") + "  /tmp/session_id:" + fs.readFileSync("/tmp/session_id") + "   req.sessionID:" + req.sessionID);
      }
    }


    if(kickedUser)
      req.flash('errorMessage', 'Un autre utilisateur est actif, vous ne pouvez pas accéder.')

    // if they aren't redirect them to the home page
    res.redirect('/login');
    res.end();
}
