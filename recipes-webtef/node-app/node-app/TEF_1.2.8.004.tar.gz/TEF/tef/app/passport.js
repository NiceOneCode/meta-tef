
var Strategy = require('passport-local').Strategy;

var fs = require('fs');
var ini = require('ini');

module.exports = function (passport) {

    passport.use(new Strategy({
        usernameField: 'username',
        passwordField: 'password',
        passReqToCallback: true
    }, function (req, username, password, cb) {
        var users = ini.parse(fs.readFileSync(__dirname + '/../config/users.ini', 'utf-8'));
        var loggedUser = {};

        try
        {
          if (users.login.auto_log_off.toString() == "true"){
            var autokick = "true";
          }
        }
        catch(e)
        {
          var autokick = "false";
        }

        for (var i in users.administrateurs.username) {
            if (username === users.administrateurs.username[i] && password === users.administrateurs.password[i]) {
                loggedUser.role = 'Administrateur';
                loggedUser.username = username;
                if (autokick == "true"){
                  if(fs.existsSync("/tmp/session_id")){
                    fs.unlinkSync("/tmp/session_id");
                  }
                }
                if(!fs.existsSync("/tmp/session_id")){
                   fs.writeFileSync("/tmp/session_id", req.sessionID);
                }
                return cb(null, loggedUser);
            }
        }
        for (var i in users.usagers.username) {
            if (username === users.usagers.username[i] && password === users.usagers.password[i]) {
                loggedUser.role = 'Usager';
                loggedUser.username = username;
                if (autokick == "true"){
                  if(fs.existsSync("/tmp/session_id")){
                    fs.unlinkSync("/tmp/session_id");
                  }
                }
                if(!fs.existsSync("/tmp/session_id")){
                   fs.writeFileSync("/tmp/session_id", req.sessionID);
                }
                return cb(null, loggedUser);
            }
        }
        for (var i in users.guests.username) {
            if (username === users.guests.username[i] && password === users.guests.password[i]) {
                loggedUser.role = 'Guest';
                loggedUser.username = username;
                if (autokick == "true"){
                  if(fs.existsSync("/tmp/session_id")){
                    fs.unlinkSync("/tmp/session_id");
                  }
                }
                if(!fs.existsSync("/tmp/session_id")){
                   fs.writeFileSync("/tmp/session_id", req.sessionID);
                }
                return cb(null, loggedUser);
            }
        }
        return cb(null, false, req.flash('errorMessage', 'ACCÈS INTERDIT. Nom d\'utilisateur ou mot de passe incorrect.'));
    }));

    passport.serializeUser(function (user, cb) {
        cb(null, user);
    });

    passport.deserializeUser(function (user, cb) {
//        var user = {};
//        user.id = id;
        cb(null, user);
    });

};
