// /**
//  *
//  * @param {type} msp
//  * @param {type} io
//  * @return {undefined}
//  */
//
// var status = false;
//
// var flow = require('nimble');
//
// module.exports = function (msp, io) {
// //    setInterval(function () {
// //        if (status === false) {
// //            msp.init(function (data) {
// //                io.emit('serial_receive', {data: data.toString("hex")});
// //            }, function () {
// //                status = true;
// //                io.emit('status', {status: status, serial_port: process.env.serial_port});
// //                msp.CMD_GET_INIT_ARM(function (getInitARM) {
// //                    process.env.getInitARM = getInitARM;
// //                });
// //            }, function () {
// //                status = false;
// //                io.emit('status', {status: status, serial_port: process.env.serial_port});
// //            });
// //        }
// //    }, 1000);
//
//     io.on('connection', function (socket) {
//         socket.on('status', function () {
//             io.emit('status', {status: status, serial_port: process.env.serial_port});
//         });
//         socket.on('serial_send', function (message) {
//             message.data = message.data.replace(/\s+/g, ''); // remove all spaces in string
//             msp.forward(message.data, function (result) {
//                 status = result;
//             });
//         });
// //        socket.on('visualisation', function () {
// //            var result = {};
// //            flow.series([
// //                function (callback) {
// //                    msp.CMD_GET_INIT_ARM(function (response) {
// //                        result.CMD_GET_INIT_ARM = response;
// //                        callback();
// //                    });
// //                },
// //                function (callback) {
// //                    msp.CMD_GET_CFG(function (response) {
// //                        result.CMD_GET_CFG = response;
// //                        callback();
// //                    });
// //                },
// //                function (callback) {
// //                    io.emit('visualisation', {data: result});
// //                    callback();
// //                }
// //            ]);
// //        });
//         // socket.on('logiciel', function () {
//         //     socket.emit('logiciel_progress', {progress: 20});
//         //     msp.commands.reboot(function () {
//         //         socket.emit('logiciel_progress', {progress: 40});
//         //         msp.commands.eraseFlash(function () {
//         //             socket.emit('logiciel_progress', {progress: 60});
//         //             msp.commands.sendFirmware(req.file.buffer.toString("hex"), function () {
//         //                 socket.emit('logiciel_progress', {progress: 80});
//         //                 console.log("FATTO");
//         //             });
//         //         });
//         //     });
//         // });
//     });
// };
