module.exports = {
    'home': {
        name: '<span class="glyphicon glyphicon-home"></span>&nbsp;Home',
        link: '/'
    },
    'configuration': {
        name: '<span class="glyphicon glyphicon-wrench"></span>&nbsp;Conf<span class="hidden-xs">iguration</span>',
        link: '/configuration'
    },
    'chargement': {
        name: '<span class="glyphicon glyphicon-import"></span>&nbsp;Charge<span class="hidden-xs hidden-md">ment</span> Conf<span class="hidden-xs hidden-md">iguration</span> Existante',
        link: '/chargement'
    },
    'config_bibl': {
        name: 'TEF <strong>BI.BL</strong>',
        link: '/configs/bibls'
    },
    'config_bibcpro': {
        name: 'TEF <strong>BI.BC.PRO</strong>',
        link: '/configs/bibcpro'
    },
    'config_bibccla': {
        name: 'TEF <strong>BI.BC.CLA</strong>',
        link: '/configs/bibccla'
    },
    'config_bibcm': {
        name: 'TEF <strong>BI.BC.M</strong>',
        link: '/configs/bibcm'
    },
    'config_hi': {
        name: 'TEF <strong>HI</strong>',
        link: '/configs/hi'
    },
    'config_hi2': {
        name: 'TEF <strong>HI2</strong>',
        link: '/configs/hi2'
    },
    'config_radio': {
        name: 'TEF <strong>RADIO</strong>',
        link: '/configs/radio'
    },
    'visualisation': {
        name: '<span class="glyphicon glyphicon-search"></span>&nbsp;Vis<span class="hidden-xs">ualisation</span>',
        link: '/visualisation'
    },
    'telechargement': {
        name: '<span class="glyphicon glyphicon-send"></span>&nbsp;Télécharge<span class="hidden-xs hidden-md">ment</span> Logiciels',
        link: '/telechargement'
    },
    'Règlage_Manuel': {
        name: '<span class="glyphicon glyphicon-send"></span>&nbsp;Règlage Manuel<span class="hidden-xs hidden-md"></span>',
        link: '/manreg'
    },
    'Mot_De_Passe': {
        name: '<span class="glyphicon glyphicon-wrench"></span>&nbsp;WiFi Mot de passe<span class="hidden-xs hidden-md"></span>',
        link: '/wifimdp'
    },
    'tef_update': {
        name: '<span class="glyphicon glyphicon-wrench"></span>&nbsp;Mise à jour de la version TEF<span class="hidden-xs hidden-md"></span>',
        link: '/tef_update'
    }
};
